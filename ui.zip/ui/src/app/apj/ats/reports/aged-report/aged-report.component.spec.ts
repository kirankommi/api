import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgedReportComponent } from './aged-report.component';

describe('AgedReportComponent', () => {
  let component: AgedReportComponent;
  let fixture: ComponentFixture<AgedReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgedReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgedReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
