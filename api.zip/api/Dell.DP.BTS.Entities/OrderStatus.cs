﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class OrderStatus
    {
        public string OrderStatusName { get; set; }
        public string GossStatusCode { get; set; }
        public bool? FulfillWarning { get; set; }
        public bool? CancelWarning { get; set; }
    }
}
