﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class AtsIncomingSupply
    {
        public string Site { get; set; }
        public int LeadTime { get; set; }
        public int Quantity { get; set; }
        public int NetIntransitQuantity { get; set; }
        public int NetFutureCommitQuantity { get; set; }
    }
}
