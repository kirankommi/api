﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class ZoneFulfillment
    {
        public int Id { get; set; }
        public int? ProductTypeId { get; set; }
        public string ZoneCode { get; set; }
        public bool? AllowsSecondTouch { get; set; }
        public bool? AllowsOutOfStock { get; set; }
        public int? Priority { get; set; }
        public string Action { get; set; }
        public AtsSite site { get; set; }
    }
}
