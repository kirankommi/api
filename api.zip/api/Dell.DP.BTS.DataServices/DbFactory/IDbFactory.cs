﻿using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dell.DP.BTS.DataServices.DbFactory
{
    public interface IDbFactory
    {
        Database Database { get; }
    }
}
