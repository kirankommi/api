import { Injectable, Injector } from '@angular/core';
import { ApjatsDashboardService } from '../apj/ats/dashboard/apjats-service.service';
import { ItemDetailsService } from '../apj/ats/item-details/item-details-service.service';
import { ApjAtsCountryService } from '../apj/ats/country/apj-ats-country.service';
import { FulfillmentCenterService } from '../apj/ats/FulfillmentCenterDetails/fulfillment-center-details.service';
import { ApjAtsCommitfalloutService } from '../apj/ats/reports/commitfallout/apj-ats-commitfallout.service';
import { AtsCommitService } from '../apj/ats/commit-details/commit-details.service';
import { ProductManagementService } from '../apj/ats/product-management/product-management.service';
import { AgedReportService } from '../apj/ats/reports/aged-report/aged-report.service';
import { ApjAtsConfigMgmtService } from '../apj/ats/configuration-management/apj-ats-configmgmt.service';
import { AtsJobConfigurationService } from '../apj/ats/job-configuration/job-configuration.service';
import { ApjAtsProductConfigService } from '../apj/ats/product-config/apj-ats-product-config.service';
import { ItemExceptionReportService } from '../apj/ats/reports/item-exception-report/item-exception-report.service';
import { ApjAtsCatalogService } from '../apj/ats/catalog/apj-ats-catalog.service';
import { ApjAtsRuleManagerService } from '../apj/ats/rule-manager/apj-ats-rulemanager.service';
import { ApjAtsRuleDetailService } from '../apj/ats/rule-manager/apj-ats-ruledetail.service';

@Injectable({
  providedIn: 'root'

})
export class ApjAtsFacadeService {
  //#region "Injected Service Object"
  private _ApjatsDashboardService: ApjatsDashboardService;
  private _itemDetailsService: ItemDetailsService;
  private _apjAtsCountryService: ApjAtsCountryService;
  private _fulfillmentCenterService: FulfillmentCenterService;
  private _apjAtsCommitfalloutService: ApjAtsCommitfalloutService;
  private _atsCommitService: AtsCommitService;
  private _productManagementService: ProductManagementService;
  private _agedReportService: AgedReportService;
  private _apjAtsConfigMgmtService: ApjAtsConfigMgmtService;
  private _jobConfigurationService: AtsJobConfigurationService;
  private _apjAtsProductConfigService: ApjAtsProductConfigService;
  private _itemExceptionReportService: ItemExceptionReportService;
  private _apjAtsCatalogService: ApjAtsCatalogService;
  private _apjAtsRuleManagerService: ApjAtsRuleManagerService;
  private _apjAtsRuleDetailService: ApjAtsRuleDetailService;
  //#endregion

  //#region "Injected Service Object Initialisation"
  public get apjatsDashboardService(): ApjatsDashboardService {
    if (!this._ApjatsDashboardService) {
      this._ApjatsDashboardService = this.injector.get(ApjatsDashboardService);
    }
    return this._ApjatsDashboardService;
  }

  public get itemDetailsService(): ItemDetailsService {
    if (!this._itemDetailsService) {
      this._itemDetailsService = this.injector.get(ItemDetailsService);
    }
    return this._itemDetailsService;
  }

  public get apjAtsCountryService(): ApjAtsCountryService {
    if (!this._apjAtsCountryService) {
      this._apjAtsCountryService = this.injector.get(ApjAtsCountryService);
    }
    return this._apjAtsCountryService;
  }
  public get fulfillmentCenterService(): FulfillmentCenterService {
    if (!this._fulfillmentCenterService) {
      this._fulfillmentCenterService = this.injector.get(FulfillmentCenterService);
    }
    return this._fulfillmentCenterService;
  }
  public get apjAtsCommitfalloutService(): ApjAtsCommitfalloutService {
    if (!this._apjAtsCommitfalloutService) {
      this._apjAtsCommitfalloutService = this.injector.get(ApjAtsCommitfalloutService);
    }
    return this._apjAtsCommitfalloutService;
  }
  public get productManagementService(): ProductManagementService {
    if (!this._productManagementService) {
      this._productManagementService = this.injector.get(ProductManagementService);
    }
    return this._productManagementService;
  }

  public get atsCommitService(): AtsCommitService {
    if (!this._atsCommitService) {
      this._atsCommitService = this.injector.get(AtsCommitService);
    }
    return this._atsCommitService;
  }

  public get apjAtsConfigMgmtService(): ApjAtsConfigMgmtService {
    if (!this._apjAtsConfigMgmtService) {
      this._apjAtsConfigMgmtService = this.injector.get(ApjAtsConfigMgmtService);
    }
    return this._apjAtsConfigMgmtService
  }

  public get apjAtsProductConfigService(): ApjAtsProductConfigService {
    if (!this._apjAtsProductConfigService) {
      this._apjAtsProductConfigService = this.injector.get(ApjAtsProductConfigService);
    }
    return this._apjAtsProductConfigService
  }

  public get apjAtsCatalogService(): ApjAtsCatalogService {
    if (!this._apjAtsCatalogService) {
      this._apjAtsCatalogService = this.injector.get(ApjAtsCatalogService);
    }
    return this._apjAtsCatalogService;
  }

  public get apjAtsRuleManagerService(): ApjAtsRuleManagerService {
    if (!this._apjAtsRuleManagerService) {
      this._apjAtsRuleManagerService = this.injector.get(ApjAtsRuleManagerService);
    }
    return this._apjAtsRuleManagerService;
  }

  public get apjAtsRuleDetailService(): ApjAtsRuleDetailService {
    if (!this._apjAtsRuleDetailService) {
      this._apjAtsRuleDetailService = this.injector.get(ApjAtsRuleDetailService);
    }
    return this._apjAtsRuleDetailService;
  }

  //Aged Report
  public get agedReportService(): AgedReportService {
    if (!this._agedReportService) {
      this._agedReportService = this.injector.get(AgedReportService);
    }
    return this._agedReportService;
  }

  //Item Exception Report
  public get itemExceptionReportService(): ItemExceptionReportService {
    if (!this._itemExceptionReportService) {
      this._itemExceptionReportService = this.injector.get(ItemExceptionReportService);
    }
    return this._itemExceptionReportService;
  }

  //#endregion

  /* Start Job Configuration */
  public get atsJobConfigurationService(): AtsJobConfigurationService {
    if (!this._jobConfigurationService) {
      this._jobConfigurationService = this.injector.get(AtsJobConfigurationService);
    }
    return this._jobConfigurationService;
  }
  /* End Job Configuration */
  constructor(private injector: Injector) {

  }
  //#region "Apj Ats Search Methods"
  LoadStockStatus() {
    return this.apjatsDashboardService.LoadStockStatus();
  }
  loadCountries(Id) {
    return this.apjatsDashboardService.loadCountries(Id);
  }
  loadCatalogGroup(Id) {
    return this.apjatsDashboardService.loadCatalogGroup(Id);
  }
  loadLocationCode(Id) {
    return this.apjatsDashboardService.loadLocationCode(Id);
  }
  Search(objapjAtsDashboard) {
    return this.apjatsDashboardService.Search(objapjAtsDashboard);
  }
  //#endregion

  //#region "Apj Ats Item Details Methods"
  getDaysofSupply(ProductCountryId) {
    return this.itemDetailsService.getDaysofSupply(ProductCountryId);
  }
  getAtsItemDetail(ProductCountryId) {
    return this.itemDetailsService.getAtsItemDetail(ProductCountryId);
  }
  getInventoryStatus(ProductCountryId, RegionId) {
    return this.itemDetailsService.getInventoryStatus(ProductCountryId, RegionId);
  }
  getLeadTimeHistory(ProductCountryId) {
    return this.itemDetailsService.getLeadTimeHistory(ProductCountryId);
  }
  getItemStatusHistory(ProductCountryId) {
    return this.itemDetailsService.getItemStatusHistory(ProductCountryId);
  }
  getDataRefreshDetail(ProductCountryId) {
    return this.itemDetailsService.getDataRefreshDetail(ProductCountryId);
  }
  getIncomingSupply(ProductCountryId) {
    return this.itemDetailsService.getIncomingSupply(ProductCountryId);
  }
  updateThreshold(postData) {
    return this.itemDetailsService.updateThreshold(postData);
  }
  updateAutoXLT(postData) {
    return this.itemDetailsService.updateAutoXLT(postData);
  }
  updateLeadTime(postData) {
    return this.itemDetailsService.updateLeadTime(postData);
  }
  updateContinueToSell(postData) {
    return this.itemDetailsService.updateContinueToSell(postData);
  }
  updateLowInventory(postData) {
    return this.itemDetailsService.updateLowInventory(postData);
  }
  updateIsActive(postData) {
    return this.itemDetailsService.updateIsActive(postData);
  }
  //#endregion

  //#region "Apj Ats Country Methods"
  getCountries(selRegion) {
    return this.apjAtsCountryService.getCountries(selRegion);
  }
  getLocationCode(selRegion) {
    return this.apjAtsCountryService.getLocationCode(selRegion);
  }
  updateCountry(ApjAtsCountry) {
    return this.apjAtsCountryService.updateCountry(ApjAtsCountry);
  }
  //#endregion
  //#region "Fulfillment Center Service"
  getProductFulfillment(ProductCountryId, RegionId) {
    return this.fulfillmentCenterService.getProductFulfillment(ProductCountryId, RegionId);
  }
  updateFulfillmentLocation(postData) {
    return this._fulfillmentCenterService.updateFulfillmentLocation(postData);
  }


  //#endregion

  //#region "Apj Ats commitfallout Methods"
  getCommitFallout(commitFalloutRequest) {
    return this.apjAtsCommitfalloutService.getCommitFallout(commitFalloutRequest);
  }
  getExportCommitFallout(commitFalloutRequest) {
    return this.apjAtsCommitfalloutService.getExportCommitFallout(commitFalloutRequest);
  }
  //#endregion

  // region Commit Service

  getCommitDetails(productCountryId) {
    return this.atsCommitService.getCommitDetails(productCountryId);
  }
  exportCommitDetails(productCountryId) {
    return this.atsCommitService.exportCommitDetails(productCountryId);
  }

  cancelCommitOrder(postData) {
    return this.atsCommitService.cancelCommitOrder(postData);
  }

  markAsFulfill(postData) {
    return this.atsCommitService.markAsFulfill(postData);
  }
  //#region "Product Management"
  GetProductTypes() {
    return this.productManagementService.GetProductTypes();
  }
  getCountriesAndCatalogGroups(regionId) {
    return this.productManagementService.getCountriesAndCatalogGroups(regionId);
  }
  GetProductDetails(productId, regionId) {
    return this.productManagementService.GetProductDetails(productId, regionId);
  }
  GetProductCountryDefaults() {
    return this.productManagementService.GetProductCountryDefaults();
  }
  getAllRegions() {
    return this.productManagementService.getAllRegions();
  }
  updateProductInformation(productInfo) {
    return this.productManagementService.updateProductInformation(productInfo);
  }

  //#endregion "Product Management"

  //#region "Aged Report"
  agedReportSearch(agedReportRequest) {
    return this.agedReportService.agedReportSearch(agedReportRequest);
  }
  //#endregion "Aged Report"

  //#region "Item Exception Report"
  itemExceptionReportSearch(itemExceptionReportRequest) {
    return this.itemExceptionReportService.itemExceptionReportSearch(itemExceptionReportRequest);
  }
  //#endregion "Item Exception Report"

  //#region "Configuration Management"
  getApplications() {
    return this.apjAtsConfigMgmtService.getApplications();
  }
  getApplicationConfigurations(filter) {
    return this.apjAtsConfigMgmtService.getApplicationConfigurations(filter);
  }
  updateapplicationconfiguration(postData) {
    return this.apjAtsConfigMgmtService.updateapplicationconfiguration(postData);
  }
  //#endregion

  /* Start Job Configuration */
  getJobConfigurationDetails(regionId) {
    return this.atsJobConfigurationService.getJobConfigurationDetails(regionId);
  }
 
  getTransactionDetails(regionId) {
    return this.atsJobConfigurationService.getTransactionDetails(regionId);
  }

  reStartWindowsService() {
    return this.atsJobConfigurationService.reStartWindowsService();
  }

  runJob(jobName) {
    return this.atsJobConfigurationService.runJob(jobName);
  }

  /* End Job Configuration */

  //#region "Product Configuration"
  getProductConfiguration() {
    return this.apjAtsProductConfigService.getProductConfiguration();
  }

  updateProductConfiguration(postData) {
    return this.apjAtsProductConfigService.updateProductConfiguration(postData);
  }
  //#endreion

  //#region "Catalog"
  getCatalogs(data) {
    return this.apjAtsCatalogService.getCatalogs(data);
  }
  UpdateCatalog(atsCatalog) {
    return this.apjAtsCatalogService.UpdateCatalog(atsCatalog);
  }
  DeleteCatalog(atsCatalog) {
    return this.apjAtsCatalogService.DeleteCatalog(atsCatalog);
  }
  //#endregion

  //#region "Rule Manager"
  getapplicationruleconfigurations(filter) {
    return this.apjAtsRuleManagerService.getapplicationruleconfigurations(filter);
  }
  //#endregion

  //#region "Rule Detail"
  getCatalog(data) {
    return this.apjAtsRuleDetailService.getCatalog(data);
  }
  getProductLines(catalogId) {
    return this.apjAtsRuleDetailService.getProductLines(catalogId);
  }
  getBrands(productLineId) {
    return this.apjAtsRuleDetailService.getBrands(productLineId);
  }
  updateapplicationruleconfiguration(atsApplicationConfigurationList) {
    return this.apjAtsRuleDetailService.updateapplicationruleconfiguration(atsApplicationConfigurationList);
  }
  //#endregion
}
