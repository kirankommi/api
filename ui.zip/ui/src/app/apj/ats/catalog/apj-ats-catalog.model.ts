export class ApjAtsCountry
{
  id: number;
  code: string;
  countryName: string;
  regionId: number;
  operation: string = null;
  allowFutureCommit: boolean;
  site: AtsSite;
  modifiedBy: string;
  active: boolean;
}

export class AtsSite
{
  id: number;
  siteName: string;
  siteCode: string;
  description: string;
  countryName: string;
  modifiedBy: string;
  countryId: number;
  oldCountryId: number;
  sequence: number;
  type: string;
  isActive: boolean;
  productCountryId: number;
  operation: string;
}

export class Data {
  CountryName: string;
  RegionCode: string;
  CatalogId: string;
  RegionId: string;
}

export class AtsCatalog {
  id: number;
  countryId: number;
  countryName: string;
  regionCode: string;
  catalogId : number;
  catalogGroupId: number;
  catalogGroup: string;
  countryCodes: string;
  countryIdsCsv: string;
  countryIds: number[] = [];
  userID: string;
  regionId: number;
  Edit: boolean;
}
