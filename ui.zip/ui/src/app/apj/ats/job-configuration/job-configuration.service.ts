import { Injectable } from '@angular/core';
import { DataservicesProvider } from '@Dataservice/dataservices/dataservices';
import { Global } from '@App/shared/global';
import { Observable } from 'rxjs/Observable';
import { AtsJobDetail, AtsJobTransactionStatus } from './job-configuration.model';
import { environment } from '@Environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AtsJobConfigurationService {

  constructor(private _DataservicesProvider: DataservicesProvider) {
  }

  getJobConfigurationDetails(regionId): Observable<AtsJobDetail[]> {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getjobdetails/' + regionId);
  }

  getTransactionDetails(regionId): Observable<AtsJobTransactionStatus[]> {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'gettransactiondetails/' + regionId);
  }

  reStartWindowsService() {
    let userName = 'a';
    let postData = {
      "JobName": "InTransitJob",
      "UserName": userName,
      "Operation": 'Restart'
    }
    return this._DataservicesProvider.PostDataWithHeader(environment.ApjEmeaAtsApiUrl + 'command/ReStartWindowsService/', postData);
  }

  runJob(jobName) {
    let userName = 'a';
    let postData1 = {
      JobName: jobName,
      UserName: userName,
      Operation: 'add'
    };
     
    return this._DataservicesProvider.PostDataWithHeader(environment.ApjEmeaAtsApiUrl + 'command/runaction/', postData1);
  }
}
