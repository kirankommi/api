﻿using Dell.DP.BTS.Entities;
using Dell.DP.BTS.API.Controllers;
using Dell.DP.BTS.DataServices;
using Dell.DP.BTS.BusinessServices;
using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    
    public class RuleManagerUnitTest:UnitTestInitializer
    {

        [Fact]
        public void GetRuleManagerDataShouldReturnOKResult()
        {
            AtsAppConfigRequest items = new AtsAppConfigRequest()
            {
                ApplicationIds = "1,2",
                ConfigIDs = "26,28",
                ConfigValues = "",
                Status = "0",
                PageNumber = 1,
                PageSize = 50
            };
            var result = btsQueryController.GetApplicationRuleConfigurations(items);
            Assert.NotNull(result);
        }
    }
}
