﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class IsgSourcingStrategy
    {
        public int RecordId { get; set; }
        public string ItemCategoryGroup { get; set; }
        public string PlantId { get; set; }
        public string SalesOrgId { get; set; }
        public string ShipToCountryCode2Char { get; set; }
        public string SoldToCountryCode2Char { get; set; }
        public string InstallAtCountryCode2Char { get; set; }
        public int IsOutsourced { get; set; }

    }

}
