import { ɵangular_packages_core_core_u } from '@angular/core';

  export class productManagementReff {
    ProductId: number;
    Sku: string;
    CatalogGroupId: string;
  }

  export class ProductCountry {
    salesChannel: number;
    countryID: number;
    countryName: string;
    continueToSell: boolean;
    sellActionOffline: string;
    includePreCheckout: boolean;
    includePostCheckout: boolean;
    displayLowInventory: boolean;
    leadTime: number;
    extendedLeadTime: number;
    low: number;
    sds: number;
    oversell: number;
    oversold: number;
    oversoldOffline: number;
    sdsEnabled: boolean;
    catalogGroupId: number;
    countryIds: string;
    catalogCountryBindingID: string;
    constructor(countryID: number, countryName:string , continueToSell: boolean, includePreCheckout: boolean, includePostCheckout: boolean, displayLowInventory: boolean, leadTime: number,
      extendedLeadTime: number, low: number, sds: number, oversell: number, oversold: number, sdsEnabled: boolean, sellActionOffline: string, oversoldOffline: number, catalogGroupId: number, countryIds: string,
      catalogCountryBindingID: string) {
      this.countryID = countryID;
      this.countryName = countryName;
      this.continueToSell = continueToSell;
      this.includePreCheckout = includePreCheckout;
      this.includePostCheckout = includePostCheckout;
      this.displayLowInventory = displayLowInventory;
      this.leadTime = leadTime;
      this.extendedLeadTime = extendedLeadTime;
      this.low = low;
      this.sds = sds;
      this.oversell = oversell;
      this.oversold = oversold;
      this.sdsEnabled = sdsEnabled;
      this.sellActionOffline = sellActionOffline;
      this.oversoldOffline = oversoldOffline;
      this.catalogGroupId = catalogGroupId;
      this.countryIds = countryIds;
      this.catalogCountryBindingID = catalogCountryBindingID;
    } 
  }

  export class ProductCatalog {
    countryID: number;
    countryName: string;
    catalogID: number;
    salesViewVisibility: boolean;
    eQuote: string;
    orderQuote: string;
    constructor(_countryID: number, _countryName: string, _catalogID: number, _salesViewVisibility: boolean, _eQuote: string, _orderQuote: string) {
      this.countryID = _countryID;
      this.countryName = _countryName;
      this.catalogID = _catalogID;
      this.salesViewVisibility = _salesViewVisibility;
      this.eQuote = _eQuote;
      this.orderQuote = _orderQuote;
    }
  }

  export interface ProductDetails {
    id: number;
    sku: string;
    name: string;
    description: string;
    fga: string;
    brand: string;
    offer: string;
    seperateMessaging: boolean;
    active: boolean;
    productType: number;
    productTypeName: string;
    productCountries: ProductCountry[];
    productCatalogs: ProductCatalog[];
  }
  export interface Site {
    countryId: number;
    oldCountryId: number;
    sequence: number;
    isActive: boolean;
    productCountryId: number;
    updatedOn: Date;
    createdOn: Date;
  }

export interface CountriesAndCatalogGroups {
    id: number;
    countryName: string;
    active: boolean;
    sequence: number;
    site: Site;
    catalogCountryBindingID: string;
    isCatalogGroup: boolean;
    countryIds: string;
  }
export interface AllRegions {
  id: number;
  name: string;
  countryID: number;
}

