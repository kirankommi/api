import { Injectable } from '@angular/core';
import {DataservicesProvider} from '@Dataservice/dataservices/dataservices';
import { Global } from '@App/shared/global';


@Injectable({
  providedIn: 'root'
})
export class ItemExceptionReportService {

  //Variable Declarations
  queryApiBaseUrl: string;

  //Constructor
  constructor(private _dataservicesProvider: DataservicesProvider) {
    this.queryApiBaseUrl = Global.ApjEmeaAtsApiUrl;
  }

  itemExceptionReportSearch(itemExceptionReportRequest) {
    return this._dataservicesProvider.PostData(this.queryApiBaseUrl + 'getInTransitDetails', itemExceptionReportRequest);
  }
}
