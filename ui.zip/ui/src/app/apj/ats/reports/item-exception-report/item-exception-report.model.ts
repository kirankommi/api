export class ItemExceptionReportRequest {
  SiteIds: string;
  ProductTypeIds: string;
  Parts: string;
  PageNumber: number;
  PageSize: number;
}
export interface ReportData {
  Type: string;
  GroupName: string;
  Catalog: string;
  Sku: string;
  Part: string;
  Status: string;
  AggregateATS: string;
  SDSThreshold: string;
  NetSDS: string;
  InOversellThreshold: string;
  NetOversell: string;
  InOversoldThreshold: string;
  NetOversold: string;
  LTSource: string;
  CurrentLT: string;
  DefaultLT: string;
  ExtendedLT: string;
  SiteCode: string;
  OnHandQuantity: string;
  Commit: string;
  FutureCommit: string;
  RoutingThreshold: string;
  NetATS: string;
  InboundSupply: string;
  SupplyETA: string;
  ShipmentMode: string;
}
export interface ExportReportData {
  Type: string;
  GroupName: string;
  Catalog: string;
  Sku: string;
  Part: string;
  Status: string;
  AggregateATS: string;
  SDSThreshold: string;
  NetSDS: string;
  InOversellThreshold: string;
  NetOversell: string;
  InOversoldThreshold: string;
  NetOversold: string;
  LTSource: string;
  CurrentLT: string;
  DefaultLT: string;
  ExtendedLT: string;
  SiteCode: string;
  OnHandQuantity: string;
  Commit: string;
  FutureCommit: string;
  RoutingThreshold: string;
  NetATS: string;
  InboundSupply: string;
  SupplyETA: string;
  ShipmentMode: string;
}

