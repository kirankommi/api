﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class IsgMaterial
    {
        public int RecordId { get; set; }
        public string Material { get; set; }
        public string MaterialDescription { get; set; }
    }
}
