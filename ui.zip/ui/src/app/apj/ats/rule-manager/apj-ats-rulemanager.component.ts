import { Component, ViewChild, ElementRef  } from '@angular/core';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ApjAtsFacadeService } from '@App/shared/apj-ats-facade.service';
import { LocalStorageService } from 'angular-2-local-storage';
import { NotifierService } from 'angular-notifier';
import { Applications, AtsApplicationConfigurationList, Filter } from './apj-ats-rulemanager.model';
import { ApjAtsRuleDetailComponent } from './apj-ats-ruledetail.component';
@Component({
  selector: 'app-apj-ats-rulemanager',
  templateUrl: './apj-ats-rulemanager.component.html',
  styleUrls: ['./apj-ats-rulemanager.component.css'],
})

export class ApjAtsRuleManagerComponent {
  apjAtsRuleManagerForm: FormGroup;
  isLoading: boolean = false;
  displayedColumns = ['Application', 'RuleName', 'ConfigurationValue', 'Status', 'Action'];
  private paginator: MatPaginator;
  //@ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatPaginator) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    this.dataSource.paginator = this.paginator;
  }
  private readonly notifier: NotifierService;
  applications: Applications[];
  atsApplicationConfigurationList: AtsApplicationConfigurationList[];
  configurationList: AtsApplicationConfigurationList[];
  filter: Filter = new Filter();
  appArray: any[];
  appselected: string = '';
  configIdsArray: any[];
  configIdsSelected: string = '';
  configValuesArray: any[];
  configValuesSelected: string = '';
  dataSource: MatTableDataSource<AtsApplicationConfigurationList>;
  hasRecords: boolean = false;
  @ViewChild('ruleDetails') public ruleDetail: ElementRef;
  @ViewChild(ApjAtsRuleDetailComponent) ruleDetailComponent: ApjAtsRuleDetailComponent; 
  IsRuleDetails: boolean = false;
  ruleList: AtsApplicationConfigurationList = new AtsApplicationConfigurationList();
  selectedApps: any[] = [];
  selectedConfigNames: any[] = [];
  selectedRules: any[] = [];


  constructor(private fb: FormBuilder,
    private _ApjAtsFacadeService: ApjAtsFacadeService,
    private _localStorageService: LocalStorageService,
    private notifierService: NotifierService) {
    this.apjAtsRuleManagerForm = fb.group({
      'ddlAppName': [null],
      'ddlRule': [null],
      'ddlConfigName': [null],
      'ddlStatus': [null],
      'chkStatus': [null],
    });
    this.notifier = notifierService;
  }

  ngOnInit() {
    this.isLoading = true;
    this._ApjAtsFacadeService.getApplications()
    .subscribe(data => {
      if (data.length > 0) {
        this.applications = data;
      }
      else {
        this.applications = [];
      }
      this.isLoading = false;
    },
    error => {
      this.notifier.notify('error', 'Error while fetching application list');
      this.isLoading = false;
    });
  }

  getRules() {
    this.isLoading = true;
    this.appArray = this.apjAtsRuleManagerForm.get('ddlAppName').value;
    this.appselected = "";
    this.appArray.forEach(apparr => {
      this.appselected = this.appselected.concat(apparr.toString() + ",");
    });

    this.filter.ApplicationIds = this.appselected;
    this.filter.ConfigIDs = null;
    this.filter.ConfigValues = null;
    this.filter.PageNumber = -1;
    this.filter.PageSize = 500;

    this.configurationList = [];
    this.apjAtsRuleManagerForm.get('ddlConfigName').setValue([]);

    this._ApjAtsFacadeService.getapplicationruleconfigurations(this.filter)
      .subscribe(data => {
        this.configurationList = data.atsApplicationConfigurationList;
        this.isLoading = false;
      },
        error => {
          this.notifier.notify('error', 'Error while fetching configuration list');
          this.isLoading = false;
        });
  }

  search() {
    this.isLoading = true;
    this.IsRuleDetails = false;
    this.configIdsArray = this.apjAtsRuleManagerForm.get('ddlRule').value;
    this.configIdsSelected = '';
    if (this.configIdsArray && this.configIdsArray.length > 0) {
      this.configIdsArray.forEach(configIdArray => {
        this.configIdsSelected = this.configIdsSelected.concat(configIdArray.toString() + ",");
      });
    }

    this.configValuesArray = this.apjAtsRuleManagerForm.get('ddlConfigName').value;
    this.configValuesSelected = '';
    if (this.configValuesArray && this.configValuesArray.length > 0) {
      this.configValuesArray.forEach(configValuesArray => {
        this.configValuesSelected = this.configValuesSelected.concat(configValuesArray.toString() + ",");
      });
    }

    this.filter.ApplicationIds = this.appselected;
    this.filter.ConfigIDs = this.configIdsSelected == '' ? null : this.configIdsSelected;
    this.filter.ConfigValues = this.configValuesSelected == '' ? null : this.configValuesSelected;;
    this.filter.Status = this.apjAtsRuleManagerForm.get('ddlStatus').value;
    this.filter.PageNumber = -1;
    this.filter.PageSize = 500;

    this._ApjAtsFacadeService.getapplicationruleconfigurations(this.filter)
      .subscribe(data => {
        this.atsApplicationConfigurationList = data.atsApplicationConfigurationList;
        this.dataSource = new MatTableDataSource(this.atsApplicationConfigurationList);
        this.dataSource.paginator = this.paginator;
        this.hasRecords = (this.dataSource != null && this.dataSource.data != null && this.dataSource.data.length > 0);
        this.isLoading = false;
      },
        error => {
          this.notifier.notify('error', 'Error while fetching Application configuration list');
          this.isLoading = false;
        });
  }

  selectAllaApps() {
    this.selectedApps = [];
    this.applications.forEach(app => {
      this.selectedApps.push(app.id);
    });
    this.apjAtsRuleManagerForm.get('ddlAppName').setValue(this.selectedApps);
    this.getRules();
  }

  deselectAllApps() {
    this.apjAtsRuleManagerForm.get('ddlAppName').setValue([]);
    this.getRules();
  }

  selectAllRules() {
    this.selectedRules = [];
    this.configurationList.forEach(configlist => {
      this.selectedRules.push(configlist.configID);
    });
    this.apjAtsRuleManagerForm.get('ddlRule').setValue(this.selectedRules);
  }

  deselectAllRules() {
    this.apjAtsRuleManagerForm.get('ddlRule').setValue([]);
    this.configIdsSelected = '';
  }

  selectAllConfigNames() {
    this.selectedConfigNames = [];
    this.configurationList.forEach(config => {
      this.selectedConfigNames.push(config.xmlConfigValue);
    });
    this.apjAtsRuleManagerForm.get('ddlConfigName').setValue(this.selectedConfigNames);
  }

  deselectAllConfigNames() {
    this.apjAtsRuleManagerForm.get('ddlConfigName').setValue([]);
    this.configValuesSelected = '';
  }

  addRow() {
    this.IsRuleDetails = true;
    setTimeout(() => {
      this.ruleDetail.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'start' });
      this.ruleList.operation = 'add';
      this.ruleDetailComponent.addRow();
    });
  }

  gotoParent() {
    setTimeout(() => {
      this.IsRuleDetails = false;
      this.ruleDetail.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'start' });
    });
  }

  save() {
    this.ruleDetailComponent.save();
  }

  edit(row) {
    this.ruleList.applicationID = row.applicationID;
    this.ruleList.applicationName = row.applicationName;
    this.ruleList.brandId = row.brandId;
    this.ruleList.brandName = row.brandName;
    this.ruleList.catalogId = row.catalogId;
    this.ruleList.catalogName = row.catalogName;
    this.ruleList.configID = row.configID;
    this.ruleList.configName = row.configName;
    this.ruleList.configValue = row.configValue;
    this.ruleList.familyId = row.familyId;
    this.ruleList.familyName = row.familyName;
    this.ruleList.isActive = row.isActive;
    this.ruleList.operation = row.operation;
    this.ruleList.preDefinitionCode = row.preDefinitionCode;
    this.ruleList.productLine = row.productLine;
    this.ruleList.productLineId = row.productLineId;
    this.ruleList.trimmedConfigName = row.trimmedConfigName;
    this.ruleList.userName = row.userName;
    this.ruleList.xmlConfigValue = row.xmlConfigValue;
    this.ruleList.operation = 'update';
    setTimeout(() => {
      this.ruleDetail.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'start' });
      this.ruleDetailComponent.editRow();
    });
    this.IsRuleDetails = true;
  }
}




