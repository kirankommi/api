export class AtsProductConfiguration {
  routingThreshold: number;
  lowThreshold: number;
  oversellThreshold: number;
  oversoldThreshold: number;
  bufferThreshold: number;
  displayLowInventory: boolean;
  includePreCheckout: boolean;
  includeCheckout: boolean;
  sellAction: boolean;
  fgascdhOverride: boolean;
  snPSCDHOverride: boolean;
}

export class PostData {
  DisplayLowInventory: boolean;
  IncludePreCheckout: boolean;
  IncludeCheckout: boolean;
  SellAction: boolean;
  FGASCDHOverride: boolean;
  UserName: string;
  UpdateAction: string;
  LowThreshold: number;
  BufferThreshold: number;
  OversellThreshold: number;
  OversoldThreshold: number;
}
