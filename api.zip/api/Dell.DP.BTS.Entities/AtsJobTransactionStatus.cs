﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsJobTransactionStatus
    {
        public string Name { get; set; }
        public string ReservationStatus { get; set; }
        public string LastUpdatedAt { get; set; }
        public string LastUpdatedBy { get; set; }
    }
}
