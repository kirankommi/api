export const environment = {
  production: false,
  ApjEmeaAtsApiUrl: 'https://dpemeaapjbtsapi-perf.ausvdc02.pcf.dell.com/api/'

};
