import { Component, OnInit,ViewChild } from '@angular/core';
// Must import to use Forms functionality  
import { MatButtonModule } from '@angular/material';
import {MatDialogModule,MatListModule,MatProgressBarModule} from '@angular/material'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { UploadService } from '../fileupload/apjFileUpload.service';
import { Router } from "@angular/router";
import { Global } from '@App/shared/global';


@Component({
  selector: 'app-fileupload',
  templateUrl: './fileupload.component.html',
  styleUrls: ['./fileupload.component.css']
})
export class FileuploadComponent implements OnInit {
   @ViewChild('file') file;
   outputPath:string = '';
  public files: Set<File> = new Set();
  templateURL: string; indLoading: boolean;
  constructor(public uploadService: UploadService, private router: Router) {
    this.templateURL = Global.UI_BASE_URL + 'src/assets/ATS_EMEA_Product_Management_Massupload_Template.xlsx';
  }

  ngOnInit() { }
debugger;
  progress;
  canBeClosed = true;
  primaryButtonText = 'Browse';
  showCancelButton = true;
  uploading = false;
  uploadSuccessful = false;
  uploadFileName:string

  onFilesAdded() {
  
    const files: { [key: string]: File } = this.file.nativeElement.files;
    this.files.clear();
    for (let key in files) {
       
        if (!isNaN(parseInt(key))) {
        this.files.add(files[key]);
      }
    }
  }
  gotoExcelDownloadPath()
  {
   // url = "http://localhost:4200/Content/Templates/APJ/ATS_APJ_Product_Management_Massupload_Template.xlsx";
    this.router.navigate(["http://localhost:4200/Content/Templates/APJ/ATS_APJ_Product_Management_Massupload_Template.xlsx"]).then( (e) => {
      if (e) {
        console.log("Navigation is successful!");
      } else {
        console.log("Navigation has failed!");
      }
    });
  }
  addFiles() {
     this.file.nativeElement.click();
  }
  uploadFiles(){

     // set the component state to "uploading"
     this.uploading = true;

     // start the upload and save the progress map
     return this.uploadService.upload(this.files);
     

  }
  downloadTemplate() {
    window.location.href = this.templateURL;
  }

}
