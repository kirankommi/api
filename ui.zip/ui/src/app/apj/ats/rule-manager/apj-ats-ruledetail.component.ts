import { Component, Input, ElementRef  } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormsModule, NgForm, FormControl} from '@angular/forms';
import { ApjAtsFacadeService } from '@App/shared/apj-ats-facade.service';
import { LocalStorageService } from 'angular-2-local-storage';
import { NotifierService } from 'angular-notifier';
import { ruleDetail } from './apj-ats-ruledetail.model';
import { Applications, AtsApplicationConfigurationList, AtsCatalog, Data, AtsProductInfo, AtsBrand } from './apj-ats-ruledetail.model';

@Component({
  selector: 'app-apj-ats-ruledetail',
  templateUrl: './apj-ats-ruledetail.component.html',
  styleUrls: ['./apj-ats-ruledetail.component.css'],
})

export class ApjAtsRuleDetailComponent {
  @Input() ruleList: AtsApplicationConfigurationList;
  apjAtsRuleDetailForm: FormGroup;
  isLoading: boolean = false;
  private readonly notifier: NotifierService;
  applications: Applications[];
  catalogs: AtsCatalog[];
  productLines: AtsProductInfo[];
  brands: AtsBrand[];
  selRegion: string = '';
  data: Data = new Data();
  regionCode: string = '';
  productLineId: number = 0;
  atsApplicationConfigurationList: AtsApplicationConfigurationList = new AtsApplicationConfigurationList();
  isDisabled: boolean = true;
  isDisabledContent: boolean = false;

  constructor(private fb: FormBuilder,
    private _ApjAtsFacadeService: ApjAtsFacadeService,
    private _localStorageService: LocalStorageService,
    private notifierService: NotifierService) {
    this.apjAtsRuleDetailForm = fb.group({
      ddlApp: new FormControl(''),
      txtRuleName: new FormControl(''),
      ddlCatalog: new FormControl(''),
      ddlProductLine: new FormControl(''),
      ddlBrand: new FormControl(''),
      ddlFamily: new FormControl(''),
      chkActive: new FormControl(''),
      txtApp: new FormControl(''),
    });
    this.notifier = notifierService;
  }

  ngOnInit() {
    //this.init();
  }

  init() {
    this.selRegion = this._localStorageService.get('selRegion');
    this.getApplications();
    this.getCatalogs();
  }

  getApplications() {
    this.isLoading = true;

    this._ApjAtsFacadeService.getApplications()
      .subscribe(data => {
        if (data.length > 0) {
          this.applications = data;
        }
        else {
          this.applications = [];
        }
        this.isLoading = false;
      },
        error => {
          this.notifier.notify('error', 'Error while fetching application list');
          this.isLoading = false;
        });
  }

  getCatalogs() {
    this.data.RegionId = this.selRegion;

    this.isLoading = true;
    this._ApjAtsFacadeService.getCatalog(this.data)
      .subscribe(data => {
        if (data.length > 0) {
          this.catalogs = data;

          //edit
          if (this.ruleList.operation == 'update') {
            this.catalogs.forEach(catalog => {
              if (catalog.regionCode == this.ruleList.catalogName) {
                this.apjAtsRuleDetailForm.get('ddlCatalog').setValue(catalog.regionCode);
                this.getProductLines();
              }
            })
          }
        }
        else {
          this.catalogs = [];
        }
        this.isLoading = false;
      },
        error => {
          this.notifier.notify('error', 'Error while fetching Catalog list');
          this.isLoading = false;
        });
  }

  getProductLines() {
    this.isLoading = true;
    this.regionCode = this.apjAtsRuleDetailForm.get('ddlCatalog').value

    this.catalogs.forEach(catalog => {
      if (catalog.regionCode == this.regionCode) {
        this._ApjAtsFacadeService.getProductLines(catalog.catalogId)
          .subscribe(data => {
            if (data.length > 0) {
              this.productLines = data;
              if (this.ruleList.operation == 'update') {
                this.getBrands();
              }
            }
            else {
              this.productLines = [];
            }
            this.isLoading = false;
          },
            error => {
              this.notifier.notify('error', 'Error while fetching Product Lines');
              this.isLoading = false;
            });
      }
    })
  }

  getBrands() {
    this.isLoading = true;
    this.productLineId = this.apjAtsRuleDetailForm.get('ddlProductLine').value
    this._ApjAtsFacadeService.getBrands(this.productLineId)
      .subscribe(data => {
        if (data.length > 0) {
          this.brands = data;
        }
        else {
          this.brands = [];
        }
        this.isLoading = false;
      },
        error => {
          this.notifier.notify('error', 'Error while fetching Brands');
          this.isLoading = false;
        });
  }

  save() {
    if (this.apjAtsRuleDetailForm.get('ddlApp').value == undefined
      || this.apjAtsRuleDetailForm.get('ddlApp').value == 0
      || this.apjAtsRuleDetailForm.get('ddlApp').value == null) {
      this.notifier.notify('error', 'Please select application');
      return;
    }
    if (this.apjAtsRuleDetailForm.get('txtRuleName').value == undefined
      || this.apjAtsRuleDetailForm.get('txtRuleName').value == ''
      || this.apjAtsRuleDetailForm.get('txtRuleName').value == null) {
      this.notifier.notify('error', 'Please enter rule name');
      return;
    }
    if (this.apjAtsRuleDetailForm.get('ddlCatalog').value == undefined
      || this.apjAtsRuleDetailForm.get('ddlCatalog').value == 0
      || this.apjAtsRuleDetailForm.get('ddlCatalog').value == null) {
      this.notifier.notify('error', 'Please select Catalog');
      return;
    }
    if (this.apjAtsRuleDetailForm.get('ddlProductLine').value == undefined
      || this.apjAtsRuleDetailForm.get('ddlProductLine').value == 0
      || this.apjAtsRuleDetailForm.get('ddlProductLine').value == null) {
      this.notifier.notify('error', 'Please select product line');
      return;
    }
    if (this.apjAtsRuleDetailForm.get('ddlBrand').value == undefined
      || this.apjAtsRuleDetailForm.get('ddlBrand').value == 0
      || this.apjAtsRuleDetailForm.get('ddlBrand').value == null) {
      this.notifier.notify('error', 'Please select brand name');
      return;
    }
    if (this.apjAtsRuleDetailForm.get('ddlFamily').value == undefined
      || this.apjAtsRuleDetailForm.get('ddlFamily').value == 0
      || this.apjAtsRuleDetailForm.get('ddlFamily').value == null) {
      this.notifier.notify('error', 'Please select family name');
      return;
    }

    this.isLoading = true;
    this.atsApplicationConfigurationList.applicationID = this.apjAtsRuleDetailForm.get('ddlApp').value;
    this.atsApplicationConfigurationList.preDefinitionCode = 'CUSTOMRULE';

    this.applications.forEach(app => {
      if (app.id == this.apjAtsRuleDetailForm.get('ddlApp').value) {
        this.atsApplicationConfigurationList.applicationName = app.name;
      }
    });

    this.catalogs.forEach(catalog => {
      if (catalog.regionCode == this.apjAtsRuleDetailForm.get('ddlCatalog').value) {
        this.atsApplicationConfigurationList.catalogId = catalog.catalogId;
      }
    })

    this.atsApplicationConfigurationList.catalogName = this.apjAtsRuleDetailForm.get('ddlCatalog').value;
    this.atsApplicationConfigurationList.configName = this.apjAtsRuleDetailForm.get('txtRuleName').value;
    this.atsApplicationConfigurationList.productLineId = this.apjAtsRuleDetailForm.get('ddlProductLine').value;

    this.productLines.forEach(productline => {
      if (productline.id == this.atsApplicationConfigurationList.productLineId) {
        this.atsApplicationConfigurationList.productLine = productline.name;
      }
    })

    this.atsApplicationConfigurationList.brandId = this.apjAtsRuleDetailForm.get('ddlBrand').value;

    if (this.apjAtsRuleDetailForm.get('ddlBrand').value === -9999) {
      this.atsApplicationConfigurationList.brandName = 'All';
    }
    else {
      this.brands.forEach(brand => {
        if (brand.id == this.apjAtsRuleDetailForm.get('ddlBrand').value) {
          this.atsApplicationConfigurationList.brandName = brand.name;
        }
      })
    }

    this.atsApplicationConfigurationList.familyId = -9999;
    this.atsApplicationConfigurationList.familyName = "All";
    this.atsApplicationConfigurationList.isActive = (this.apjAtsRuleDetailForm.get('chkActive').value != null
      && this.apjAtsRuleDetailForm.get('chkActive').value != undefined) ? this.apjAtsRuleDetailForm.get('chkActive').value : 0;
    this.atsApplicationConfigurationList.userName = "ASIA-PACIFIC\\Kiran_kumar_Kommi";
    this.atsApplicationConfigurationList.operation = this.ruleList.operation;

    this._ApjAtsFacadeService.updateapplicationruleconfiguration(this.atsApplicationConfigurationList)
      .subscribe(data => {

        if (this.ruleList.operation == 'update')
          this.notifier.notify('success', "Information updated successfully");
        else if (this.ruleList.operation == 'add')
          this.notifier.notify('success', "Information added successfully");

        this.isLoading = false;
      },
        error => {
          this.notifier.notify('error', 'Error while adding rule');
          this.isLoading = false;
        });
  }
  
  editRow() {
    this.init();
    this.apjAtsRuleDetailForm.get('txtApp').setValue(this.ruleList.applicationID + " - " + this.ruleList.applicationName);
    this.apjAtsRuleDetailForm.get('ddlApp').setValue(this.ruleList.applicationID);
    this.apjAtsRuleDetailForm.get('txtRuleName').setValue(this.ruleList.configName);
    this.apjAtsRuleDetailForm.get('ddlProductLine').setValue(this.ruleList.productLineId);
    this.apjAtsRuleDetailForm.get('ddlBrand').setValue(this.ruleList.brandId);
    this.apjAtsRuleDetailForm.get('ddlFamily').setValue(this.ruleList.familyId);
    this.apjAtsRuleDetailForm.get('chkActive').setValue(this.ruleList.isActive);
  }

  addRow() {
    this.productLines = [];
    this.brands = [];
    this.apjAtsRuleDetailForm.reset();
    this.init();
  }
}




