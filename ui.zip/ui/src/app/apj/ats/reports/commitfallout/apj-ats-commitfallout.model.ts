export class CommitFalloutRequest
{
    RegionId: string;
    PageNumber: number;
    PageSize: number;
}

export class CommitCalloutDetail
{
    sku: string;
    fga: string;
    orderNumber: string;
    quantity: string;
    countryCode: string;
    updatedDateTime: string;
    tieNumber: string;
    productType: string;
}

export class CommitCalloutDetailResponse
{
    commitCalloutDetails: CommitCalloutDetail[];
    recordCount: string;
}