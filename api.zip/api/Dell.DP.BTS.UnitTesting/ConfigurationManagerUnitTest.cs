﻿using Dell.DP.BTS.Entities;
using Dell.DP.BTS.API.Controllers;
using Dell.DP.BTS.DataServices;
using Dell.DP.BTS.BusinessServices;
using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    /// <summary>
    /// Summary description for ConfigurationManagerUnitTest
    /// </summary>
    
    public class ConfigurationManagerUnitTest:UnitTestInitializer
    {


        [Fact]
        public void GetApplicatioConfigurationsDataShouldReturnOKResult()
        {
            AtsAppConfigRequest items = new AtsAppConfigRequest()
            {
                ApplicationIds = "1",
                ConfigIDs = "488",
                ConfigValues = "488",
                Status = "1",
                PageNumber=1, 
                PageSize=50                  
            };
            var result = btsQueryController.GetApplicationConfigurations(items);
            Assert.NotNull(result);
        }
    }
}
