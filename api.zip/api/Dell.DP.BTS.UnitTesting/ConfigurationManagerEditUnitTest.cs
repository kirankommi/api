﻿using Dell.DP.BTS.Entities;
using Dell.DP.BTS.API.Controllers;
using Dell.DP.BTS.DataServices;
using Dell.DP.BTS.BusinessServices;
using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    /// <summary>
    /// Summary description for ConfigurationManagerUnitTest
    /// </summary>
    
    public class ConfigurationManagerEditUnitTest:UnitTestInitializer
    {


        [Fact]
        public void UpdateApplicatioConfigurationsDataShouldReturnOKResult()
        {
            var result = btsCommandController.UpdateApplicationConfiguration(atsApplicationConfigurations);
            Assert.NotNull(result);
        }
    }
}
