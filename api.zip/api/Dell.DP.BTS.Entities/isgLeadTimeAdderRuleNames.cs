﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{

    [ExcludeFromCodeCoverage]
    public class IsgLeadTimeAdderRuleNames
    {
        public int RuleId { get; set; }
        public string RuleName { get; set; }
    }
}
