import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LayoutModule } from '@angular/cdk/layout';
//import {GoTopButtonModule} from 'ng2-go-top-button';
import {BrowserAnimationsModule } from '@angular/platform-browser/animations';
// tslint:disable-next-line: max-line-length
import { ToolbarComponent } from './toolbar/toolbar.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { CustomtableComponent } from './customtable/customtable.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CollapseModule, PaginationModule, ModalModule } from 'ngx-bootstrap';
import { HeaderComponent } from './navigation/header/header.component';
import { SidenavListComponent } from './navigation/sidenav-list/sidenav-list.component';
import { LayoutComponent } from './layout/layout.component';
import { RoutingModule } from './routing/routing.module';
import { MaterialModule } from './material/material.module';
import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './america/dashboard/dashboard.component';
import 'hammerjs';
import { ApjAtsDashboardComponent } from './apj/ats/dashboard/apj-ats-dashboard.component';
import { MatToolbarModule, MatButtonModule, MatSidenavModule, MatIconModule, MatListModule } from '@angular/material';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { ProductManagementComponent } from './apj/ats/product-management/product-management.component'; 
import { ItemDetailsComponent } from './apj/ats/item-details/item-details.component';
import { ConfirmationDialogComponent } from './shared/confirmation-dialog/confirmation-dialog.component';
import { NotifierModule, NotifierOptions } from 'angular-notifier';
import { ApjAtsCountryComponent } from './apj/ats/country/apj-ats-country.component';
import { MatInputModule} from '@angular/material/input';
import { MatSelectModule} from '@angular/material/select';
import { MatPaginatorModule} from '@angular/material/paginator';
import { MatSnackBarModule} from '@angular/material/snack-bar';
import { CommitDetailsComponent } from './apj/ats/commit-details/commit-details.component';
import { ChartsModule } from 'ng2-charts'; 
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { FulfillmentCenterDetailsComponent } from './apj/ats/FulfillmentCenterDetails/fulfillment-center-details.component';
import { LocalStorageModule } from 'angular-2-local-storage';
import { ApjAtsCommitFalloutComponent } from './apj/ats/reports/commitfallout/apj-ats-commitfallout.component';
import { MassuploadProductManagementComponent } from './apj/ats/massupload/massupload-product-management/massupload-product-management.component';
import { MassuploadProductManagementService } from './apj/ats/massupload/massupload-product-management/massupload-product-management.service';
import { MassuploadLeadtimeManagementComponent } from './apj/ats/massupload/massupload-leadtime-management/massupload-leadtime-management.component';
import { MassuploadLeadTimeManagementService } from './apj/ats/massupload/massupload-leadtime-management/massupload-leadtime-management.service';
import { FileuploadComponent } from '@App/apj/ats/fileupload/fileupload.component';
import { AgedReportComponent } from './apj/ats/reports/aged-report/aged-report.component';
import { ApjAtsConfigMgmtComponent } from './apj/ats/configuration-management/apj-ats-configmgmt.component';
import { JobConfigurationComponent } from './apj/ats/job-configuration/job-configuration.component';
import { ApjAtsProductConfigComponent } from './apj/ats/product-config/apj-ats-product-config.component';
import { ApjAtsCatalogComponent } from './apj/ats/catalog/apj-ats-catalog.component';
import { InterceptorService } from '@Dataservice/dataservices/interceptor.service';
import { ItemExceptionReportComponent } from './apj/ats/reports/item-exception-report/item-exception-report.component';
import { ApjAtsRuleManagerComponent } from './apj/ats/rule-manager/apj-ats-rulemanager.component';
import { ApjAtsRuleDetailComponent } from './apj/ats/rule-manager/apj-ats-ruledetail.component';
import { CacheInterceptor } from '@Dataservice/dataservices/cacheInterceptor.service';

const customNotifierOptions: NotifierOptions = {
  position: {
    horizontal: {
      position: 'right',
      distance: 12
    },
    vertical: {
      position: 'bottom',
      distance: 20,
      gap: 10
    }
  },
  theme: 'material',
  behaviour: {
    autoHide: 900000,
    onClick: 'hide',
    onMouseover: 'pauseAutoHide',
    showDismissButton: true,
    stacking: 4
  },
  animations: {
    enabled: true,
    show: {
      preset: 'slide',
      speed: 300,
      easing: 'ease'
    },
    hide: {
      preset: 'fade',
      speed: 300,
      easing: 'ease',
      offset: 50
    },
    shift: {
      speed: 300,
      easing: 'ease'
    },
    overlap: 150
  }
};

@NgModule({
  declarations: [
    AppComponent,
    ToolbarComponent,
    CustomtableComponent,
    HeaderComponent,
    SidenavListComponent,
    LayoutComponent,
    HomeComponent,
    DashboardComponent,
    ApjAtsDashboardComponent,
    ProductManagementComponent,
    ItemDetailsComponent, 
    ConfirmationDialogComponent,
    ApjAtsCountryComponent,
    FulfillmentCenterDetailsComponent,
    CommitDetailsComponent,
    ApjAtsCommitFalloutComponent,
    MassuploadProductManagementComponent,
    MassuploadLeadtimeManagementComponent,
    FileuploadComponent,
    AgedReportComponent,
    ApjAtsConfigMgmtComponent,
    JobConfigurationComponent,
    ApjAtsProductConfigComponent,
    ApjAtsCatalogComponent,
    ItemExceptionReportComponent,
    ApjAtsRuleManagerComponent,
    ApjAtsRuleDetailComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    LayoutModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    CollapseModule,
    RoutingModule,
    MaterialModule,
    PaginationModule.forRoot(),
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    HttpModule,
    HttpClientModule,
    MatInputModule,
    MatSelectModule,
    MatPaginatorModule,
    MatSnackBarModule,
    NotifierModule.withConfig(customNotifierOptions),
    NgxChartsModule, ChartsModule, ModalModule.forRoot(),  
    LocalStorageModule.forRoot({
      prefix: 'my-app',
      storageType: 'localStorage'
    })
  ],
  entryComponents: [
    ConfirmationDialogComponent
  ],
  providers: [MassuploadProductManagementService, MassuploadLeadTimeManagementService,
    { provide: HTTP_INTERCEPTORS, useClass: CacheInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
