import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { ConfirmationDialogComponent, ConfirmDialogModel } from '@App/shared/confirmation-dialog/confirmation-dialog.component';
import { FormBuilder, FormGroup, Validators, FormsModule, NgForm } from '@angular/forms';
import { DataservicesProvider } from '@Dataservice/dataservices/dataservices';
import { ApjAtsFacadeService } from '@App/shared/apj-ats-facade.service';
import { Global } from '@App/shared/global';
import { ExcelService } from '@App/shared/exportservice';
import { MatPaginator, MatSort, MatTableDataSource, MatTooltip } from '@angular/material';
import { LocalStorageService } from 'angular-2-local-storage';
import { AtsCommitDetail, CommitItemDetail } from './commit-details.model';
import { SelectionModel } from '@angular/cdk/collections';
import { NotifierService } from 'angular-notifier';


@Component({
  selector: 'app-commit-details',
  templateUrl: './commit-details.component.html',
  styleUrls: ['./commit-details.component.css'],
  providers: [DataservicesProvider]
})
export class CommitDetailsComponent implements OnInit {
  @Input() commitItemDetail: CommitItemDetail;
  isCommitDetails: boolean = false;
  private notifier: NotifierService;
  
  parseData = [];

  atsCommitDetailList: AtsCommitDetail[];
  selection = new SelectionModel<AtsCommitDetail>(true, []);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  displayedColumns = ['Name', 'ShipToContactName', 'CustomerName', 'IRN', 'Segment', 'OrderNumber', 'TieNumber', 'Quantity', 'ReservedOn', 'CommitedOn', 'FulfillmentLocation',
    'GossStatus', 'Select'];
  userIsEmeaReadOnly: boolean = false;
  dataSource: MatTableDataSource<AtsCommitDetail>;
  pageIndex: number = 1;
  pageSize: number = 10;
  pageSizeOptions: number[] = [10, 20, 30, 50, 100];
  length: any;
  totalPageSize: any;
  indLoading: boolean = false;  
  getCommitDetailsExport: any;
  ErrorMsg: any;
  SuccessMsg: any;
  RegionId: string;
  productCountryId: number;
  sku: string;


  constructor(private fb: FormBuilder,
    private _ApjAtsFacadeService: ApjAtsFacadeService,
    private excelService: ExcelService,
    private _localStorageService: LocalStorageService,
    notifier: NotifierService) {
    this.RegionId = this._localStorageService.get('selRegion');
    this.productCountryId = this._localStorageService.get('productCountryId');
    this.sku = this._localStorageService.get('sku');
    this.notifier = notifier;
  }

  ngOnInit() {
    this.init();
  }

  init() {
    this._ApjAtsFacadeService.getCommitDetails(this.productCountryId)
      .subscribe(data => {
        this.selection.clear();
        this.atsCommitDetailList = data;//this.mockData;
        this.dataSource = new MatTableDataSource(this.atsCommitDetailList);
        console.log(this.dataSource);
        //this.dataSource.paginator = this.paginator;
        this.isCommitDetails = true;
      })
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /* Export to Excel functionality */
  exportCommitDetails() {
    this.indLoading = true;
    this._ApjAtsFacadeService.exportCommitDetails(this.productCountryId)
      .subscribe(data => {
        this.selection.clear();
        this.atsCommitDetailList = data;

        this.atsCommitDetailList.map(item => {
          return {
            'Country Name': item.name,
            'Ship to Contact': item.shipToContactName,
            'Customer Name': item.customerName,
            'IRN': item.irn,
            'Segment': item.segment,
            'Order Number': item.orderNumber,
            'Tie Number': item.tieNumber,
            'Quantity': item.quantity,
            'Reservation On': item.reservationId,
            'Comitted On': item.commitedOn,
            'Fulfilled From': item.fulfillmentLocation,
            'Order Status': item.gossStatus
          }
        }).forEach(item => this.parseData.push(item));

        this.excelService.exportAsExcelFile(this.parseData, 'CommitDetailsReport');

        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }


  cancelCommittedOrder() {
    if (this.selection.selected && this.selection.selected.length == 0) {
      this.notifier.notify('warn', 'No order selected for cancel.');
      return;
    }

    this.indLoading = true;

    var request = [];
    for (var i = 0; i < this.selection.selected.length; i++) {
      var r = {
        "ReservationId": this.selection.selected[i].reservationId,
        "FulfillWarning": this.selection.selected[i].fulfillWarning,
        "CancelWarning": this.selection.selected[i].cancelWarning,
        "UpdatedBy": 'jitendra_kumar_pradh'
      }
      request.push(r);
    }

    if (request.length > 0) {
      this._ApjAtsFacadeService.cancelCommitOrder(request)
        .subscribe(data => {
          this.notifier.notify('success', 'Cancelled Commit');
          this.init();
          this.indLoading = false;
        },
          error => { this.ErrorMsg = <any>error; this.indLoading = false; });

    }
    else {
      this.notifier.notify('warn', 'Please select item');

    }
  }

  markAsFulfill() {

    if (this.selection.selected && this.selection.selected.length == 0) {
      this.notifier.notify('warn', 'No order selected for Mark as Fulfilled.');
      return;
    }

    this.indLoading = true;

    var request = [];
    for (var i = 0; i < this.selection.selected.length; i++) {
      var r = {
        "ReservationId": this.selection.selected[i].reservationId,
        "FulfillWarning": this.selection.selected[i].fulfillWarning,
        "CancelWarning": this.selection.selected[i].cancelWarning,
        "UpdatedBy": 'jitendra_kumar_pradh'
      }
      request.push(r);
    }

    if (request.length > 0) {
      this._ApjAtsFacadeService.markAsFulfill(request)
        .subscribe(data => {
          this.notifier.notify('success', 'Fulfilled Commit');
          this.init();
          this.indLoading = false;
        },
          error => { this.ErrorMsg = <any>error; this.indLoading = false; });

    }
    else {
      this.notifier.notify('warn', 'Please select item');

    }
  }
}

