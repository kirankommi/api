﻿using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    /// <summary>
    /// Summary description for CountryManagementUnitTest
    /// </summary>
    
    public class FulfillmentCenterUnitTest:UnitTestInitializer
    {

        [Fact]
        public void GetFulfillmentCentersDataShouldReturnOKResult()
        {
            int region = 3;
            var result = btsQueryController.GetFulfillmentLocation(region);
            Assert.NotNull(result);
        }

        [Fact]
        public void GetCountriesByCodeDataShouldReturnOKResult()
        {
            int region = 3;
            string code = "STKCOV";
            var result = btsQueryController.GetFulfillmentLocation(region);
            Assert.NotNull(result);
        }

        [Fact]
        public void GetCountriesByNameDataShouldReturnOKResult()
        {
            int region = 3;
            string name = "COVENTRY";
            var result = btsQueryController.GetFulfillmentLocation(region);
            Assert.NotNull(result);
        }
    }
}
