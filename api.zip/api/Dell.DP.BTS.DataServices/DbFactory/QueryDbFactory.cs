﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Diagnostics.CodeAnalysis;

namespace Dell.DP.BTS.DataServices.DbFactory
{
    [ExcludeFromCodeCoverage]
    public class QueryDbFactory : IDbFactory
    {
        #region Private Members

        private string _connectionString { get; set; }
        #endregion
        #region Constructor
        public QueryDbFactory(string connectionString)
        {
            this._connectionString = connectionString;
        }
        #endregion
        #region Public Members
        public Database Database
        {
            get
            {
                return new Microsoft.Practices.EnterpriseLibrary.Data.Sql.SqlDatabase(_connectionString);

            }
        }
        #endregion

    }
}
