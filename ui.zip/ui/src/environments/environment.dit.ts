export const environment = {
  production: false,
  ApjEmeaAtsApiUrl: 'https://dpemeaapjbtsapi-dit.ausvdc02.pcf.dell.com/api/'

};
