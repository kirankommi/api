﻿using Dell.DP.BTS.BusinessServices.CommandBusiness.Interfaces;
using Dell.DP.BTS.DataServices.CommandRepository.Interfaces;
using Dell.DP.BTS.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Dell.DP.BTS.BusinessServices.CommandBusiness.Implementation
{
    public class BtsCommandBusiness : IBtsCommandBusiness
    {

        #region Private Members
        /// <summary>
        /// This property can be used bts inventory Command business object as dynamic
        /// </summary>
        private readonly IBtsCommandRepository _btsCommandRepository;
        public DbCommandResult DbCommandResult { get; private set; }
        #endregion

        #region Constructor

        /// <summary>
        /// Paramterised constructor with inventory Command business object as parameter 
        /// </summary>
        /// <param name="inventoryCommandBusiness"></param>
        public BtsCommandBusiness(IBtsCommandRepository btsCommandRepository) => _btsCommandRepository = btsCommandRepository;

        #endregion

        #region Public Get routes
        /// <summary>
        /// This end point can be used to test the API health
        /// </summary>
        /// <returns>boolean value</returns>
        public bool IsAlive()
        {
            return true;
        }

        public void UpdateCatalog(AtsCatalog atsCatalog)
        {
             _btsCommandRepository.UpdateCatalog(atsCatalog);
            this.DbCommandResult = _btsCommandRepository.DbCommandResult;
        }
        public void DeleteCatalog(AtsCatalog Item)
        {
            _btsCommandRepository.DeleteCatalog(Item);
            this.DbCommandResult = _btsCommandRepository.DbCommandResult;
        }
        public void UpdateCountry(AtsCountry atsCountry)
        {
             _btsCommandRepository.UpdateCountry(atsCountry);
            this.DbCommandResult = _btsCommandRepository.DbCommandResult;
        }
        public void UpdateApplicationConfiguration(AtsApplicationConfiguration Item)
        {
             _btsCommandRepository.UpdateApplicationConfiguration(Item);
            this.DbCommandResult = _btsCommandRepository.DbCommandResult;
        }
        public void UpdateProductConfiguration(AtsProductConfiguration productConfig)
        {
             _btsCommandRepository.UpdateProductConfiguration(productConfig);
            this.DbCommandResult = _btsCommandRepository.DbCommandResult;
        }
        public void UpdateProductInformation(AtsProductInfoAddUpdateRequest prodRequest)
        {
            _btsCommandRepository.UpdateProductInformation(prodRequest);
            this.DbCommandResult = _btsCommandRepository.DbCommandResult;
        }
        public void UpdateContinueToSell(AtsItemDetail atsItemDetail)
        {
             _btsCommandRepository.UpdateContinueToSell(atsItemDetail);
            this.DbCommandResult = _btsCommandRepository.DbCommandResult;
        }
        public void UpdateDisplayLowInventory(AtsItemDetail atsItemDetail)
        {
             _btsCommandRepository.UpdateDisplayLowInventory(atsItemDetail);
            this.DbCommandResult = _btsCommandRepository.DbCommandResult;
        }
        public void UpdateIsActive(AtsItemDetail atsItemDetail)
        {
             _btsCommandRepository.UpdateIsActive(atsItemDetail);
            this.DbCommandResult = _btsCommandRepository.DbCommandResult;
        }
        public void UpdateLeadTime(AtsItemDetail AtsDetail)
        {
             _btsCommandRepository.UpdateLeadTime(AtsDetail);
            this.DbCommandResult = _btsCommandRepository.DbCommandResult;
        }
        public void UpdateFulfillmentLocation(List<AtsSite> sites)
        {
             _btsCommandRepository.UpdateFulfillmentLocation(sites);
            this.DbCommandResult = _btsCommandRepository.DbCommandResult;
        }
        public void UpdateFulfillmentLocations(AtsSite sites)
        {
             _btsCommandRepository.UpdateFulfillmentLocations(sites);
            this.DbCommandResult = _btsCommandRepository.DbCommandResult;
        }
        public void MarkAsFulfill(List<AtsCommitDetail> Items)
        {
             _btsCommandRepository.MarkAsFulfill(Items);
            this.DbCommandResult = _btsCommandRepository.DbCommandResult;
        }
        public void CancelReservation(List<AtsCommitDetail> Items)
        {
            _btsCommandRepository.CancelReservation(Items);
            this.DbCommandResult = _btsCommandRepository.DbCommandResult;
        }
        public void UpdateThreshold(AtsItemDetail AtsDetail)
        {
             _btsCommandRepository.UpdateThreshold(AtsDetail);
            this.DbCommandResult = _btsCommandRepository.DbCommandResult;
        }

        #endregion
    }
}
