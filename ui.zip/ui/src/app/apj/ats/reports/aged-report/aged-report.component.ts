import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, NgForm, FormsModule} from '@angular/forms';
import { DataservicesProvider } from '@Dataservice/dataservices/dataservices';
import { ApjAtsFacadeService } from '@App/shared/apj-ats-facade.service';
import { Global } from '@App/shared/global';
import { ExcelService } from '@App/shared/exportservice';
import { MatPaginator, MatSort, MatTableDataSource, MatTooltip, fadeInContent } from '@angular/material';
import { LocalStorageService } from 'angular-2-local-storage';
import { ReportData, AgedReportRequest, ExportReportData } from './aged-report.model'
import { ProductManagementService } from '@App/apj/ats/product-management/product-management.service'
import { NotifierService } from 'angular-notifier';
import { debug } from 'util';
@Component({
  selector: 'app-aged-report',
  templateUrl: './aged-report.component.html',
  styleUrls: ['./aged-report.component.css']
})
export class AgedReportComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;

  //Variable Declarations
  displayedColumns = ['productType', 'country', 'sku', 'fga', 'orderQuantity', 'orderNumber', 'statusAge'];
  RegionId: number;
  apjAgedReportForm: FormGroup;
  dataSource: MatTableDataSource<ReportData>;
  pageIndex: number = 1;
  pageSize: number = 10;
  pageSizeOptions: number[] = [10, 20, 30, 50, 100];
  length: any;
  totalPageSize: any;
  IsCommitDetails: boolean = false;
  indLoading: boolean = false;
  Countries: any;
  SelCountries: any;
  LocationCodes: any;
  ProductTypes: any;
  getFGADetails: any;
  exportData: ExportReportData[];
  parseData = [];
  ErrorMsg: any;
  SuccessMsg: any;
  agedReportRequest: AgedReportRequest = new AgedReportRequest();
  haRecords: boolean = false;
  notifier: NotifierService;
  isValid: Boolean = false;
  //Constructor
  constructor(private _formBuilder: FormBuilder
    , private _dataservicesProvider: DataservicesProvider
    , private _excelService: ExcelService
    , private _ApjAtsFacadeService: ApjAtsFacadeService
    , private _localStorageService: LocalStorageService
    , private _productManagementService: ProductManagementService
    , private _notifier: NotifierService) {

    this.RegionId = this._localStorageService.get('selRegion');

    // To initialize FormGroup , Validators.required 
    this.apjAgedReportForm = _formBuilder.group({
      'ddlCountry': [null],
      //'ddlSite': [null],
      'ddlType': [null],
      'txtStatusAge': [null],
      'txtPart': [null]
    });

    this.notifier = _notifier;

  }

  //Init
  ngOnInit() {
    this.RegionId = this._localStorageService.get('selRegion');
    this.loadCountries(this.RegionId);
    //this.loadLocationCode(this.RegionId);
    this.loadProductType();
    this.Search(this.apjAgedReportForm.value, true)
  }

  // Country
  loadCountries(_regionId): void {
    this.indLoading = true;
    this._ApjAtsFacadeService.loadCountries(_regionId)
      .subscribe(countries => {
        this.Countries = countries;
        this.removeAllCountries();
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }

  removeAllCountries() {
    let filteredCountries = this.Countries.filter(function (pc) {
      if (pc.countryName.toUpperCase() != "ALL COUNTRIES") {
        return pc;
      }
    });
    this.Countries = filteredCountries;
  }

  // Site
  //loadLocationCode(_regionId): void {
  //  this.indLoading = true;
  //  this._ApjAtsFacadeService.loadLocationCode(_regionId)
  //    .subscribe(locationcodes => {
  //      this.LocationCodes = locationcodes;
  //      this.indLoading = false;
  //    },
  //      error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  //}

  // ProductType
  loadProductType(): void {
    this.indLoading = true;
    this._productManagementService.GetProductTypes()
      .subscribe(productTypes => {
        this.ProductTypes = productTypes;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }


  getNext(event):void {
    debugger;
    this.length = length;
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.Search(this.apjAgedReportForm.value,false);
  }

  doFilter(value: string) {
    value = value.trim();
    value = value.toLowerCase();
    this.dataSource.filter = value;
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
    debugger;

    this.haRecords = this.dataSource.filteredData.length > 0;
  }

  validateSearch(obj) {

    //Country
    this.agedReportRequest.CountryIds = '-1';
    if (!(obj.ddlCountry === '' || obj.ddlCountry === 'undefined' || obj.ddlCountry === null)) {
      this.SelCountries = this.apjAgedReportForm.get('ddlCountry').value;
      if (this.SelCountries && this.SelCountries.length > 0) {
        this.agedReportRequest.CountryIds = "";
        this.SelCountries.forEach(item => {
          this.agedReportRequest.CountryIds = this.agedReportRequest.CountryIds.concat(item.toString() + ",");
        });
      }
    }

    //Site
    //this.agedReportRequest.SiteIds = '-1';
    //if (!(obj.ddlSite === '' || obj.ddlSite === 'undefined' || obj.ddlSite === null)) {
    //  this.agedReportRequest.SiteIds = obj.ddlSite;
    //}

    this.agedReportRequest.SiteIds = "-1";

    //Product Type
    this.agedReportRequest.ProductTypeIds = '-1';
    if (!(obj.ddlType === '' || obj.ddlType === 'undefined' || obj.ddlType === null)) {
      this.agedReportRequest.ProductTypeIds = obj.ddlType;
    }
    debugger;
    //Age 
    this.agedReportRequest.StatusAge = 6;
    if (!(obj.txtStatusAge === '' || obj.txtStatusAge === 'undefined' || obj.txtStatusAge === null)) {
      if (obj.txtStatusAge < 6) {
        this.notifier.notify('error', 'Status Age value should be greater than 5');
        return false;
      } else {
        this.agedReportRequest.StatusAge = obj.txtStatusAge;
      }

    }

    //Part
    this.agedReportRequest.Parts = '-1';
    if (!(obj.txtPart === '' || obj.txtPart === 'undefined' || obj.txtPart === null)) {
      this.agedReportRequest.Parts = obj.txtPart;
    }

    return true;
  }
  Search(obj, resetpageIndex) {
    debugger;
    this.isValid = this.validateSearch(obj);
    if (!this.isValid)
      return;
    if (resetpageIndex==true)
      this.pageIndex = 1;
       
    //Page Number
    this.agedReportRequest.PageNumber = this.pageIndex;

    //Page Number
    this.agedReportRequest.PageSize = this.pageSize;

    this.agedReportRequest.RegionId = this.RegionId;

    this.haRecords = false;
    this.indLoading = true;

    this._ApjAtsFacadeService.agedReportSearch(this.agedReportRequest)
      .subscribe(data => {
        this.dataSource = new MatTableDataSource<ReportData>(data['orderDetailsList']);
        this.totalPageSize = data['recordCount'];
        this.haRecords = (this.dataSource != null && this.dataSource.data != null && this.dataSource.data.length > 0);
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }

  exportToExcel() {
    this.parseData = [];
    this.exportData.map(item => {
      return {
        'Product Type': item.productType,
        'Country': item.country,       
        //'Site': item.siteName,
        'SKU': item.sku,
        'Part Number / CFG': item.fga,
        'Order Quantity': item.orderQuantity,
        'Order Number': item.orderNumber,
        'Status Age (In Days)':item.statusAge
      }
    }).forEach(item => this.parseData.push(item));

    this._excelService.exportAsExcelFile(this.parseData, 'Aged_Report');
  }
  exportAsXLSX(obj): void {
    this.isValid = this.validateSearch(obj);
    if (!this.isValid)
      return;
    debugger;
    //Page Number
    this.agedReportRequest.PageNumber = 1;

    //Page Number
    this.agedReportRequest.PageSize = -1;

    this.indLoading = true;
    this._ApjAtsFacadeService.agedReportSearch(this.agedReportRequest)
      .subscribe(data => {
        this.exportData = data.orderDetailsList;
        this.exportToExcel();
        this.indLoading = false;
      },
      error => { this.ErrorMsg = <any>error; this.indLoading = false; });

  }

  selectAllCountry() {
    this.SelCountries = [];
    this.Countries.forEach(app => {
      this.SelCountries.push(app.id);
    });
    this.apjAgedReportForm.get('ddlCountry').setValue(this.SelCountries);
  }

  deselectAllCountry() {
    this.SelCountries = [];
    this.apjAgedReportForm.get('ddlCountry').setValue(this.SelCountries);
  }


}
