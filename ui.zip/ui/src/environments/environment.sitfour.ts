export const environment = {
  production: false,
  ApjEmeaAtsApiUrl: 'https://dpemeaapjbtsapi-g4.ausvdc02.pcf.dell.com/api/'

};
