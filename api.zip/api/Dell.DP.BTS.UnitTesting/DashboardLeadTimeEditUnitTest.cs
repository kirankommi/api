﻿using Dell.DP.BTS.Entities;
using Dell.DP.BTS.API.Controllers;
using Dell.DP.BTS.DataServices;
using Dell.DP.BTS.BusinessServices;
using Xunit;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.AspNetCore.Mvc;

namespace Dell.DP.BTS.UnitTesting
{
    
    public class DashboardLeadTimeEditUnitTest : UnitTestInitializer
    {

        [Fact]

        public void UpdatingStandardLeadTimeWithAValidValue()
        {
            AtsItemDetail _atsItemDetail = new AtsItemDetail()
            {
                Sku = "998-BQVX",
                ProductCountryId = 85067,
                DefaultLT = 1,
                ExtendedLeadTime = 9,
                AutoXltIncrement = 3,
                UpdatedBy = "Jitendra_kumar_pradh",
                Active=false,
                AllowAutoXLT=false,
                ATS=null,
                AvailabletoSellQuantiry=1,
                Brand=null,
                Cart=null,
                Catalog=null,
                CatalogGroup=null,
                CatalogGroupId=null,
                CatalogId=null,
                Checkout=null,
                Commit = null,
                ContinueToSell = false,
                CountDown = null,
                CreatedBy = null,
                CreatedOn = System.DateTime.Now,
                Description = null,
                DisplayLowInventry = false,
                ExtendedLeadTimeThresold = 1,
                FutureCommit = null,
                Id=1,
                IsEligibleForSmartLogo=false,
                IsFirstTrackEligible=false,
                IsSDSEnabledCountry=false,
                ItemInventryStatus = null,
                LeadTime = null,
                LowThreshold=1,
                LTSource = null,
                OfferType = null,
                OnHand = null,
                OutOfStockThresold=1,
                Part = null,
                ProductCountryIds = null,
                SameDayShippingThreshold=1,
                SDS=false,
                SDSShippingId=1,
                Status = null,
                StatusId=1,
                StdLeadTime = null,
                Threshold = null,
                Type = null,
                UpdatedOn=System.DateTime.Now
            };
            var result = btsCommandController.updateLeadTime(_atsItemDetail);
            Asserts(result);
        }

        [Fact]

        public void ExtendedLeadTimeWhichAlsoGreaterThanTheStandardLeadTime()
        {
            AtsItemDetail _atsItemDetail = new AtsItemDetail()
            {
                Sku = "998-BQVX",
                ProductCountryId = 85067,
                DefaultLT = 2,
                ExtendedLeadTime = 9,
                AutoXltIncrement = 3,
                UpdatedBy = "Jitendra_kumar_pradh",
                Active = false,
                AllowAutoXLT = false,
                ATS = null,
                AvailabletoSellQuantiry = 1,
                Brand = null,
                Cart = null,
                Catalog = null,
                CatalogGroup = null,
                CatalogGroupId = null,
                CatalogId = null,
                Checkout = null,
                Commit = null,
                ContinueToSell = false,
                CountDown = null,
                CreatedBy = null,
                CreatedOn = System.DateTime.Now,
                Description = null,
                DisplayLowInventry = false,
                ExtendedLeadTimeThresold = 1,
                FutureCommit = null,
                Id = 1,
                IsEligibleForSmartLogo = false,
                IsFirstTrackEligible = false,
                IsSDSEnabledCountry = false,
                ItemInventryStatus = null,
                LeadTime = null,
                LowThreshold = 1,
                LTSource = null,
                OfferType = null,
                OnHand = null,
                OutOfStockThresold = 1,
                Part = null,
                ProductCountryIds = null,
                SameDayShippingThreshold = 1,
                SDS = false,
                SDSShippingId = 1,
                Status = null,
                StatusId = 1,
                StdLeadTime = null,
                Threshold = null,
                Type = null,
                UpdatedOn = System.DateTime.Now
            };
            var result = btsCommandController.updateLeadTime(_atsItemDetail);
            Asserts(result);
        }

        [Fact]

        public void StandardLeadTimeAtTheSKUIsInOKLowSDSThresholdStaus()
        {
            AtsItemDetail _atsItemDetail = new AtsItemDetail()
            {
                Sku = "998-BQVX",
                ProductCountryId = 85067,
                DefaultLT = 2,
                ExtendedLeadTime = 8,
                AutoXltIncrement = 3,
                UpdatedBy = "Jitendra_kumar_pradh",
                Active = false,
                AllowAutoXLT = false,
                ATS = null,
                AvailabletoSellQuantiry = 1,
                Brand = null,
                Cart = null,
                Catalog = null,
                CatalogGroup = null,
                CatalogGroupId = null,
                CatalogId = null,
                Checkout = null,
                Commit = null,
                ContinueToSell = false,
                CountDown = null,
                CreatedBy = null,
                CreatedOn = System.DateTime.Now,
                Description = null,
                DisplayLowInventry = false,
                ExtendedLeadTimeThresold = 1,
                FutureCommit = null,
                Id = 1,
                IsEligibleForSmartLogo = false,
                IsFirstTrackEligible = false,
                IsSDSEnabledCountry = false,
                ItemInventryStatus = null,
                LeadTime = null,
                LowThreshold = 1,
                LTSource = null,
                OfferType = null,
                OnHand = null,
                OutOfStockThresold = 1,
                Part = null,
                ProductCountryIds = null,
                SameDayShippingThreshold = 1,
                SDS = false,
                SDSShippingId = 1,
                Status = null,
                StatusId = 1,
                StdLeadTime = null,
                Threshold = null,
                Type = null,
                UpdatedOn = System.DateTime.Now
            };
            var result = btsCommandController.updateLeadTime(_atsItemDetail);
            Asserts(result);
        }

        [Fact]

        public void StandardLeadTimeAtTheSKUIsInXLTOOSThresholdStaus()
        {
            AtsItemDetail _atsItemDetail = new AtsItemDetail()
            {
                Sku = "998-BQVX",
                ProductCountryId = 85067,
                DefaultLT = 1,
                ExtendedLeadTime = 8,
                AutoXltIncrement = 3,
                UpdatedBy = "Jitendra_kumar_pradh",
                Active = false,
                AllowAutoXLT = false,
                ATS = null,
                AvailabletoSellQuantiry = 1,
                Brand = null,
                Cart = null,
                Catalog = null,
                CatalogGroup = null,
                CatalogGroupId = null,
                CatalogId = null,
                Checkout = null,
                Commit = null,
                ContinueToSell = false,
                CountDown = null,
                CreatedBy = null,
                CreatedOn = System.DateTime.Now,
                Description = null,
                DisplayLowInventry = false,
                ExtendedLeadTimeThresold = 1,
                FutureCommit = null,
                Id = 1,
                IsEligibleForSmartLogo = false,
                IsFirstTrackEligible = false,
                IsSDSEnabledCountry = false,
                ItemInventryStatus = null,
                LeadTime = null,
                LowThreshold = 1,
                LTSource = null,
                OfferType = null,
                OnHand = null,
                OutOfStockThresold = 1,
                Part = null,
                ProductCountryIds = null,
                SameDayShippingThreshold = 1,
                SDS = false,
                SDSShippingId = 1,
                Status = null,
                StatusId = 1,
                StdLeadTime = null,
                Threshold = null,
                Type = null,
                UpdatedOn = System.DateTime.Now
            };
            var result = btsCommandController.updateLeadTime(_atsItemDetail);
            Asserts(result);
        }

        [Fact]

        public void ExtendedLeadTimeAtTheSKUIsInOKLowSDSThresholdStaus()
        {
            AtsItemDetail _atsItemDetail = new AtsItemDetail()
            {
                Sku = "998-BQVX",
                ProductCountryId = 85067,
                DefaultLT = 1,
                ExtendedLeadTime = 7,
                AutoXltIncrement = 3,
                UpdatedBy = "Jitendra_kumar_pradh",
                Active = false,
                AllowAutoXLT = false,
                ATS = null,
                AvailabletoSellQuantiry = 1,
                Brand = null,
                Cart = null,
                Catalog = null,
                CatalogGroup = null,
                CatalogGroupId = null,
                CatalogId = null,
                Checkout = null,
                Commit = null,
                ContinueToSell = false,
                CountDown = null,
                CreatedBy = null,
                CreatedOn = System.DateTime.Now,
                Description = null,
                DisplayLowInventry = false,
                ExtendedLeadTimeThresold = 1,
                FutureCommit = null,
                Id = 1,
                IsEligibleForSmartLogo = false,
                IsFirstTrackEligible = false,
                IsSDSEnabledCountry = false,
                ItemInventryStatus = null,
                LeadTime = null,
                LowThreshold = 1,
                LTSource = null,
                OfferType = null,
                OnHand = null,
                OutOfStockThresold = 1,
                Part = null,
                ProductCountryIds = null,
                SameDayShippingThreshold = 1,
                SDS = false,
                SDSShippingId = 1,
                Status = null,
                StatusId = 1,
                StdLeadTime = null,
                Threshold = null,
                Type = null,
                UpdatedOn = System.DateTime.Now
            };
            var result = btsCommandController.updateLeadTime(_atsItemDetail);
            Asserts(result);
        }

        [Fact]

        public void ExtendedLeadTimeAtTheSKUIsInXLTOOSThresholdStaus()
        {
            AtsItemDetail _atsItemDetail = new AtsItemDetail()
            {
                Sku = "998-BQVX",
                ProductCountryId = 85067,
                DefaultLT = 3,
                ExtendedLeadTime = 9,
                AutoXltIncrement = 3,
                UpdatedBy = "Jitendra_kumar_pradh",
                Active = false,
                AllowAutoXLT = false,
                ATS = null,
                AvailabletoSellQuantiry = 1,
                Brand = null,
                Cart = null,
                Catalog = null,
                CatalogGroup = null,
                CatalogGroupId = null,
                CatalogId = null,
                Checkout = null,
                Commit = null,
                ContinueToSell = false,
                CountDown = null,
                CreatedBy = null,
                CreatedOn = System.DateTime.Now,
                Description = null,
                DisplayLowInventry = false,
                ExtendedLeadTimeThresold = 1,
                FutureCommit = null,
                Id = 1,
                IsEligibleForSmartLogo = false,
                IsFirstTrackEligible = false,
                IsSDSEnabledCountry = false,
                ItemInventryStatus = null,
                LeadTime = null,
                LowThreshold = 1,
                LTSource = null,
                OfferType = null,
                OnHand = null,
                OutOfStockThresold = 1,
                Part = null,
                ProductCountryIds = null,
                SameDayShippingThreshold = 1,
                SDS = false,
                SDSShippingId = 1,
                Status = null,
                StatusId = 1,
                StdLeadTime = null,
                Threshold = null,
                Type = null,
                UpdatedOn = System.DateTime.Now
            };
            var result = btsCommandController.updateLeadTime(_atsItemDetail);
            Asserts(result);
        }

        [Fact]

        public void ExtendedLeadTimeIsGreaterThanOrEqualToTheStandardLeadTime()
        {
            AtsItemDetail _atsItemDetail = new AtsItemDetail()
            {
                Sku = "998-BQVX",
                ProductCountryId = 85067,
                DefaultLT = 9,
                ExtendedLeadTime = 9,
                AutoXltIncrement = 3,
                UpdatedBy = "Jitendra_kumar_pradh",
                Active = false,
                AllowAutoXLT = false,
                ATS = null,
                AvailabletoSellQuantiry = 1,
                Brand = null,
                Cart = null,
                Catalog = null,
                CatalogGroup = null,
                CatalogGroupId = null,
                CatalogId = null,
                Checkout = null,
                Commit = null,
                ContinueToSell = false,
                CountDown = null,
                CreatedBy = null,
                CreatedOn = System.DateTime.Now,
                Description = null,
                DisplayLowInventry = false,
                ExtendedLeadTimeThresold = 1,
                FutureCommit = null,
                Id = 1,
                IsEligibleForSmartLogo = false,
                IsFirstTrackEligible = false,
                IsSDSEnabledCountry = false,
                ItemInventryStatus = null,
                LeadTime = null,
                LowThreshold = 1,
                LTSource = null,
                OfferType = null,
                OnHand = null,
                OutOfStockThresold = 1,
                Part = null,
                ProductCountryIds = null,
                SameDayShippingThreshold = 1,
                SDS = false,
                SDSShippingId = 1,
                Status = null,
                StatusId = 1,
                StdLeadTime = null,
                Threshold = null,
                Type = null,
                UpdatedOn = System.DateTime.Now
            };
            var result = btsCommandController.updateLeadTime(_atsItemDetail);
            Asserts(result);
        }

        public void Asserts(IActionResult result)
        {
            Assert.NotNull(result);
        }

    }
}

