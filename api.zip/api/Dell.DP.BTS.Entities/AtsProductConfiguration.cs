﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class AtsProductConfiguration
    {
        public int RoutingThreshold { get; set; }
        public int LowThreshold { get; set; }
        public int OversellThreshold { get; set; }
        public int OversoldThreshold { get; set; }
        public int BufferThreshold { get; set; }
        public bool? DisplayLowInventory { get; set; }
        public bool? IncludePreCheckout { get; set; }
        public bool? IncludeCheckout { get; set; }
        public bool? SellAction { get; set; }
        public bool? FGASCDHOverride { get; set; }
        public bool? SnPSCDHOverride { get; set; }
        public string UserName { get; set; }
        public string UpdateAction { get; set; }


        //     RoutingThreshold, LowThreshold, OversellThreshold, OversoldThreshold, BufferThreshold, DisplayLowInventory, IncludePreCheckout, IncludeCheckout, SellAction


    }
}
