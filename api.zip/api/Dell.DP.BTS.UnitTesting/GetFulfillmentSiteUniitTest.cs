﻿using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    /// <summary>
    /// Summary description for ProductConfigurationUnitTest
    /// </summary>
    
    public class FulfillmentSiteUnitTest:UnitTestInitializer
    {


        [Fact]
        public void GetFulfillmentSiteDataShouldReturnOKResult()
        {
            int productCountryId = 1588;
            var result = btsQueryController.GetProductFulfillmentLocation(productCountryId, 3);
            Assert.NotNull(result);
        }
    }
}
