﻿using Dell.DP.BTS.Entities;
using Dell.DP.BTS.API.Controllers;
using Dell.DP.BTS.DataServices;
using Dell.DP.BTS.BusinessServices;
using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    /// <summary>
    /// Summary description for InTransitUnitTest
    /// </summary>
    
    public class InTransitUnitTest:UnitTestInitializer
    {


        [Fact]
        public void GetInTransitDataShouldReturnOKResult()
        {
            AtsInTransitSearchRequest items = new AtsInTransitSearchRequest()
            {
                PageNumber = 1,
                PageSize = 20,
                CountryId = 1
            };

            var result = btsQueryController.GetInTransit(items);
            Assert.NotNull(result);
        }

        [Fact]
        public void GetInTransitExportDataShouldReturnOKResult()
        {
            AtsInTransitSearchRequest items = new AtsInTransitSearchRequest()
            {
                PageNumber = 1,
                PageSize = 20,
                CountryId = 1
            };

            var result = btsQueryController.ExportInTransitDetails(items);
            Assert.NotNull(result);
        }


    }
}
