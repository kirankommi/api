import { Component, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatDialog } from '@angular/material';
import { FormBuilder, FormGroup, Validators, FormsModule, NgForm, FormControl } from '@angular/forms';
import { ApjAtsCatalogService } from './apj-ats-catalog.service';
import { ApjAtsFacadeService } from '@App/shared/apj-ats-facade.service';
import { ApjAtsCountry, Data, AtsCatalog } from './apj-ats-catalog.model';
import { Global } from '@App/shared/global';
import { LocalStorageService } from 'angular-2-local-storage';
import { NotifierService } from 'angular-notifier';
import { ConfirmationDialogComponent, ConfirmDialogModel } from '@App/shared/confirmation-dialog/confirmation-dialog.component';

@Component({
  selector: 'app-apj-ats-catalog',
  templateUrl: './apj-ats-catalog.component.html',
  styleUrls: ['./apj-ats-catalog.component.css'],
})

export class ApjAtsCatalogComponent {
  apjAtsCatalogForm: FormGroup;
  CountryList: ApjAtsCountry[];
  atsCatalogs: AtsCatalog[];
  data: Data = new Data();
  atsCatalog: AtsCatalog = new AtsCatalog();
  searchText: string = ''; 
  searchBy: string = '';
  selRegion: string = '';
  indLoading: boolean = false;
  displayedColumns = ['countryName', 'CatalogCode', 'CatalogId', 'Action'];
  dataSource: MatTableDataSource<AtsCatalog>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  private readonly notifier: NotifierService;
  addNewRow: boolean = false;
  message: string;

  constructor(private fb: FormBuilder,
    private _ApjAtsFacadeService:ApjAtsFacadeService,
    private _localStorageService: LocalStorageService,
    notifierService: NotifierService,
    public dialog: MatDialog) {
    // To initialize FormGroup , Validators.required 
    this.apjAtsCatalogForm = fb.group({
      ddlSearchBy: new FormControl(''),
      txtSearch: new FormControl(''),
      ddlCountry: new FormControl(''),
      txtRegionCode: new FormControl(''),
      txtCatalogId: new FormControl('')
    });
    this.notifier = notifierService;
  }

  ngOnInit(){
    this.init();
  }

  init() {
    this.selRegion = this._localStorageService.get('selRegion');
    this.getCatalogs();
  }

  getCatalogs() {
    this.indLoading = true;
    this.data.RegionId = this.selRegion;
    this._ApjAtsFacadeService.getCatalogs(this.data)
    .subscribe(data => {
      if (data.length > 0) {
        this.atsCatalogs = data;
        this.dataSource = new MatTableDataSource(this.atsCatalogs);
        this.dataSource.paginator = this.paginator;
        this.getCountries();
      }
      else {
        this.atsCatalogs = [];
      }
      this.indLoading = false;
    },
    error => {
      this.notifier.notify('error', 'Error while fetching Catalogs');
      this.indLoading = false;
    });
  }

  getCountries() {
    this.indLoading = true;
    this._ApjAtsFacadeService.getCountries(this.selRegion)
    .subscribe(data => {
      if (data.length > 0) {
        this.CountryList = data;
        this.indLoading = false;
      }
      else {
        this.CountryList = [];
      }
      this.indLoading = false;
    },
    error => {
      this.notifier.notify('error', 'Error while fetching Contries');
      this.indLoading = false;
    });
  }

  search() {
    if (this.apjAtsCatalogForm.get('ddlSearchBy').value == "COUNTRYNAME" ||
      this.apjAtsCatalogForm.get('ddlSearchBy').value == "CATALOGCODE" ||
      this.apjAtsCatalogForm.get('ddlSearchBy').value == "CATALOGID") {
      if (this.apjAtsCatalogForm.get('txtSearch').value == "" ||
        this.apjAtsCatalogForm.get('txtSearch').value == null) {
        this.notifier.notify('error', 'Please provide search text.');
        return;
      }
    }
    if (this.apjAtsCatalogForm.get('ddlSearchBy').value == "") {
      if (this.apjAtsCatalogForm.get('txtSearch').value != "") {
        this.notifier.notify('error', 'Please select Search By and provide search text.');
        return;
      }
    }

    this.indLoading = true;
    this.addNewRow = false;
    this.data.CountryName = null;
    this.data.RegionCode = null;
    this.data.CatalogId = null;

    switch (this.apjAtsCatalogForm.get('ddlSearchBy').value) {
      case 'COUNTRYNAME':
        this.data.CountryName = this.apjAtsCatalogForm.get('txtSearch').value;
        break;
      case 'CATALOGCODE':
        this.data.RegionCode = this.apjAtsCatalogForm.get('txtSearch').value;
        break;
      case 'CATALOGID':
        this.data.CatalogId = this.apjAtsCatalogForm.get('txtSearch').value;
        break;
    }

    this.data.RegionId = this.selRegion;
    this._ApjAtsFacadeService.getCatalogs(this.data)
    .subscribe(data => {
      if (data.length > 0) {
        this.atsCatalogs = data;
        this.dataSource = new MatTableDataSource(this.atsCatalogs);
        this.dataSource.paginator = this.paginator;
        this.indLoading = false;
      }
      else {
        this.atsCatalogs = [];
        this.dataSource = new MatTableDataSource(this.atsCatalogs);
      }
      this.indLoading = false;
    },
    error => {
      this.notifier.notify('error', 'Error while fetching Catalogs');
      this.indLoading = false;
    });
  }

  createNewCatalog(): AtsCatalog {
    return {
      id: 0,
      countryId: 0,
      countryName: "",
      regionCode: "",
      catalogId: 0,
      catalogGroupId: 0,
      catalogGroup: "",
      countryCodes: "",
      countryIdsCsv: "",
      countryIds: [],
      userID: "",
      regionId: 0,
      Edit: true
    };
  }

  addRow() {
    if (!this.addNewRow) {
      this.atsCatalogs.forEach(catalog => {
          catalog.Edit = false;
      });
      this.addNewRow = true;
      this.apjAtsCatalogForm.controls['ddlCountry'].setValue("");
      this.apjAtsCatalogForm.controls['txtRegionCode'].setValue("");
      this.apjAtsCatalogForm.controls['txtCatalogId'].setValue("");
      this.dataSource.data.unshift(this.createNewCatalog());
      this.dataSource.filter = "";
      this.paginator.pageIndex = 0;
      this.dataSource.paginator = this.paginator;
    }
  }

  toggleEditMode(row) {
    if (!this.addNewRow) {
      this.atsCatalogs.forEach(catalog => {
        if (row.id != catalog.id) {
          catalog.Edit = false;
        }
        else {
          catalog.Edit = true;
        }
      });
      this.apjAtsCatalogForm.controls['ddlCountry'].setValue(row.countryId);
      this.apjAtsCatalogForm.controls['txtRegionCode'].setValue(row.regionCode);
      this.apjAtsCatalogForm.controls['txtCatalogId'].setValue(row.catalogId);
    }
    
  }

  update(row) {
    if (this.apjAtsCatalogForm.controls['ddlCountry'].value == null || this.apjAtsCatalogForm.controls['ddlCountry'].value == "") {
      this.notifier.notify('error', 'Please select Country Name');
      row.edit = true;
      return;
    }
    else if (this.apjAtsCatalogForm.controls['ddlCountry'].value == null || this.apjAtsCatalogForm.controls['txtRegionCode'].value == "") {
      this.notifier.notify('error', 'Please Enter Catalog Code');
      row.edit = true;
      return;
    }

    if(this.addNewRow)
      this.message = 'Do you want to add this Catalog ?';
    else
      this.message = 'Do you want to update this Catalog ?';

    const dialogData = new ConfirmDialogModel("Catalog Edit", this.message);
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {maxWidth: "100%",data: dialogData,disableClose: true,width: "100%"});
    row.Edit = false;

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult) {
        this.atsCatalog.countryId = this.apjAtsCatalogForm.controls['ddlCountry'].value;
        this.atsCatalog.regionCode = this.apjAtsCatalogForm.controls['txtRegionCode'].value;
        this.atsCatalog.catalogId = this.apjAtsCatalogForm.controls['txtCatalogId'].value;
        this.atsCatalog.userID = "ASIA-PACIFIC\\Kiran_kumar_Kommi";
        this.atsCatalog.id = row.id;

        this._ApjAtsFacadeService.UpdateCatalog(this.atsCatalog)
        .subscribe(data => {
          this.search();
          this.notifier.notify('success', 'Information updated successfully');
        },
        error => {
          this.notifier.notify('error', 'Error while updating Catalog');
          this.indLoading = false;
        });
      }
    });
  }

  delete(row) {
    this.message = 'Do you want to delete this Catalog ?';
    const dialogData = new ConfirmDialogModel("Catalog Delete", this.message);
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {maxWidth: "100%",data: dialogData,disableClose: true,width: "100%"});

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult) {
        this.atsCatalog.id = row.id;
        this._ApjAtsFacadeService.DeleteCatalog(this.atsCatalog)
        .subscribe(data => {
          this.search();
          this.notifier.notify('success', 'Information deleted successfully');
        },
        error => {
          this.notifier.notify('error', 'Error while deleting Catalog');
          this.indLoading = false;
        });
      }
    });
  }

  cancel() {
    if (this.addNewRow) {
      this.search()
    }
  }
}




