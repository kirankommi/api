﻿using Dell.DP.BTS.Entities;
using Dell.DP.BTS.API.Controllers;
using Dell.DP.BTS.DataServices;
using Dell.DP.BTS.BusinessServices;
using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    
    public class RuleManagerEditUnitTest:UnitTestInitializer
    {

        [Fact]
        public void UpdateRuleManagerDataShouldReturnOKResult()
        {
            var result = btsCommandController.UpdateApplicationRuleConfiguration(atsApplicationConfigurations);
            Assert.NotNull(result);
        }
    }
}
