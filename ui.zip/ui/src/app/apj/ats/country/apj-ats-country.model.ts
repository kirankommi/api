export class ApjAtsCountry
{
    Id: number;
    id: number;
    Code:string;
    code:string;
    CountryName:string;
    countryName:string;
    RegionId: number;
    regionId: number;
    Operation: string = null;
    AllowFutureCommit: boolean;
    Site: AtsSite;
    ModifiedBy: string;
    Edit: boolean;
    Active: boolean;
}

export class AtsSite
{
    Id: number;
    SiteName: string;
    SiteCode:string;
    Description:string;
    CountryName:string;
    ModifiedBy:string;
    CountryId:number;
    OldCountryId:number;
    Sequence:number;
    Type:string;
    IsActive:boolean;
    ProductCountryId:number;
    Operation:string;
}

export class Region
{
    name: string;
    value: number;
}