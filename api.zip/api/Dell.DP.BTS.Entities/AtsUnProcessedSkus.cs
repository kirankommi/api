﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsUnProcessedSkus
    {
        public string SKU { get; set; }
        public string FGA { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string ItemTypeCode { get; set; }
        public string BTSFlag { get; set; }
        public string BTOFlag { get; set; }
        public string BTPFlag { get; set; }
        public string CreatedOn { get; set; }
        public string UpdatedOn { get; set; }
        public bool Active { get; set; }
        public bool IsActive { get; set; } //Handling Model binding
        public int RegionId { get; set; }
        public string LOB { get; set; }
      
    }
}
