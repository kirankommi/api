﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsStatusHistory
    {
        public int HistoryId { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string FromStatus { get; set; }
        public string ToState { get; set; }
        public string CreatedBy { get; set; }
    }


    public class AtsLeadTimeHistory
    {
        public int Id { get; set; }
        public DateTime? ChangedOn { get; set; }
        public int  FromLeadTime { get; set; }
        public int  ToLeadTime { get; set; }
        public string UpdatedBy { get; set; }
    }

}
