﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class IsgSiteHoliday
    {
        public int SiteHolidayId { get; set; }
        public string SiteId { get; set; }
        public string HolidayDate { get; set; }
        public string Description { get; set; }
        public bool IsWeekend { get; set; }
        public string ChangedBy { get; set; }
        public int RowNumber { get; set; }

    }
}
