﻿using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    
    public class StatusHistoryAndSummaryUnitTest : UnitTestInitializer
    {

        [Fact]
        public void GetStatusHistoryAndSummaryDetailShouldReturnOKResult()
        {
            var productCountryId = 5988;

            var result = btsQueryController.GetItemStatusHistory(productCountryId);
            Assert.NotNull(result);
        }      
    }
}
