import { Component, OnInit, Output, EventEmitter } from '@angular/core';
export interface Region {
  value: string;
  viewValue: string;
}
export interface ProductType {
  value: string;
  viewValue: string;
} 
@Component({
  selector: 'app-sidenav-list',
  templateUrl: './sidenav-list.component.html',
  styleUrls: ['./sidenav-list.component.css']
})
export class SidenavListComponent implements OnInit {

  //panelOpenState = false;

  @Output() sidenavClose = new EventEmitter();
 
  constructor() { }
  Regions: Region[] = [
    {value: '1', viewValue: 'AMERICAS'},
    {value: '2', viewValue: 'APJ'},
    {value: '3', viewValue: 'EMEA'},
    {value: '4', viewValue: 'GLOBAL'}
  ];
  ProductTypes: ProductType[] = [
    {value: '1', viewValue: 'BASE'},
    {value: '2', viewValue: 'COMPONENT'},
    {value: '3', viewValue: 'FGA (BTS & BTP)'},
    {value: '4', viewValue: 'BTO / CTO'},
    {value: '5', viewValue: 'S & P ATS'},
    {value: '6', viewValue: 'ATS (BTS & BTP)'},
    {value: '7', viewValue: 'Ready Stock'}
  ];
  ngOnInit() {
  }
 
  public onSidenavClose = () => {
    this.sidenavClose.emit();
  }
 
}