﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsItemSearchRequest
    {
        public string Sku { get; set; }
        public int Type { get; set; }
        public string Part { get; set; }
        public string CountryId { get; set; }
        public string CatalogGroupIds { get; set; }
        public int Region { get; set; }
        public int StockStatus { get; set; }
        public string CatalogId { get; set; }
        public string LocationCode { get; set; }
        public int? IsContinueToSell { get; set; }
        public string IsActive { get; set; }
        public int SalesChannel { get; set; }
        public int? SDSEnable { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}
