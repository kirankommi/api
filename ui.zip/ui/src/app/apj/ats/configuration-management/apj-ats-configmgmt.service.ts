import { Injectable } from '@angular/core';
import {DataservicesProvider} from '@Dataservice/dataservices/dataservices';
import { Observable } from 'rxjs/Observable';
import { Configurations, PostData } from './apj-ats-configmgmt.model';
import { environment } from '@Environments/environment';

@Injectable({
    providedIn: 'root'  
})
export class ApjAtsConfigMgmtService {

    constructor(private _DataservicesProvider:DataservicesProvider ) {
    }

    getApplications() {
      return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getApplications');
    }

    getApplicationConfigurations(filter) : Observable<Configurations> {
      return this._DataservicesProvider.PostData(environment.ApjEmeaAtsApiUrl + 'getApplicationConfigurations', filter);
    }

    updateapplicationconfiguration(postData: PostData) {
      return this._DataservicesProvider.PostData(environment.ApjEmeaAtsApiUrl + 'command/updateapplicationconfiguration', postData);
    }
}
