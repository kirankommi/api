﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsItem : AtsCommon
    {
        public int Id { get; set; }
        public String Sku { get; set; }
        public string Part { get; set; }
        public string Brand { get; set; }
        public string Type { get; set; }
        public string OfferType { get; set; }
        public string Description { get; set; }
        public int? CatalogId { get; set; }
        public string Catalog { get; set; }
        public int? CatalogGroupId { get; set; }
        public string CatalogGroup { get; set; }
        public int? ATS { get; set; }
        public int? OnHand { get; set; }
        public int? Commit { get; set; }
        public int? Checkout { get; set; }
        public int? Cart { get; set; }
        public string FutureCommit { get; set; }
        public int StatusId { get; set; }
        public string Status { get; set; }
        public int? LeadTime { get; set; }
        public string LTSource { get; set; }
        public int? DefaultLT { get; set; }
        public int? StdLeadTime { get; set; }
        public string CountDown { get; set; }
        public bool ContinueToSell { get; set; }
        public bool SDS { get; set; }
        public bool Active { get; set; }
        public int ProductCountryId { get; set; }
        public string ProductCountryIds { get; set; }
        public int ExtendedLeadTime { get; set; }
        public bool IsSDSEnabledCountry { get; set; }
        public string Threshold { get; set; }
        public bool? IsBTSSku { get; set; }
        public bool? IsBTOSku { get; set; }
        public bool? IsBTPSku { get; set; }

    }

    public class AtsItemDetail : AtsItem
    {
        public int LowThreshold { get; set; }
        public int SDSShippingId { get; set; }
        public int OutOfStockThresold { get; set; }
        public bool DisplayLowInventry { get; set; }
        public bool IsEligibleForSmartLogo { get; set; }
        public string ItemInventryStatus { get; set; }
        public bool IsFirstTrackEligible { get; set; }
        public int ExtendedLeadTimeThresold { get; set; }
        public int AvailabletoSellQuantiry { get; set; }
        public int SameDayShippingThreshold { get; set; }
        public bool AllowAutoXLT { get; set; }
        public int AutoXltIncrement { get; set; }
    }
}
