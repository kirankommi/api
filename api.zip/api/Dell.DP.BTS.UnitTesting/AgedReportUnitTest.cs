﻿using Dell.DP.BTS.Entities;
using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    /// <summary>
    /// Summary description for ProductConfigurationUnitTest
    /// </summary>
    public class AgedReportUnitTest:UnitTestInitializer
    {

        [Fact]
        public void GetAgedReportDataShouldReturnOKResult()
        {
            OrderDetailsSearchRequest orderDetailsSearchRequest = new OrderDetailsSearchRequest();
            orderDetailsSearchRequest.PageNumber = 1;
            orderDetailsSearchRequest.PageSize = 20;
            orderDetailsSearchRequest.CountryIds = "-1";
            orderDetailsSearchRequest.Parts = "-1";
            orderDetailsSearchRequest.ProductTypeIds = "-1";
            orderDetailsSearchRequest.SiteIds = "-1";


            var result = btsQueryController.GetOrderDetails(orderDetailsSearchRequest);
            Assert.NotNull(result);
        }
    }
}
