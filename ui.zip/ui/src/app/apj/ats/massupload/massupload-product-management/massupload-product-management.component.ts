import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient, HttpEvent, HttpErrorResponse, HttpEventType } from '@angular/common/http';
// Must import to use Forms functionality  
import { MatButtonModule } from '@angular/material';
import { MatDialogModule, MatListModule, MatProgressBarModule } from '@angular/material'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { MassuploadProductManagementService } from '../massupload-product-management/massupload-product-management.service';
import { Router } from "@angular/router";
import { FormBuilder, FormGroup } from '@angular/forms';
import { forEach } from '@angular/router/src/utils/collection';
import { Global } from '@App/shared/global';
import { NotifierService } from 'angular-notifier';

@Component({
  selector: 'massupload-product-management',
  templateUrl: './massupload-product-management.component.html',
  styleUrls: ['./massupload-product-management.component.css']
})
export class MassuploadProductManagementComponent implements OnInit {
  selectedFile: File
  outputPath: string = '';
  public isFileUploadHasRecord: boolean = false;
  isFileBrowsed: boolean = false;
  IsSuccessWarning: boolean = false;
  NeedShowMessage: boolean = false;
  toggleErrorInfo: boolean = false;
  canBeClosed = true;
  primaryButtonText = 'Browse';
  showCancelButton = true;
  uploading = false;
  uploadSuccessful = false;
  uploadFileName: string;
  data: any;
  error: string;
  excelName: string;
  profileForm: FormGroup;
  FailedInfo: any;
  indLoading: boolean = false;
  UploadStatus: string;
  IsUploadSuccess: boolean = false;
  notifier: NotifierService;

  constructor(private fb: FormBuilder, public uploadService: MassuploadProductManagementService, private router: Router,
    private httpClient: HttpClient, private _notifier: NotifierService) { this.notifier = _notifier; }

  ngOnInit() {
    this.profileForm = this.fb.group({
      name: [''],
      profile: ['']
    });
  }


  onFilesAdded(event) {
    this.isFileBrowsed = false;
    if (event.target.files.length > 0) {
      console.log(event.target.files);
      this.selectedFile = event.target.files[0];
      this.excelName = this.selectedFile.name;
      this.isFileBrowsed = true;
      this.profileForm.get('name').setValue(this.selectedFile.name)
    }
  }
  gotoExcelDownloadPath() {
    this.router.navigate(["http://localhost:4200/Content/Templates/APJ/ATS_APJ_Product_Management_Massupload_Template.xlsx"]).then((e) => {
      if (e) {
        console.log("Navigation is successful!");
      } else {
        console.log("Navigation has failed!");
      }
    });
  }

  getFormattedInfo(info: string) {
    var infoArray = [];

    if (info) {
      info = info.replace(/\r\n/g, "");
      info = info.replace(/\\r\\n/g, "");
      info = info.replace(/\\n/g, "\n");
      if (info) {
        info.split(/\n/g).forEach(x => {
          if (x != "")
            infoArray.push(x);
        })
      }
    }

    return infoArray;
  }

  uploadFiles() {
    this.indLoading = true;
    this.toggleErrorInfo = false;
    this.IsUploadSuccess = false;
    const formData: FormData = new FormData();
    formData.append('file', this.selectedFile, this.selectedFile.name);
    formData.append('name', this.profileForm.get('name').value);
    formData.append('profile', this.profileForm.get('profile').value);
    // formData.append('file',this.profileForm.get('profile').value, this.profileForm.get('name').value);
    this.FailedInfo = [];
    this.FailedInfo = null;
    this.uploadService.upload(formData).subscribe(
      (res) => {
        this.data = res;
        this.isFileUploadHasRecord = this.data != null && this.data.totalRecords != null && this.data.totalRecords > 0;
        this.FailedInfo = this.getFormattedInfo(this.data.failedInfo);

        this.IsSuccessWarning = this.data.failedCount == 0 && this.data.failedInfo.length !== null &&  this.data.failedInfo.trim().length > 0 ;
        this.UploadStatus = this.data.failedCount > 0 ? (this.data.failedCount >= this.data.totalRecords ? 'Failed' : 'Partial') : (this.IsSuccessWarning==true) ? 'Warnings' : 'Success';
        this.NeedShowMessage = this.UploadStatus != 'Success';
        this.indLoading = false;
      },
      (err) => { this.error = err; this.indLoading = false; this.notifier.notify('error', err); }

    );
    console.log(this.data);
  }

}
