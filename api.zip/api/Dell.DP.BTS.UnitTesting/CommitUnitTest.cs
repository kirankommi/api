﻿using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    /// <summary>
    /// Summary description for ProductConfigurationUnitTest
    /// </summary>
    
    public class CommitUnitTest:UnitTestInitializer
    {


        [Fact]
        public void GetCommitDataShouldReturnOKResult()
        {
            int productCountryId = 1588;
            
            var result = btsQueryController.GetCommitDetail(productCountryId);
            Assert.NotNull(result);
        }
    }
}
