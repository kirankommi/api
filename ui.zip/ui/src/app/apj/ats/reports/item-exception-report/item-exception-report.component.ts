import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, NgForm, FormsModule } from '@angular/forms';
import { DataservicesProvider } from '@Dataservice/dataservices/dataservices';
import { ApjAtsFacadeService } from '@App/shared/apj-ats-facade.service';
import { Global } from '@App/shared/global';
import { ExcelService } from '@App/shared/exportservice';
import { MatPaginator, MatSort, MatTableDataSource, MatTooltip, fadeInContent } from '@angular/material';
import { LocalStorageService } from 'angular-2-local-storage';
import { ReportData, ItemExceptionReportRequest, ExportReportData } from './item-exception-report.model'
import { ProductManagementService } from '@App/apj/ats/product-management/product-management.service'
import { NotifierService } from 'angular-notifier';
import { debug } from 'util';
@Component({
  selector: 'app-item-exception-report',
  templateUrl: './item-exception-report.component.html',
  styleUrls: ['./item-exception-report.component.css']
})
export class ItemExceptionReportComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;

  //Variable Declarations
  displayedColumns = ['Type', 'GroupName', 'Catalog', 'Sku', 'Part', 'Status', 'AggregateATS', 'SDSThreshold', 'NetSDS', 'InOversellThreshold', 'NetOversell', 'InOversoldThreshold', 'NetOversold', 'LTSource', 'CurrentLT', 'DefaultLT', 'ExtendedLT', 'SiteCode', 'OnHandQuantity', 'Commit', 'FutureCommit', 'RoutingThreshold', 'NetATS', 'InboundSupply', 'SupplyETA', 'ShipmentMode'];

  apjItemExceptionReportForm: FormGroup;
  dataSource: MatTableDataSource<ReportData>;
  RegionId: number;
  pageIndex: number = 1;
  pageSize: number = 10;
  pageSizeOptions: number[] = [10, 20, 30, 50, 100];
  length: any;
  totalPageSize: any;
  IsCommitDetails: boolean = false;
  indLoading: boolean = false;
  Countries: any;
  LocationCodes: any;
  ProductTypes: any;
  getFGADetails: any;
  exportData: ExportReportData[];
  parseData = [];
  ErrorMsg: any;
  SuccessMsg: any;
  itemExceptionReportRequest: ItemExceptionReportRequest = new ItemExceptionReportRequest();
  haRecords: boolean = false;
  notifier: NotifierService;
  isValid: Boolean = false;
  //Constructor
  constructor(private _formBuilder: FormBuilder
    , private _dataservicesProvider: DataservicesProvider
    , private _excelService: ExcelService
    , private _ApjAtsFacadeService: ApjAtsFacadeService
    , private _localStorageService: LocalStorageService
    , private _productManagementService: ProductManagementService
    , private _notifier: NotifierService) {

    this.RegionId = this._localStorageService.get('selRegion');

    // To initialize FormGroup , Validators.required 
    this.apjItemExceptionReportForm = _formBuilder.group({
      'ddlSite': [null],
      'ddlType': [null],
      'txtPart': [null]
    });

    this.notifier = _notifier;

  }

  //Init
  ngOnInit() {
    this.RegionId = this._localStorageService.get('selRegion');
    this.loadLocationCode(this.RegionId);
    this.loadProductType();
    this.Search(this.apjItemExceptionReportForm.value)
  }

  // Site
  loadLocationCode(_regionId): void {
    this.indLoading = true;
    this._ApjAtsFacadeService.loadLocationCode(_regionId)
      .subscribe(locationcodes => {
        this.LocationCodes = locationcodes;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }

  // ProductType
  loadProductType(): void {
    this.indLoading = true;
    this._productManagementService.GetProductTypes()
      .subscribe(productTypes => {
        this.ProductTypes = productTypes;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }

  getNext(event): void {
    this.length = length;
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.Search(this.apjItemExceptionReportForm.value);
  }

  doFilter(value: string) {
    value = value.trim();
    value = value.toLowerCase();
    this.dataSource.filter = value;
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
    this.haRecords = this.dataSource.filteredData.length > 0;
  }

  validateSearch(obj) {

    //Site
    this.itemExceptionReportRequest.SiteIds = '-1';
    if (!(obj.ddlSite === '' || obj.ddlSite === 'undefined' || obj.ddlSite === null)) {
      this.itemExceptionReportRequest.SiteIds = obj.ddlSite;
    }

    //Product Type
    this.itemExceptionReportRequest.ProductTypeIds = '-1';
    if (!(obj.ddlType === '' || obj.ddlType === 'undefined' || obj.ddlType === null)) {
      this.itemExceptionReportRequest.ProductTypeIds = obj.ddlType;
    }

    //Part
    this.itemExceptionReportRequest.Parts = '-1';
    if (!(obj.txtPart === '' || obj.txtPart === 'undefined' || obj.txtPart === null)) {
      this.itemExceptionReportRequest.Parts = obj.txtPart;
    }

    return true;
  }
  Search(obj) {

    this.isValid = this.validateSearch(obj);
    if (!this.isValid)
      return;

    //Page Number
    this.itemExceptionReportRequest.PageNumber = this.pageIndex;

    //Page Number
    this.itemExceptionReportRequest.PageSize = this.pageSize;

    this.haRecords = false;
    this.indLoading = true;

    this._ApjAtsFacadeService.itemExceptionReportSearch(this.itemExceptionReportRequest)
      .subscribe(data => {
        this.dataSource = new MatTableDataSource<ReportData>(data['orderDetailsList']);
        this.totalPageSize = data['recordCount'];
        this.haRecords = (this.dataSource != null && this.dataSource.data != null && this.dataSource.data.length > 0);
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }

  exportToExcel() {
    this.parseData = [];
    this.exportData.map(item => {
      return {
        'Type': item.Type,
        'Catalog Group': item.GroupName,
        'Catalog': item.Catalog,
        'SKU': item.Sku,
        'Part/CFG': item.Part,
        'Status': item.Status,
        'Aggregate ATS': item.AggregateATS,
        'SDS Threshold': item.SDSThreshold,
        'Net SDS': item.NetSDS,
        'XLT Threshold': item.InOversellThreshold,
        'Net XLT': item.NetOversell,
        'OOS/EOL Threshold': item.InOversoldThreshold,
        'Net OOS/EOL': item.NetOversold,
        'LT Source': item.LTSource,
        'Current LT': item.CurrentLT,
        'Def LT': item.DefaultLT,
        'Ext LT': item.ExtendedLT,
        'Site': item.SiteCode,
        'On Hand': item.OnHandQuantity,
        'Commit': item.Commit,
        'Future Commit': item.FutureCommit,
        'Routing Threshold': item.RoutingThreshold,
        'Net ATS': item.NetATS,
        'Supply': item.InboundSupply,
        'Supply ETA': item.SupplyETA,
        'Ship Mode': item.ShipmentMode

      }
    }).forEach(item => this.parseData.push(item));

    this._excelService.exportAsExcelFile(this.parseData, 'Item_Exception_Report');
  }
  exportAsXLSX(obj): void {
    this.isValid = this.validateSearch(obj);
    if (!this.isValid)
      return;
    debugger;
    //Page Number
    this.itemExceptionReportRequest.PageNumber = 1;

    //Page Number
    this.itemExceptionReportRequest.PageSize = -1;

    this.indLoading = true;
    this._ApjAtsFacadeService.itemExceptionReportSearch(this.itemExceptionReportRequest)
      .subscribe(data => {
        this.exportData = data.orderDetailsList;
        this.exportToExcel();
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });

  }


}
