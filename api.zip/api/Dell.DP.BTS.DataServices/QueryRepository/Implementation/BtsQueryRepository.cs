﻿using Dell.DP.BTS.DataServices.DbFactory;
using Dell.DP.BTS.DataServices.QueryRepository.Interfaces;
using Dell.DP.BTS.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Dell.DP.BTS.DataServices.QueryRepository.Implementation
{
    public class BtsQueryRepository : IBtsQueryRepository
    {
        private readonly IDbFactory _atsQueryDbFactory;
        protected List<AtsItem> AtsItems;
        protected List<OrderDetailsSearchResponse> response;
        protected OrderDetailsSearchResponse orderDetailsSearchResponse;
        protected CommitCalloutDetail commitCalloutDetail;
        protected List<CommitCalloutDetail> CommitCalloutDetails;

        public BtsQueryRepository(IDbFactory atsQueryDbFactory)
        {
            this._atsQueryDbFactory = atsQueryDbFactory;
        }


        public async Task<AtsFgaItemLists> GetFGAItemDetails(AtsItemSearchRequest Item)
        {
            var lstAtsItems = new AtsFgaItemLists();
            lstAtsItems.AtsFGAItems = new List<AtsItem>();
            lstAtsItems.AtsFGAItems.Clear();

            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetItems";
                        dbCommand.CommandTimeout = 120;

                        var Sku = new SqlParameter("@Sku", (Item.Sku == "null" ? null : Item.Sku));
                        var Part = new SqlParameter("@FGAorPARTNo", (Item.Part == "null" ? null : Item.Part));
                        var IsActive = new SqlParameter("@IsActive", Item.IsActive);
                        var Type = new SqlParameter("@Type", Item.Type);
                        var StockStatus = new SqlParameter("@StockStatuses", Item.StockStatus);
                        var CountryIds = new SqlParameter("@CountryIds", Item.CountryId);
                        var CatalogGoupIds = new SqlParameter("@CatalogGroupIds", Item.CatalogGroupIds);
                        var RegionId = new SqlParameter("@RegionId", Item.Region);
                        var CatalogId = new SqlParameter("@CatalogIds", Item.CatalogId);
                        var locationCode = new SqlParameter("@LocationCodes", Item.LocationCode);
                        var SDSEnable = new SqlParameter("@SDSEnabled", (Item.SDSEnable == -1 ? null : Item.SDSEnable));
                        var ContinueToSell = new SqlParameter("@ContinueToSell", (Item.IsContinueToSell == -1 ? null : Item.IsContinueToSell));
                        var pageNumber = new SqlParameter("@PageNumber", Item.PageNumber);
                        var pageSize = new SqlParameter("@PageSize", Item.PageSize);
                        var prmTotalRows = new SqlParameter() { ParameterName = "@TotalRows", Direction = ParameterDirection.Output, SqlDbType = SqlDbType.Int };

                        dbCommand.Parameters.Add(Sku);
                        dbCommand.Parameters.Add(Part);
                        dbCommand.Parameters.Add(IsActive);
                        dbCommand.Parameters.Add(Type);
                        dbCommand.Parameters.Add(StockStatus);
                        dbCommand.Parameters.Add(CountryIds);
                        dbCommand.Parameters.Add(CatalogGoupIds);
                        dbCommand.Parameters.Add(RegionId);
                        dbCommand.Parameters.Add(CatalogId);
                        dbCommand.Parameters.Add(locationCode);
                        dbCommand.Parameters.Add(SDSEnable);
                        dbCommand.Parameters.Add(ContinueToSell);
                        dbCommand.Parameters.Add(pageNumber);
                        dbCommand.Parameters.Add(pageSize);
                        dbCommand.Parameters.Add(prmTotalRows);


                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsItem();

                                model.Id = Convert.ToInt32(reader["Id"]);
                                model.Sku = (reader["SKU"] == DBNull.Value) ? null : Convert.ToString(reader["SKU"]);
                                model.Part = (reader["FGA"] == DBNull.Value) ? null : Convert.ToString(reader["FGA"]);
                                model.Brand = (reader["BRAND_NAME"] == DBNull.Value) ? null : Convert.ToString(reader["BRAND_NAME"]);
                                model.Type = (reader["FGA_NonFGA"] == DBNull.Value) ? null : Convert.ToString(reader["FGA_NonFGA"]);
                                model.Description = (reader["Description"] == DBNull.Value) ? null : Convert.ToString(reader["Description"]);
                                model.OfferType = (reader["OfferType"] == DBNull.Value) ? null : Convert.ToString(reader["OfferType"]);
                                model.CatalogGroup = (reader["Catalog"] == DBNull.Value) ? null : reader["Catalog"].ToString();
                                model.ATS = (reader["Available"] == DBNull.Value) ? null : (int?)(reader["Available"]);
                                model.OnHand = (reader["OnHand"] == DBNull.Value) ? null : (int?)(reader["OnHand"]);
                                model.Commit = (reader["Committed"] == DBNull.Value) ? null : (int?)(reader["Committed"]);
                                model.Checkout = (reader["PostCheckOut"] == DBNull.Value) ? null : (int?)(reader["PostCheckOut"]);
                                model.Cart = (reader["PreCheckOut"] == DBNull.Value) ? null : (int?)(reader["PreCheckOut"]);
                                model.Status = (reader["Status"] == DBNull.Value) ? null : Convert.ToString(reader["Status"]);
                                model.Threshold = (reader["Threshold"] == DBNull.Value) ? null : Convert.ToString(reader["Threshold"]);
                                model.LeadTime = (reader["DisplayLeadTime"] == DBNull.Value) ? null : (int?)(reader["DisplayLeadTime"]);
                                model.LTSource = (reader["LeadTimeSource"] == DBNull.Value) ? null : Convert.ToString(reader["LeadTimeSource"]);
                                model.DefaultLT = (reader["DefaultLeadTime"] == DBNull.Value) ? null : (int?)(reader["DefaultLeadTime"]);
                                model.ContinueToSell = (Convert.ToBoolean(reader["ContinueToSell"]));
                                model.Active = (Convert.ToBoolean(reader["Active"]));
                                model.ProductCountryId = Convert.ToInt32(reader["ProductCountryId"]);
                                lstAtsItems.AtsFGAItems.Add(model);
                            }

                        }
                        lstAtsItems.RecordCount = (prmTotalRows.Value == DBNull.Value) ? null : (int?)prmTotalRows.Value;

                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return lstAtsItems;
        }

        public async Task<List<AtsItem>> GetFGAItemExportDetails(AtsItemSearchRequest Item)
        {
            var Result = GetFGAItemDetails(new AtsItemSearchRequest
            {
                CatalogId = Item.CatalogId,
                CountryId = Item.CountryId,
                IsActive = Item.IsActive,
                IsContinueToSell = Item.IsContinueToSell,
                LocationCode = Item.LocationCode,
                Part = Item.Part,
                Region = Item.Region,
                SalesChannel = Item.SalesChannel,
                SDSEnable = Item.SDSEnable,
                Sku = Item.Sku,
                StockStatus = Item.StockStatus,
                Type = Item.Type,
                PageNumber = 1,
                PageSize = -1
            });

            await Task.WhenAll(Result);
            AtsItems = Result.Result.AtsFGAItems;

            return AtsItems;

        }
        public async Task<IEnumerable<InventryStatus>> GetStockStatus()
        {
            var atsInventry = new List<InventryStatus>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetInventoryStatus";

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new InventryStatus();

                                model.Id = Convert.ToInt32(reader["Id"]);
                                model.Status = (reader["Status"] == DBNull.Value) ? null : Convert.ToString(reader["Status"]);
                                model.Status = (model.Status == "SDS") ? "Buffer" : model.Status;
                                atsInventry.Add(model);
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return atsInventry;
        }

        public async Task<IEnumerable<AtsItem>> GetCatalogGroup(int regionId)
        {
            var atsItem = new List<AtsItem>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetCatalogs";

                        var region = new SqlParameter("regionId", regionId);
                        dbCommand.Parameters.Add(region);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsItem();
                                model.CatalogId = (reader["CatalogId"] == DBNull.Value) ? null : (int?)(reader["CatalogId"]);
                                model.Catalog = (reader["CatalogName"] == DBNull.Value) ? null : Convert.ToString(reader["CatalogName"]);
                                model.CatalogGroupId = (reader["CatalogGroupId"] == DBNull.Value) ? null : (int?)(reader["CatalogGroupId"]);
                                model.CatalogGroup = (reader["CatalogGroupName"] == DBNull.Value) ? null : Convert.ToString(reader["CatalogGroupName"]);
                                atsItem.Add(model);
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return atsItem;
        }

        public async Task<IEnumerable<AtsSite>> GetFulfillmentLocation(int regionId)
        {
            var atsSite = new List<AtsSite>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetFulFillmentLocations";

                        var region = new SqlParameter("regionId", regionId);
                        dbCommand.Parameters.Add(region);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsSite();
                                model.Id = Convert.ToInt32(reader["Id"]);
                                model.SiteName = (reader["Name"] == DBNull.Value) ? null : Convert.ToString(reader["Name"]);
                                model.SiteCode = (reader["FacilityCode"] == DBNull.Value) ? null : Convert.ToString(reader["FacilityCode"]);
                                model.Description = (reader["Description"] == DBNull.Value) ? null : Convert.ToString(reader["Description"]);
                                model.CountryName = (reader["CountryName"] == DBNull.Value) ? null : Convert.ToString(reader["CountryName"]);
                                model.CountryId = Convert.ToInt32(reader["CountryId"]);
                                model.IsActive = Convert.ToBoolean(reader["Active"]);
                                model.Sequence = Convert.ToInt32(reader["Sequence"]);
                                model.Type = (reader["Type"] == DBNull.Value) ? null : Convert.ToString(reader["Type"]);
                                atsSite.Add(model);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return atsSite;
        }

        public async Task<IEnumerable<AtsCountry>> GetCountriesAndCatalogGroups(int regionId)
        {
            var atsCountry = new List<AtsCountry>();
            atsCountry.Clear();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetCountryAndCatalogGroup";

                        var region = new SqlParameter("regionId", regionId);
                        dbCommand.Parameters.Add(region);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsCountry();
                                model.site = new AtsSite();

                                model.Id = Convert.ToInt32(reader["Id"]);
                                model.CatalogCountryBindingID = (reader["CatalogCountryBindingID"] == DBNull.Value) ? null : Convert.ToString(reader["CatalogCountryBindingID"]);
                                model.CountryName = (reader["Name"] == DBNull.Value) ? null : Convert.ToString(reader["Name"]);
                                model.IsCatalogGroup = (reader["IsCatalogGroup"] == DBNull.Value) ? null : (bool?)Convert.ToBoolean(reader["IsCatalogGroup"]);
                                model.CountryIds = (reader["CountryIds"] == DBNull.Value) ? null : Convert.ToString(reader["CountryIds"]);
                                atsCountry.Add(model);
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return atsCountry;
        }

        public async Task<Dictionary<string, int>> GetCountryUsageDetail(int id)
        {
            var atsCountryUsageDetail = new Dictionary<string, int>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetLimitsRegionAndFullfilmentLocations";
                        var countryIdParam = new SqlParameter("@CountryId", id);
                        dbCommand.Parameters.Add(countryIdParam);
                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                atsCountryUsageDetail.Add("Limit", Convert.ToInt32(reader["Limit"]));
                                atsCountryUsageDetail.Add("Region", Convert.ToInt32(reader["Region"]));
                                atsCountryUsageDetail.Add("FulfillmentLocation", Convert.ToInt32(reader["FulfillmentLocation"]));
                                atsCountryUsageDetail.Add("ProductCountry", Convert.ToInt32(reader["ProductCountry"]));
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return atsCountryUsageDetail;
        }

        public async Task<IEnumerable<AtsDataRefresh>> GetAtsItemRefreshDetail(int ProductCountryId)
        {
            var atsRefresh = new List<AtsDataRefresh>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetDataRefreshForProduct";

                        var productCountryId = new SqlParameter("@ProductCountryId", ProductCountryId);
                        dbCommand.Parameters.Add(productCountryId);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsDataRefresh();
                                model.Item = (reader["Item"] == DBNull.Value) ? null : Convert.ToString(reader["Item"]);
                                model.RefreshTime = (reader["RefreshTime"] == DBNull.Value) ? (DateTime?)null : Convert.ToDateTime(reader["RefreshTime"]);
                                atsRefresh.Add(model);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return atsRefresh;
        }

        public async Task<IEnumerable<AtsStatusHistory>> GetAtsStatusHistory(int ProductCountryId)
        {
            var atsRefresh = new List<AtsStatusHistory>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetStatusHistory";

                        var productCountryId = new SqlParameter("@ProductCountryId", ProductCountryId);
                        dbCommand.Parameters.Add(productCountryId);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsStatusHistory();
                                model.HistoryId = (reader["HistoryId"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["HistoryId"]);
                                model.CreatedBy = (reader["CreatedBy"] == DBNull.Value) ? null : Convert.ToString(reader["CreatedBy"]);
                                model.CreatedOn = (reader["CreatedOn"] == DBNull.Value) ? (DateTime?)null : Convert.ToDateTime(reader["CreatedOn"]);
                                model.FromStatus = (reader["FromStatus"] == DBNull.Value) ? null : Convert.ToString(reader["FromStatus"]);
                                model.ToState = (reader["ToStatus"] == DBNull.Value) ? null : Convert.ToString(reader["ToStatus"]);
                                atsRefresh.Add(model);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return atsRefresh;
        }

        public async Task<IEnumerable<AtsLeadTimeHistory>> GetLeadTimeHistory(int ProductCountryId)
        {
            var atsLeadTime = new List<AtsLeadTimeHistory>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetLeadTimeHistory";

                        var productCountryId = new SqlParameter("@ProductCountryId", ProductCountryId);
                        dbCommand.Parameters.Add(productCountryId);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsLeadTimeHistory();
                                model.UpdatedBy = (reader["UpdatedBy"] == DBNull.Value) ? null : Convert.ToString(reader["UpdatedBy"]);
                                model.ChangedOn = (reader["LeadTimeChangedDateTime"] == DBNull.Value) ? (DateTime?)null : Convert.ToDateTime(reader["LeadTimeChangedDateTime"]);
                                model.FromLeadTime = (reader["FromLeadTime"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["FromLeadTime"]);
                                model.ToLeadTime = (reader["ToLeadTime"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["ToLeadTime"]);
                                atsLeadTime.Add(model);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return atsLeadTime;
        }

        public async Task<IEnumerable<AtsItemDetail>> GetAtsItemDetail(int ProductCountryId)
        {
            var atsItemDetail = new List<AtsItemDetail>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetItemInfo";

                        var productCountryId = new SqlParameter("@ProductCountryId", ProductCountryId);
                        dbCommand.Parameters.Add(productCountryId);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsItemDetail();
                                model.LTSource = (reader["LeadTimeSource"] == DBNull.Value) ? null : Convert.ToString(reader["LeadTimeSource"]);

                                model.LeadTime = (reader["LeadTime"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["LeadTime"]);
                                model.DefaultLT = (reader["DefaultLeadTime"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["DefaultLeadTime"]);
                                model.ExtendedLeadTime = (reader["ExtendedLeadTime"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["ExtendedLeadTime"]);
                                model.AllowAutoXLT = (reader["AllowAutoXLT"] == DBNull.Value) ? false : Convert.ToBoolean(reader["AllowAutoXLT"]);
                                model.ExtendedLeadTimeThresold = (reader["ExtendedLeadTimeThreshold"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["ExtendedLeadTimeThreshold"]);
                                model.OutOfStockThresold = (reader["OutOfStockThreshold"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["OutOfStockThreshold"]);
                                model.LowThreshold = (reader["LowThreshold"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["LowThreshold"]);
                                model.SameDayShippingThreshold = (reader["SameDayShippingThreshold"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["SameDayShippingThreshold"]);

                                model.ContinueToSell = Convert.ToBoolean(reader["IsContinuteToSell"]);
                                model.DisplayLowInventry = Convert.ToBoolean(reader["DisplayLowInventory"]);
                                model.IsEligibleForSmartLogo = Convert.ToBoolean(reader["IsEligibleForSmartSelectLogo"]);
                                model.ItemInventryStatus = (reader["InventoryStatus"] == DBNull.Value) ? null : Convert.ToString(reader["InventoryStatus"]);
                                model.IsFirstTrackEligible = Convert.ToBoolean(reader["IsFastTrackEligible"]);
                                model.AvailabletoSellQuantiry = (reader["AvailableToSellQuantity"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["AvailableToSellQuantity"]);
                                model.SDS = Convert.ToBoolean(reader["SDSEnabled"]);
                                model.Active = Convert.ToBoolean(reader["IsActive"]);
                                model.AutoXltIncrement = (reader["AutoXltIncrement"] == DBNull.Value) ? 1 : Convert.ToInt32(reader["AutoXltIncrement"]);
                                atsItemDetail.Add(model);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return atsItemDetail;
        }

        public async Task<IEnumerable<AtsDaysofSupply>> GetDaysofSupply(int ProductCountryId)
        {
            var atsIncomingSupply = new List<AtsDaysofSupply>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_FetchDaysofSupply_2012I1";

                        var productCountryId = new SqlParameter("@ProductCountryId", ProductCountryId);
                        dbCommand.Parameters.Add(productCountryId);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsDaysofSupply();
                                model.TimeFrame = (reader["TimeFrame"] == DBNull.Value) ? string.Empty : Convert.ToString(reader["TimeFrame"]);
                                model.Sales = (reader["Sales"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["Sales"]);
                                model.DSI = (reader["DSI"] == DBNull.Value) ? 0.0 : Convert.ToDouble(reader["DSI"]);

                                atsIncomingSupply.Add(model);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return atsIncomingSupply;
        }

        public async Task<AtsProductCountry> GetProductCountryDefaults()
        {
            AtsProductCountry prodCountry = new AtsProductCountry();

            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    connection.Open();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetProductDefaults";

                        using (var reader = dbCommand.ExecuteReader())
                        {
                            while (await reader.ReadAsync())
                            {
                                prodCountry.Low = Convert.ToInt32(reader["LowThreshold"]);
                                prodCountry.Oversell = Convert.ToInt32(reader["OversellThreshold"]);
                                prodCountry.Oversold = Convert.ToInt32(reader["OversoldThreshold"]);
                                prodCountry.SDS = Convert.ToInt32(reader["SameDayShippingThreshold"]);
                                prodCountry.ContinueToSell = Convert.ToBoolean(reader["ContinueToSell"]);
                                prodCountry.LeadTime = Convert.ToInt32(reader["StandardLeadTime"]); ;
                                prodCountry.ExtendedLeadTime = Convert.ToInt32(reader["ExtendedLeadTime"]);
                                prodCountry.DisplayLowInventory = Convert.ToBoolean(reader["DisplayLowInventory"]);
                                prodCountry.IncludePreCheckout = Convert.ToBoolean(reader["IncludePreCheckout"]);
                                prodCountry.IncludePostCheckout = Convert.ToBoolean(reader["IncludePostCheckout"]);
                            }
                        }
                    }
                }

                return prodCountry;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }

        }

        public IEnumerable<AtsProdType> GetProductTypes()
        {
            AtsProdType ProdType;
            var ProdTypeLst = new List<AtsProdType>();

            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    connection.Open();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "PROC_ATS_GetAllProductTypes_2013R5";

                        using (var reader = dbCommand.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ProdType = new AtsProdType();

                                ProdType.Id = Convert.ToInt32(reader["Id"]);
                                ProdType.Name = Convert.ToString(reader["Name"]);

                                ProdTypeLst.Add(ProdType);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return ProdTypeLst;
        }

        public async Task<IEnumerable<AtsProductInfo>> GetProductLines(Int32 catalogId)
        {
            var productLines = new List<AtsProductInfo>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_SV_GetProductLines";

                        var prdId = new SqlParameter("@CatalogId", catalogId);

                        dbCommand.Parameters.Add(prdId);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsProductInfo();
                                model.ID = (reader["ID"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["ID"]);
                                model.Name = Convert.ToString(reader["Name"]);
                                productLines.Add(model);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return productLines;
        }

        public async Task<IEnumerable<AtsBrand>> GetBrands(Int32 productlineId)
        {
            var brands = new List<AtsBrand>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_SV_GetBrands";

                        var prdProductLineId = new SqlParameter("@ProductLineID", productlineId);

                        dbCommand.Parameters.Add(prdProductLineId);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsBrand();
                                model.ID = (reader["ID"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["ID"]);
                                model.Name = Convert.ToString(reader["Name"]);
                                brands.Add(model);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return brands;
        }

        public async Task<IEnumerable<RegionItem>> GetAllRegions()
        {
            var regionItems = new List<RegionItem>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "PROC_ATS_GetAllRegions_2012R2";

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var regionItem = new RegionItem();
                                regionItem.ID = (reader["ID"] == DBNull.Value) ? null : (int?)(reader["ID"]);
                                regionItem.Name = (reader["Name"] == DBNull.Value) ? null : Convert.ToString(reader["Name"]);
                                regionItem.CountryID = (reader["CountryID"] == DBNull.Value) ? null : (int?)(reader["CountryID"]);
                                regionItems.Add(regionItem);
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return regionItems;
        }

        public async Task<IEnumerable<AtsCountry>> GetCountries(int regionId)
        {
            var atsCountry = new List<AtsCountry>();
            atsCountry.Clear();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetCountry";

                        var region = new SqlParameter("@regionId", regionId);
                        dbCommand.Parameters.Add(region);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsCountry();
                                model.site = new AtsSite();

                                model.Id = Convert.ToInt32(reader["Id"]);
                                model.CountryName = (reader["Name"] == DBNull.Value) ? null : Convert.ToString(reader["Name"]);
                                model.Code = (reader["Code"] == DBNull.Value) ? null : Convert.ToString(reader["Code"]);
                                model.RegionId = (reader["Region"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["Region"]);
                                model.site.Id = Convert.ToInt32(reader["FulfillmentLocationId"] == DBNull.Value ? -1 : reader["FulfillmentLocationId"]);
                                model.site.SiteCode = (reader["FulfillmentLocationCode"] == DBNull.Value) ? null : Convert.ToString(reader["FulfillmentLocationCode"]);
                                model.AllowFutureCommit = (reader["AllowFutureCommit"] == DBNull.Value) ? null : (bool?)Convert.ToBoolean(reader["AllowFutureCommit"]);
                                atsCountry.Add(model);
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return atsCountry;
        }

        private List<AtsCountry> FetchCountries(int regionId)
        {
            var atsCountry = new List<AtsCountry>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetCountry";

                        var region = new SqlParameter("@regionId", regionId);
                        dbCommand.Parameters.Add(region);

                        using (var reader = dbCommand.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var model = new AtsCountry();

                                model.Id = Convert.ToInt32(reader["Id"]);
                                model.CountryName = (reader["Name"] == DBNull.Value) ? null : Convert.ToString(reader["Name"]);
                                model.Code = (reader["Code"] == DBNull.Value) ? null : Convert.ToString(reader["Code"]);
                                model.RegionId = (reader["Region"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["Region"]);
                                atsCountry.Add(model);
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return atsCountry;
        }

        public async Task<AtsProductInfo> GetProductInformation(int productID, int regionId)
        {
            AtsProductInfo product = new AtsProductInfo();
            //added await to resolving refresh issues
            await GetProductInfo(productID, product);
            await GetProductCountries(productID, product, regionId);
            await GetProductCatalogs(productID, product, regionId);
            return product;
        }

        private async Task GetProductInfo(int productID, AtsProductInfo product)
        {
            AtsProductInfo productInfo = new AtsProductInfo();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "PROC_ATS_GetProductInfo_2014R11_8";

                        var prdID = new SqlParameter("@ProductID", productID);
                        dbCommand.Parameters.Add(prdID);

                        using (var reader = dbCommand.ExecuteReader())
                        {

                            while (await reader.ReadAsync())
                            {
                                product.Active = Convert.ToBoolean(reader["Active"]);
                                product.Description = Convert.ToString(reader["Description"]);
                                product.FGA = Convert.ToString(reader["FGA"]);
                                product.ID = Convert.ToInt32(reader["Id"]);
                                product.Name = Convert.ToString(reader["Name"]);
                                product.Offer = Convert.ToString(reader["OfferType"]);
                                product.SKU = Convert.ToString(reader["SKU"]);
                                product.ProductType = Convert.ToInt32(reader["ProductTypeId"]);

                                product.ProductTypeName = (from p in GetProductTypes()
                                                           where p.Id == product.ProductType
                                                           select p.Name).FirstOrDefault();

                                product.SeperateMessaging = Convert.ToBoolean(reader["Messaging"]);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }

        }

        private async Task GetProductCountries(int productID, AtsProductInfo product, int regionId)
        {

            AtsProductCountry prodCountry;
            List<AtsProductCountry> prodCountrylst = new List<AtsProductCountry>();
            var allCountries = FetchCountries(regionId);
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetProductCountry";

                        var prdID = new SqlParameter("@ProductID", productID);
                        var region = new SqlParameter("@regionId", regionId);

                        dbCommand.Parameters.Add(prdID);
                        dbCommand.Parameters.Add(region);

                        using (var reader = dbCommand.ExecuteReader())
                        {
                            while (await reader.ReadAsync())
                            {
                                prodCountry = new AtsProductCountry();
                                prodCountry.CountryID = Convert.ToInt32(reader["CountryID"]);
                                prodCountry.CountryIds = (reader["CountryIDs"] == DBNull.Value) ? string.Empty : Convert.ToString(reader["CountryIDs"]);
                                prodCountry.CatalogCountryBindingID = (reader["CatalogCountryBindingID"] == DBNull.Value) ? string.Empty : Convert.ToString(reader["CatalogCountryBindingID"]);
                                prodCountry.CountryName = allCountries.FirstOrDefault(c => c.Id == prodCountry.CountryID).CountryName;
                                prodCountry.CountryName = (reader["CountryCatalogGroupName"] == DBNull.Value) ? string.Empty : Convert.ToString(reader["CountryCatalogGroupName"]);
                                prodCountry.ContinueToSell = (reader["ContinueToSell"] == DBNull.Value) ? false : Convert.ToBoolean(reader["ContinueToSell"]);
                                prodCountry.LeadTime = (reader["DefaultLeadTime"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["DefaultLeadTime"]);//TODO:Make type as nullable. So incase data is null then same will propagete to UI.
                                prodCountry.ExtendedLeadTime = (reader["ExtendedLeadTime"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["ExtendedLeadTime"]);//TODO:Make type as nullable. So incase data is null then same will propagete to UI.
                                prodCountry.DisplayLowInventory = (reader["DisplayLowInventory"] == DBNull.Value) ? false : Convert.ToBoolean(reader["DisplayLowInventory"]);
                                prodCountry.IncludePreCheckout = (reader["IncludePreCheckout"] == DBNull.Value) ? false : Convert.ToBoolean(reader["IncludePreCheckout"]);
                                prodCountry.IncludePostCheckout = (reader["IncludePostCheckout"] == DBNull.Value) ? false : Convert.ToBoolean(reader["IncludePostCheckout"]);
                                prodCountry.Low = (reader["LowStockLimit"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["LowStockLimit"]);//TODO:Make type as nullable. So incase data is null then same will propagete to UI.
                                prodCountry.SDS = (reader["SameDayShippingStockLimit"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["SameDayShippingStockLimit"]);//TODO:Make type as nullable. So incase data is null then same will propagete to UI.
                                prodCountry.Oversell = (reader["InOversellStockLimit"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["InOversellStockLimit"]);//TODO:Make type as nullable. So incase data is null then same will propagete to UI.
                                prodCountry.Oversold = (reader["InOversoldStockLimit"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["InOversoldStockLimit"]);//TODO:Make type as nullable. So incase data is null then same will propagete to UI.
                                prodCountry.SDSEnabled = (reader["SDSEnabled"] == DBNull.Value) ? false : Convert.ToBoolean(reader["SDSEnabled"]);
                                prodCountrylst.Add(prodCountry);
                            }
                        }
                    }
                }

                product.ProductCountries = prodCountrylst;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }

        }

        private async Task GetProductCatalogs(int productID, AtsProductInfo product, int regionId)
        {

            List<AtsProductCatalog> prodCataloglst = new List<AtsProductCatalog>();
            AtsProductCatalog prodCatalog;
            var allCountries = FetchCountries(regionId);
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetProductCatalogs";

                        var prdID = new SqlParameter("@ProductID", productID);
                        dbCommand.Parameters.Add(prdID);

                        using (var reader = dbCommand.ExecuteReader())
                        {
                            while (await reader.ReadAsync())
                            {
                                prodCatalog = new AtsProductCatalog();

                                prodCatalog.CountryID = Convert.ToInt32(reader["CountryID"]);

                                var country = allCountries.FirstOrDefault(c => c.Id == prodCatalog.CountryID);
                                if (country == null)
                                {
                                    prodCatalog.CountryName = string.Empty;
                                }
                                else
                                {
                                    prodCatalog.CountryName = country.CountryName;
                                }

                                prodCatalog.CatalogID = Convert.ToInt32(reader["CatalogID"]);
                                prodCatalog.SalesViewVisibility = Convert.ToBoolean(reader["SVVisibility"]);
                                prodCatalog.eQuote = Convert.ToString(reader["eQuote"]);
                                prodCatalog.OrderQuote = Convert.ToString(reader["OrderQuote"]);
                                prodCataloglst.Add(prodCatalog);
                            }
                        }
                    }
                }

                if (prodCataloglst.Count > 0)
                {
                    product.ProductCatalogs = prodCataloglst;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }

        }

        public async Task<IEnumerable<int>> GetDefaultCatalog(int CountryId)
        {
            List<int> defaultCatalogIds = new List<int>();
            using (var connection = _atsQueryDbFactory.Database.CreateConnection())
            {
                await connection.OpenAsync();
                using (var dbCommand = connection.CreateCommand())
                {
                    dbCommand.CommandType = CommandType.StoredProcedure;
                    dbCommand.CommandText = "DPM_ATS_GetDefaultCatalog";
                    dbCommand.Parameters.Add(new SqlParameter("@CountryId", CountryId));
                    using (var reader = await dbCommand.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            defaultCatalogIds.Add((int)(reader["DefaultCatalogId"]));
                        }
                    }
                }
            }
            return defaultCatalogIds;
        }

        public async Task<IEnumerable<DefaultCatalogRequest>> GetDefaultCatalogs(List<int> CountryIds)
        {
            List<DefaultCatalogRequest> defaultCatalogs = new List<DefaultCatalogRequest>();
            using (var connection = _atsQueryDbFactory.Database.CreateConnection())
            {
                await connection.OpenAsync();
                foreach (var countryId in CountryIds)
                {
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetDefaultCatalog";
                        dbCommand.Parameters.Add(new SqlParameter("@CountryId", countryId));
                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                defaultCatalogs.Add(new DefaultCatalogRequest { CountryId = countryId, DefaultCatalogId = (reader["DefaultCatalogId"] == DBNull.Value) ? null : (int?)(reader["DefaultCatalogId"]) });
                            }
                        }
                    }
                }
            }
            return defaultCatalogs;
        }

        public async Task<IEnumerable<AtsCatalog>> GetCatalog(AtsCatalog Item)
        {
            var catalogs = new List<AtsCatalog>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetRegions";

                        var CountryName = new SqlParameter("@CountryName", Item.CountryName);
                        var RegionCode = new SqlParameter("@RegionCode", Item.RegionCode);
                        var CatalogId = new SqlParameter("@CatalogId", Item.CatalogId);

                        dbCommand.Parameters.Add(CountryName);
                        dbCommand.Parameters.Add(RegionCode);
                        dbCommand.Parameters.Add(CatalogId);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsCatalog();
                                model.Id = (reader["Id"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["Id"]);
                                model.CountryId = (reader["CountryId"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["CountryId"]);
                                model.CountryName = (reader["CountryName"] == DBNull.Value) ? null : Convert.ToString(reader["CountryName"]);
                                model.RegionCode = (reader["RegionCode"] == DBNull.Value) ? null : Convert.ToString(reader["RegionCode"]);
                                model.CatalogId = (reader["CatalogId"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["CatalogId"]);

                                catalogs.Add(model);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return catalogs;
        }

        public async Task<IEnumerable<AtsCatalog>> GetCatalogs(AtsCatalog Item)
        {
            var catalogs = new List<AtsCatalog>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetAllCatalogs";

                        var CountryName = new SqlParameter("@CountryName", Item.CountryName);
                        var RegionCode = new SqlParameter("@RegionCode", Item.RegionCode);
                        var CatalogId = new SqlParameter("@CatalogId", Item.CatalogId);
                        var RegionId = new SqlParameter("@RegionId", Item.RegionId);

                        dbCommand.Parameters.Add(CountryName);
                        dbCommand.Parameters.Add(RegionCode);
                        dbCommand.Parameters.Add(CatalogId);
                        dbCommand.Parameters.Add(RegionId);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsCatalog();
                                model.Id = (reader["Id"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["Id"]);
                                model.CountryId = (reader["CountryId"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["CountryId"]);
                                model.CountryName = (reader["CountryName"] == DBNull.Value) ? null : Convert.ToString(reader["CountryName"]);
                                model.RegionCode = (reader["RegionCode"] == DBNull.Value) ? null : Convert.ToString(reader["RegionCode"]);
                                model.CatalogId = (reader["CatalogId"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["CatalogId"]);

                                catalogs.Add(model);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return catalogs;
        }

        public async Task<IEnumerable<AtsCommitDetail>> GetCommitDetail(int ProductCountryId)
        {
            var atsCommit = new List<AtsCommitDetail>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetCommitDetails";

                        var productCountryId = new SqlParameter("@ProductCountryId", ProductCountryId);
                        dbCommand.Parameters.Add(productCountryId);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsCommitDetail();

                                model.CommitedOn = (reader["UpdateDateTime"] == DBNull.Value) ? (DateTime?)null : Convert.ToDateTime(reader["UpdateDateTime"]);
                                model.ReservedOn = (reader["LastUpdatedAt"] == DBNull.Value) ? (DateTime?)null : Convert.ToDateTime(reader["LastUpdatedAt"]);
                                model.TieNumber = (reader["Tienumber"] == DBNull.Value) ? null : Convert.ToString(reader["Tienumber"]);
                                model.ReservationId = (reader["Id"] == DBNull.Value) ? null : Convert.ToString(reader["Id"]);
                                model.FacilityCode = (reader["FacilityCode"] == DBNull.Value) ? null : Convert.ToString(reader["FacilityCode"]);
                                model.Quantity = (reader["Quantity"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["Quantity"]);
                                model.OrderNumber = (reader["OrderNumber"] == DBNull.Value) ? null : Convert.ToString(reader["OrderNumber"]);
                                model.Segment = (reader["Segment"] == DBNull.Value) ? null : Convert.ToString(reader["Segment"]);
                                model.IRN = (reader["IRN"] == DBNull.Value) ? null : Convert.ToString(reader["IRN"]);
                                model.Name = (reader["NAME"] == DBNull.Value) ? null : Convert.ToString(reader["NAME"]);
                                model.ShipToContactName = (reader["ShipToContactName"] == DBNull.Value) ? null : Convert.ToString(reader["ShipToContactName"]);
                                model.BillingCompanyName = (reader["BillingCompanyName"] == DBNull.Value) ? null : Convert.ToString(reader["BillingCompanyName"]);
                                model.CustomerName = (reader["CustomerName"] == DBNull.Value) ? null : Convert.ToString(reader["CustomerName"]);
                                model.FulfillmentLocation = (reader["FulfillmentLocation"] == DBNull.Value) ? null : Convert.ToString(reader["FulfillmentLocation"]);
                                model.BusinessUnitCode = (reader["BusinessUnitCode"] == DBNull.Value) ? null : Convert.ToString(reader["BusinessUnitCode"]);
                                model.GossStatus = "Not Available";
                                atsCommit.Add(model);
                            }

                            if (atsCommit != null && atsCommit.Count() > 0)
                            {
                                IEnumerable<OrderStatus> OrderStatusLookup = GetOrderStatusLookup();
                                //TODO:::
                                //GossApiUtil.UpdateOrderGossStatus(atsCommit, OrderStatusLookup);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return atsCommit;
        }

        public async Task<IEnumerable<AtsApplication>> GetApplications()
        {
            var atsApplications = new List<AtsApplication>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetApplicationList";

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var atsApplication = new AtsApplication();
                                atsApplication.Id = Convert.ToInt32(reader["Id"]);
                                atsApplication.Name = (reader["Name"] == DBNull.Value) ? null : Convert.ToString(reader["Name"]);
                                atsApplication.Code = (reader["Code"] == DBNull.Value) ? null : Convert.ToString(reader["Code"]);
                                atsApplications.Add(atsApplication);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return atsApplications;
        }

        public async Task<AtsAppConfigList> GetApplicationConfigurations(AtsAppConfigRequest appConfigReq)
        {
            var atsApplicationConfigurations = new AtsAppConfigList();
            atsApplicationConfigurations.AtsApplicationConfigurationList = new List<AtsApplicationConfiguration>();
            atsApplicationConfigurations.AtsApplicationConfigurationList.Clear();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetApplicationConfigurations";

                        var ApplicationIdParam = new SqlParameter("@AppId", (appConfigReq.ApplicationIds == "null" ? null : appConfigReq.ApplicationIds));
                        var ConfigIdParam = new SqlParameter("@ConfigId", (appConfigReq.ConfigIDs == "null" ? null : appConfigReq.ConfigIDs));
                        var ConfigValueParam = new SqlParameter("@ConfigValue", (appConfigReq.ConfigValues == "null" ? null : appConfigReq.ConfigValues));
                        var StatusParam = new SqlParameter("@Status", (appConfigReq.Status == "null" ? null : appConfigReq.Status));
                        var pageNumberParam = new SqlParameter("@PageNumber", appConfigReq.PageNumber);
                        var pageSizeParam = new SqlParameter("@PageSize", appConfigReq.PageSize);
                        var prmTotalRowsParam = new SqlParameter() { ParameterName = "@TotalRows", Direction = ParameterDirection.Output, SqlDbType = SqlDbType.Int };
                        dbCommand.Parameters.Add(ApplicationIdParam);
                        dbCommand.Parameters.Add(ConfigIdParam);
                        dbCommand.Parameters.Add(ConfigValueParam);
                        dbCommand.Parameters.Add(StatusParam);
                        dbCommand.Parameters.Add(pageNumberParam);
                        dbCommand.Parameters.Add(pageSizeParam);
                        dbCommand.Parameters.Add(prmTotalRowsParam);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var atsApplicationConfiguration = new AtsApplicationConfiguration();
                                atsApplicationConfiguration.ConfigID = Convert.ToInt32(reader["ConfigID"]);
                                atsApplicationConfiguration.ApplicationID = Convert.ToInt32(reader["ApplicationID"]);
                                atsApplicationConfiguration.ConfigName = (reader["ConfigName"] == DBNull.Value) ? null : Convert.ToString(reader["ConfigName"]);
                                atsApplicationConfiguration.TrimmedConfigName = (reader["TrimmedConfigValue"] == DBNull.Value) ? null : Convert.ToString(reader["TrimmedConfigValue"]);
                                atsApplicationConfiguration.ApplicationName = (reader["ApplicationName"] == DBNull.Value) ? null : Convert.ToString(reader["ApplicationName"]);
                                atsApplicationConfiguration.ConfigValue = (reader["ConfigValue"] == DBNull.Value) ? null : Convert.ToString(reader["ConfigValue"]);
                                atsApplicationConfiguration.IsActive = (reader["Active"] == DBNull.Value) ? null : (bool?)reader["Active"];
                                atsApplicationConfigurations.AtsApplicationConfigurationList.Add(atsApplicationConfiguration);
                            }
                        }
                        atsApplicationConfigurations.RecordCount = (prmTotalRowsParam.Value == DBNull.Value) ? null : (int?)prmTotalRowsParam.Value;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return atsApplicationConfigurations;
        }

        public async Task<AtsAppConfigList> GetApplicationRuleConfigurations(AtsAppConfigRequest appConfigReq)
        {
            int catalogId, productLineId, brandId, familyId;
            string catalog, productLine, brand, family;
            var atsApplicationConfigurations = new AtsAppConfigList();
            atsApplicationConfigurations.AtsApplicationConfigurationList = new List<AtsApplicationConfiguration>();
            atsApplicationConfigurations.AtsApplicationConfigurationList.Clear();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetApplicationRuleConfigurations";

                        var ApplicationIdParam = new SqlParameter("@AppId", (appConfigReq.ApplicationIds == "null" ? null : appConfigReq.ApplicationIds));
                        var ConfigIdParam = new SqlParameter("@ConfigId", (appConfigReq.ConfigIDs == "null" ? null : appConfigReq.ConfigIDs));
                        var ConfigValueParam = new SqlParameter("@ConfigValue", (appConfigReq.ConfigValues == "null" ? null : appConfigReq.ConfigValues));
                        var StatusParam = new SqlParameter("@Status", (appConfigReq.Status == "null" ? null : appConfigReq.Status));
                        var pageNumberParam = new SqlParameter("@PageNumber", appConfigReq.PageNumber);
                        var pageSizeParam = new SqlParameter("@PageSize", appConfigReq.PageSize);
                        var prmTotalRowsParam = new SqlParameter() { ParameterName = "@TotalRows", Direction = ParameterDirection.Output, SqlDbType = SqlDbType.Int };
                        dbCommand.Parameters.Add(ApplicationIdParam);
                        dbCommand.Parameters.Add(ConfigIdParam);
                        dbCommand.Parameters.Add(ConfigValueParam);
                        dbCommand.Parameters.Add(StatusParam);
                        dbCommand.Parameters.Add(pageNumberParam);
                        dbCommand.Parameters.Add(pageSizeParam);
                        dbCommand.Parameters.Add(prmTotalRowsParam);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var atsApplicationConfiguration = new AtsApplicationConfiguration();
                                atsApplicationConfiguration.ConfigID = Convert.ToInt32(reader["ConfigID"]);
                                atsApplicationConfiguration.ApplicationID = Convert.ToInt32(reader["ApplicationID"]);
                                atsApplicationConfiguration.ConfigName = (reader["ConfigName"] == DBNull.Value) ? null : Convert.ToString(reader["ConfigName"]);
                                atsApplicationConfiguration.TrimmedConfigName = (reader["TrimmedConfigValue"] == DBNull.Value) ? null : Convert.ToString(reader["TrimmedConfigValue"]);
                                atsApplicationConfiguration.ApplicationName = (reader["ApplicationName"] == DBNull.Value) ? null : Convert.ToString(reader["ApplicationName"]);
                                atsApplicationConfiguration.ConfigValue = (reader["ConfigValue"] == DBNull.Value) ? null : Convert.ToString(reader["ConfigValue"]);
                                atsApplicationConfiguration.XMLConfigValue = (reader["ConfigValue"] == DBNull.Value) ? null : Convert.ToString(reader["ConfigValue"]);
                                atsApplicationConfiguration.IsActive = (reader["Active"] == DBNull.Value) ? null : (bool?)reader["Active"];
                                atsApplicationConfigurations.AtsApplicationConfigurationList.Add(atsApplicationConfiguration);
                            }
                        }
                        atsApplicationConfigurations.RecordCount = (prmTotalRowsParam.Value == DBNull.Value) ? null : (int?)prmTotalRowsParam.Value;
                        foreach (var appConfig in atsApplicationConfigurations.AtsApplicationConfigurationList)
                        {
                            appConfig.ConfigValue = ParseRule(appConfig.ConfigValue, out catalogId, out catalog, out productLineId, out productLine, out brandId, out brand, out familyId, out family);
                            appConfig.CatalogId = catalogId;
                            appConfig.CatalogName = catalog;
                            appConfig.ProductLineId = productLineId;
                            appConfig.ProductLine = productLine;
                            appConfig.BrandId = brandId;
                            appConfig.BrandName = brand;
                            appConfig.FamilyId = familyId;
                            appConfig.FamilyName = family;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return atsApplicationConfigurations;
        }

        string ParseRule(string ruleInfo, out int catalogId, out string catalog, out int productLineId, out string productLine, out int brandId, out string brand, out int familyId, out string family)
        {
            catalogId = productLineId = brandId = familyId = 0;
            catalog = productLine = brand = family = string.Empty;
            XmlDocument document = new XmlDocument();
            document.LoadXml(ruleInfo);
            StringBuilder builder = new StringBuilder();
            foreach (XmlNode node in document.DocumentElement.ChildNodes)
            {
                if (node.Name == "CatalogID")
                {
                    catalogId = node.InnerText == string.Empty ? 0 : Convert.ToInt32(node.InnerText);
                }
                else if (node.Name == "CatalogName")
                {
                    builder.Append("Catalog : ");
                    catalog = node.InnerText;
                    builder.Append(node.InnerText);
                    builder.Append(System.Environment.NewLine);
                }
                else if (node.Name == "ProductLineID")
                {
                    productLineId = node.InnerText == string.Empty ? 0 : Convert.ToInt32(node.InnerText);
                }
                else if (node.Name == "ProductLineName")
                {
                    builder.Append("Product Line : ");
                    productLine = node.InnerText;
                    builder.Append(node.InnerText);
                    builder.Append(System.Environment.NewLine);
                }
                else if (node.Name == "BrandID")
                {
                    brandId = node.InnerText == string.Empty ? 0 : Convert.ToInt32(node.InnerText);
                }
                else if (node.Name == "BrandName")
                {
                    builder.Append("Brand : ");
                    brand = node.InnerText;
                    builder.Append(node.InnerText);
                    builder.Append(System.Environment.NewLine);
                }
                else if (node.Name == "FamilyID")
                {
                    familyId = node.InnerText == string.Empty ? 0 : Convert.ToInt32(node.InnerText);
                }
                else if (node.Name == "FamilyName")
                {
                    builder.Append("Family : ");
                    family = node.InnerText;
                    builder.Append(node.InnerText);
                }

            }
            return builder.ToString();
        }

        public async Task<IEnumerable<AtsJobTransactionStatus>> GetTransactionDetails(int regionId)
        {
            var jobTransactions = new List<AtsJobTransactionStatus>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "PROC_ATS_JobTransactionStatus_2014R3"; // JobTransactionStatus

                        var regionIdParam = new SqlParameter("@RegionId", regionId);
                        dbCommand.Parameters.Add(regionIdParam);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsJobTransactionStatus();
                                model.Name = (reader["Name"] == DBNull.Value) ? null : Convert.ToString(reader["Name"]);
                                model.ReservationStatus = (reader["ReservationStatus"] == DBNull.Value) ? null : Convert.ToString(reader["ReservationStatus"]);

                                DateTime? lastUpdatedAt = (reader["LastUpdatedAt"] == DBNull.Value) ? (DateTime?)null : Convert.ToDateTime(reader["LastUpdatedAt"]);
                                if (lastUpdatedAt.HasValue)
                                    model.LastUpdatedAt = string.Format("{0} {1}", lastUpdatedAt.Value.ToString("MM/dd/yyyy hh:mm:ss"), lastUpdatedAt.Value.ToString("tt", CultureInfo.InvariantCulture));//TODO:::

                                model.LastUpdatedBy = (reader["LastUpdatedBy"] == DBNull.Value) ? null : Convert.ToString(reader["LastUpdatedBy"]);

                                jobTransactions.Add(model);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }

            return jobTransactions;
        }
        public async Task<IEnumerable<AtsJobDetails>> GetJobDetails(int regionId)
        {
            var jobDetails = new List<AtsJobDetails>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "SP_GetAllATSJobs_ATS_2014R3"; // DBJobDetails 

                        var regionIdParam = new SqlParameter("@RegionId", regionId);
                        dbCommand.Parameters.Add(regionIdParam);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsJobDetails();
                                model.Source = (reader["JobSource"] == DBNull.Value) ? null : Convert.ToString(reader["JobSource"]);
                                model.Name = (reader["JobName"] == DBNull.Value) ? null : Convert.ToString(reader["JobName"]);
                                model.Description = (reader["JobDescription"] == DBNull.Value) ? null : Convert.ToString(reader["JobDescription"]);
                                model.Status = (reader["JobStatus"] == DBNull.Value) ? null : Convert.ToString(reader["JobStatus"]);
                                model.ExecutionStatus = (reader["JobExecutionStatus"] == DBNull.Value) ? null : Convert.ToString(reader["JobExecutionStatus"]);
                                model.Schedule = (reader["JobSchedule"] == DBNull.Value) ? null : Convert.ToString(reader["JobSchedule"]);

                                DateTime? lastRunTime = (reader["JobLastRunTime"] == DBNull.Value) ? (DateTime?)null : Convert.ToDateTime(reader["JobLastRunTime"]);
                                DateTime? nextRunTime = (reader["JobNextrunTime"] == DBNull.Value) ? (DateTime?)null : Convert.ToDateTime(reader["JobNextrunTime"]);
                                if (lastRunTime.HasValue)
                                    model.LastRunTime = string.Format("{0} {1}", lastRunTime.Value.ToString("MM/dd/yyyy hh:mm:ss"), lastRunTime.Value.ToString("tt", CultureInfo.InvariantCulture));
                                if (nextRunTime.HasValue)
                                    model.NextRunTime = string.Format("{0} {1}", nextRunTime.Value.ToString("MM/dd/yyyy hh:mm:ss"), nextRunTime.Value.ToString("tt", CultureInfo.InvariantCulture));

                                model.ManualOverride = (reader["JobManualOverride"] == DBNull.Value) ? null : Convert.ToString(reader["JobManualOverride"]);
                                model.Action = (reader["JobAction"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["JobAction"]);
                                jobDetails.Add(model);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }

            return jobDetails;
        }
        public async Task<IEnumerable<AtsItemSiteInventory>> GetInventoryStatus(int ProductCountryId)
        {
            var atsInventory = new List<AtsItemSiteInventory>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetItemSiteInventory";

                        var productCountryId = new SqlParameter("@ProductCountryId", ProductCountryId);
                        dbCommand.Parameters.Add(productCountryId);
                        var RegionId = new SqlParameter("@RegionId", 3);
                        dbCommand.Parameters.Add(RegionId);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new AtsItemSiteInventory();
                                model.OnHand = (reader["OnHand"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["OnHand"]);
                                model.FulfillmentLocationName = (reader["FulfillmentLocationName"] == DBNull.Value) ? null : Convert.ToString(reader["FulfillmentLocationName"]);
                                model.FulfillmentLocationId = (reader["FulfillmentLocationId"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["FulfillmentLocationId"]);
                                model.FacilityCode = (reader["FacilityCode"] == DBNull.Value) ? null : Convert.ToString(reader["FacilityCode"]);
                                atsInventory.Add(model);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return atsInventory;
        }

        public async Task<AtsProductConfiguration> GetProductConfiguration()
        {
            var productConfiguration = new AtsProductConfiguration();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetProductConfiguration";

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                productConfiguration.RoutingThreshold = Convert.ToInt32(reader["RoutingThreshold"]);
                                productConfiguration.LowThreshold = Convert.ToInt32(reader["LowThreshold"]);
                                productConfiguration.OversellThreshold = Convert.ToInt32(reader["OversellThreshold"]);
                                productConfiguration.OversoldThreshold = Convert.ToInt32(reader["OversoldThreshold"]);
                                productConfiguration.BufferThreshold = Convert.ToInt32(reader["BufferThreshold"]);
                                productConfiguration.DisplayLowInventory = (reader["DisplayLowInventory"] == DBNull.Value) ? null : (bool?)reader["DisplayLowInventory"];
                                productConfiguration.IncludePreCheckout = (reader["IncludePreCheckout"] == DBNull.Value) ? null : (bool?)reader["IncludePreCheckout"];
                                productConfiguration.IncludeCheckout = (reader["IncludeCheckout"] == DBNull.Value) ? null : (bool?)reader["IncludeCheckout"];
                                productConfiguration.SellAction = (reader["SellAction"] == DBNull.Value) ? null : (bool?)reader["SellAction"];
                                productConfiguration.FGASCDHOverride = (reader["FGASCDHOverride"] == DBNull.Value) ? null : (bool?)reader["FGASCDHOverride"];
                                productConfiguration.SnPSCDHOverride = (reader["SnPSCDHOverride"] == DBNull.Value) ? null : (bool?)reader["SnPSCDHOverride"];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return productConfiguration;
        }

        public async Task<IEnumerable<AtsSite>> GetProductFulfillmentLocation(int ProductCountryId, int Region)
        {
            var productFulfillmentLocation = new List<AtsSite>();
            using (var connection = _atsQueryDbFactory.Database.CreateConnection())
            {
                connection.Open();
                using (var dbCommand = connection.CreateCommand())
                {
                    dbCommand.CommandType = CommandType.StoredProcedure;
                    dbCommand.CommandText = "DPM_ATS_GetProductFulfillment";

                    var productCountryID = new SqlParameter("@ProductCountryId", ProductCountryId);
                    var RegionId = new SqlParameter("@Region", Region);

                    dbCommand.Parameters.Add(productCountryID);
                    dbCommand.Parameters.Add(RegionId);
                    using (var reader = await dbCommand.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            var model = new AtsSite();
                            model.Id = Convert.ToInt32(reader["FulfillmentLocationId"]);
                            model.SiteName = (reader["FulfillmentLocationName"] == DBNull.Value ? null : reader["FulfillmentLocationName"].ToString());
                            model.SiteCode = (reader["FacilityCode"] == DBNull.Value ? null : reader["FacilityCode"].ToString());
                            model.IsActive = (bool)(reader["IsActive"]);
                            productFulfillmentLocation.Add(model);
                        }
                    }
                }
            }
            return productFulfillmentLocation;
        }

        public async Task<InTransitLists> GetInTransit(AtsInTransitSearchRequest Item)
        {
            var lstAtsInTransit = new InTransitLists();
            lstAtsInTransit.AtsInTransit = new List<InTransit>();
            lstAtsInTransit.AtsInTransit.Clear();

            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_InTransitHistory_2018R1";
                        dbCommand.CommandTimeout = 120;

                        var CountryId = new SqlParameter("@CountryId", Item.CountryId);
                        var pageNumber = new SqlParameter("@PageNumber", Item.PageNumber);
                        var pageSize = new SqlParameter("@PageSize", Item.PageSize);
                        var prmTotalRows = new SqlParameter() { ParameterName = "@TotalRows", Direction = ParameterDirection.Output, SqlDbType = SqlDbType.Int };

                        dbCommand.Parameters.Add(CountryId);
                        dbCommand.Parameters.Add(pageNumber);
                        dbCommand.Parameters.Add(pageSize);
                        dbCommand.Parameters.Add(prmTotalRows);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new InTransit();

                                model.SKU = (reader["SKU"] == DBNull.Value) ? null : Convert.ToString(reader["SKU"]);
                                model.PART = (reader["PART"] == DBNull.Value) ? null : Convert.ToString(reader["PART"]);
                                model.QUANTITY = (reader["QUANTITY"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["QUANTITY"]);
                                model.ASSIN = (reader["ASSIN"] == DBNull.Value) ? null : Convert.ToString(reader["ASSIN"]);
                                model.SHIPFROMFACILITY = (reader["SHIPFROMFACILITY"] == DBNull.Value) ? null : Convert.ToString(reader["SHIPFROMFACILITY"]);
                                model.MERGECENTER = (reader["MERGECENTER"] == DBNull.Value) ? null : Convert.ToString(reader["MERGECENTER"]);
                                model.ESTIMATEDARRIVAL = (reader["ESTIMATEDARRIVAL"] == DBNull.Value) ? null : Convert.ToString(reader["ESTIMATEDARRIVAL"]);
                                model.TRANSPORTMODE = (reader["TRANSPORTMODE"] == DBNull.Value) ? null : Convert.ToString(reader["TRANSPORTMODE"]);
                                model.INVENTORYOWNER = (reader["INVENTORYOWNER"] == DBNull.Value) ? null : Convert.ToString(reader["INVENTORYOWNER"]);

                                lstAtsInTransit.AtsInTransit.Add(model);

                            }

                        }
                        lstAtsInTransit.RecordCount = (prmTotalRows.Value == DBNull.Value) ? null : (int?)prmTotalRows.Value;

                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return lstAtsInTransit;
        }
        public async Task<IEnumerable<InTransit>> GetInTransitExport(AtsInTransitSearchRequest Item)
        {
            var lstAtsInTransit = new List<InTransit>();

            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_InTransitHistory_2018R1";
                        dbCommand.CommandTimeout = 120;

                        var CountryId = new SqlParameter("@CountryId", Item.CountryId);
                        var pageNumber = new SqlParameter("@PageNumber", Item.PageNumber);
                        var pageSize = new SqlParameter("@PageSize", Item.PageSize);
                        var prmTotalRows = new SqlParameter() { ParameterName = "@TotalRows", Direction = ParameterDirection.Output, SqlDbType = SqlDbType.Int };

                        dbCommand.Parameters.Add(CountryId);
                        dbCommand.Parameters.Add(pageNumber);
                        dbCommand.Parameters.Add(pageSize);
                        dbCommand.Parameters.Add(prmTotalRows);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var model = new InTransit();

                                model.SKU = (reader["SKU"] == DBNull.Value) ? null : Convert.ToString(reader["SKU"]);
                                model.PART = (reader["PART"] == DBNull.Value) ? null : Convert.ToString(reader["PART"]);
                                model.QUANTITY = (reader["QUANTITY"] == DBNull.Value) ? 0 : Convert.ToInt32(reader["QUANTITY"]);
                                model.ASSIN = (reader["ASSIN"] == DBNull.Value) ? null : Convert.ToString(reader["ASSIN"]);
                                model.SHIPFROMFACILITY = (reader["SHIPFROMFACILITY"] == DBNull.Value) ? null : Convert.ToString(reader["SHIPFROMFACILITY"]);
                                model.MERGECENTER = (reader["MERGECENTER"] == DBNull.Value) ? null : Convert.ToString(reader["MERGECENTER"]);
                                model.ESTIMATEDARRIVAL = (reader["ESTIMATEDARRIVAL"] == DBNull.Value) ? null : Convert.ToString(reader["ESTIMATEDARRIVAL"]);
                                model.TRANSPORTMODE = (reader["TRANSPORTMODE"] == DBNull.Value) ? null : Convert.ToString(reader["TRANSPORTMODE"]);
                                model.INVENTORYOWNER = (reader["INVENTORYOWNER"] == DBNull.Value) ? null : Convert.ToString(reader["INVENTORYOWNER"]);

                                lstAtsInTransit.Add(model);

                            }

                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }

            return lstAtsInTransit;

        }

        public async Task<OrderDetailsSearchResultList> GetOrderDetails(OrderDetailsSearchRequest request)
        {
            var responseList = new OrderDetailsSearchResultList();
            responseList.OrderDetailsList = new List<OrderDetailsSearchResponse>();
            responseList.OrderDetailsList.Clear();

            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_GetOrderDetails";
                        dbCommand.CommandTimeout = 120;

                        dbCommand.Parameters.Add(new SqlParameter("@CountryIds", request.CountryIds));
                        dbCommand.Parameters.Add(new SqlParameter("@SiteIds", request.SiteIds));
                        dbCommand.Parameters.Add(new SqlParameter("@ProductTypeIds", request.ProductTypeIds));
                        dbCommand.Parameters.Add(new SqlParameter("@Parts", request.Parts));
                        dbCommand.Parameters.Add(new SqlParameter("@StatusAge", request.StatusAge));
                        dbCommand.Parameters.Add(new SqlParameter("@Region", 3));
                        dbCommand.Parameters.Add(new SqlParameter("@PageNumber", request.PageNumber));
                        dbCommand.Parameters.Add(new SqlParameter("@PageSize", request.PageSize));

                        var prmTotalRows = new SqlParameter() { ParameterName = "@TotalRows", Direction = ParameterDirection.Output, SqlDbType = SqlDbType.Int };
                        dbCommand.Parameters.Add(prmTotalRows);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                orderDetailsSearchResponse = new OrderDetailsSearchResponse();
                                orderDetailsSearchResponse.ProductTypeId = (reader["ProductTypeId"] == DBNull.Value) ? null : (int?)(reader["ProductTypeId"]);
                                orderDetailsSearchResponse.ProductType = (reader["Type"] == DBNull.Value) ? null : Convert.ToString(reader["Type"]);
                                orderDetailsSearchResponse.CountryId = (reader["CountryId"] == DBNull.Value) ? null : (int?)(reader["CountryId"]);
                                orderDetailsSearchResponse.Country = (reader["Country"] == DBNull.Value) ? null : Convert.ToString(reader["Country"]);
                                orderDetailsSearchResponse.SiteId = (reader["SiteId"] == DBNull.Value) ? null : (int?)(reader["SiteId"]);
                                orderDetailsSearchResponse.SiteCode = (reader["SiteCode"] == DBNull.Value) ? null : Convert.ToString(reader["SiteCode"]);
                                orderDetailsSearchResponse.SiteName = (reader["SiteName"] == DBNull.Value) ? null : Convert.ToString(reader["SiteName"]);
                                orderDetailsSearchResponse.SKU = (reader["SKU"] == DBNull.Value) ? null : Convert.ToString(reader["SKU"]);
                                orderDetailsSearchResponse.FGA = (reader["FGA"] == DBNull.Value) ? null : Convert.ToString(reader["FGA"]);
                                orderDetailsSearchResponse.OrderNumber = (reader["OrderNumber"] == DBNull.Value) ? null : (long?)(reader["OrderNumber"]);
                                orderDetailsSearchResponse.OrderQuantity = (reader["OrderQuantity"] == DBNull.Value) ? null : (int?)(reader["OrderQuantity"]);
                                orderDetailsSearchResponse.StatusAge = (reader["StatusAge"] == DBNull.Value) ? null : (int?)(reader["StatusAge"]);
                                responseList.OrderDetailsList.Add(orderDetailsSearchResponse);
                            }
                        }

                        responseList.RecordCount = (prmTotalRows.Value == DBNull.Value) ? null : (int?)prmTotalRows.Value;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }

            return responseList;
        }

        public async Task<IEnumerable<OrderDetailsSearchResponse>> GetOrderExportDetails(OrderDetailsSearchRequest request)
        {
            var Result = GetOrderDetails(new OrderDetailsSearchRequest
            {
                CountryIds = request.CountryIds,
                SiteIds = request.SiteIds,
                ProductTypeIds = request.ProductTypeIds,
                Parts = request.Parts,
                StatusAge = request.StatusAge,
                PageNumber = request.PageNumber,
                PageSize = request.PageSize
            }
            );

            await Task.WhenAll(Result);

            response = Result.Result.OrderDetailsList;

            return response;
        }

        public async Task<CommitCalloutDetailResponse> GetCommitCalloutDetails(CommitFalloutRequest request)
        {
            var responseList = new CommitCalloutDetailResponse();
            responseList.CommitCalloutDetails = new List<CommitCalloutDetail>();
            responseList.CommitCalloutDetails.Clear();

            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    await connection.OpenAsync();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "DPM_ATS_CommitFallout";
                        dbCommand.CommandTimeout = 120;

                        dbCommand.Parameters.Add(new SqlParameter("@RegionId", request.RegionId));
                        dbCommand.Parameters.Add(new SqlParameter("@PageNumber", request.PageNumber));
                        dbCommand.Parameters.Add(new SqlParameter("@PageSize", request.PageSize));

                        var prmTotalRows = new SqlParameter() { ParameterName = "@TotalRows", Direction = ParameterDirection.Output, SqlDbType = SqlDbType.Int };
                        dbCommand.Parameters.Add(prmTotalRows);

                        using (var reader = await dbCommand.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                commitCalloutDetail = new CommitCalloutDetail();
                                commitCalloutDetail.SKU = (reader["SKU"] == DBNull.Value) ? null : Convert.ToString(reader["SKU"]);
                                commitCalloutDetail.FGA = (reader["FGA"] == DBNull.Value) ? null : Convert.ToString(reader["FGA"]);
                                commitCalloutDetail.OrderNumber = (reader["OrderNumber"] == DBNull.Value) ? null : Convert.ToString(reader["OrderNumber"]);
                                commitCalloutDetail.Quantity = (reader["Quantity"] == DBNull.Value) ? null : Convert.ToString(reader["Quantity"]);
                                commitCalloutDetail.CountryCode = (reader["CountryCode"] == DBNull.Value) ? null : Convert.ToString(reader["CountryCode"]);
                                commitCalloutDetail.UpdatedDateTime = (reader["UpdateDateTime"] == DBNull.Value) ? (DateTime?)null : Convert.ToDateTime(reader["UpdateDateTime"]);
                                commitCalloutDetail.TieNumber = (reader["TieNumber"] == DBNull.Value) ? null : Convert.ToString(reader["TieNumber"]);
                                commitCalloutDetail.ProductType = (reader["ProductType"] == DBNull.Value) ? null : Convert.ToString(reader["ProductType"]);
                                responseList.CommitCalloutDetails.Add(commitCalloutDetail);
                            }
                        }

                        responseList.RecordCount = (prmTotalRows.Value == DBNull.Value) ? null : (int?)prmTotalRows.Value;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }

            return responseList;
        }

        public async Task<IEnumerable<CommitCalloutDetail>> GetCommitCalloutExportDetails(CommitFalloutRequest request)
        {
            var Result = GetCommitCalloutDetails(request);

            await Task.WhenAll(Result);

            CommitCalloutDetails = Result.Result.CommitCalloutDetails;

            return CommitCalloutDetails;
        }

        private IEnumerable<OrderStatus> GetOrderStatusLookup()
        {
            var orderStatus = new List<OrderStatus>();
            try
            {
                using (var connection = _atsQueryDbFactory.Database.CreateConnection())
                {
                    connection.Open();
                    using (var dbCommand = connection.CreateCommand())
                    {
                        dbCommand.CommandType = CommandType.StoredProcedure;
                        dbCommand.CommandText = "GetOrderStatusName";

                        using (var reader = dbCommand.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var model = new OrderStatus();
                                model.OrderStatusName = (reader["OrderStatusName"] == DBNull.Value) ? null : Convert.ToString(reader["OrderStatusName"]);
                                model.GossStatusCode = (reader["GossCode"] == DBNull.Value) ? null : Convert.ToString(reader["GossCode"]);
                                model.FulfillWarning = (reader["FulfillWarning"] == DBNull.Value) ? false : Convert.ToBoolean(reader["FulfillWarning"]);
                                model.CancelWarning = (reader["CancelWarning"] == DBNull.Value) ? false : Convert.ToBoolean(reader["CancelWarning"]);
                                orderStatus.Add(model);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return orderStatus;
        }

    }
}
