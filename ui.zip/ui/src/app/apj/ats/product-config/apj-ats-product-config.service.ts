import { Injectable } from '@angular/core';
import { DataservicesProvider } from '@Dataservice/dataservices/dataservices';
import { Observable } from 'rxjs/Observable';
import { AtsProductConfiguration, PostData } from './apj-ats-product-config.model';
import { environment } from '@Environments/environment';

@Injectable({
  providedIn: 'root'
})

export class ApjAtsProductConfigService {

  constructor(private _DataservicesProvider: DataservicesProvider) {
  }

  getProductConfiguration(): Observable<AtsProductConfiguration> {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'GetProductConfiguration');
  }

  updateProductConfiguration(postData: PostData) {
    return this._DataservicesProvider.PostData(environment.ApjEmeaAtsApiUrl + 'command/updateProductConfiguration', postData);
  }
}
