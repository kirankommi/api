﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class AtsProductCountryDeleteRequest
    {
        public AtsProductInfo ProductInfo { get; set; }
        public string ProductId { get; set; }
        public string FgaId { get; set; }
        public string Error { get; set; }
        public AtsProductCountry ProductCountryToDelete { get; set; }
    }
}
