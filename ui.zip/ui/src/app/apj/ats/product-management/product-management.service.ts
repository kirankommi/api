import { Injectable } from '@angular/core';
import { DataservicesProvider } from '@Dataservice/dataservices/dataservices';
import { environment } from '@Environments/environment';


@Injectable({
  providedIn: 'root'

})
export class ProductManagementService {
  constructor(private _DataservicesProvider: DataservicesProvider) {

  }

  GetProductTypes() {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'GetProductTypes/');
  }
  getCountries(regionId) {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getCountries/'+regionId);
  }
  getCountriesAndCatalogGroups(regionId) {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getCountriesAndCatalogGroups/'+regionId);
  }
  GetProductDetails(productId,regionId) {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'GetProductDetails/'+productId+'/'+regionId);
  }
  GetProductCountryDefaults() {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'GetProductCountryDefaults/');
  }
  getAllRegions() {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getAllRegions/');
  }
  updateProductInformation(productInfo) {
    var postData = {
      productInfo: productInfo,
      productId: productInfo.id,
      fgaId: productInfo.fga,
      error: ''
    };

    return this._DataservicesProvider.PostDataWithHeader(environment.ApjEmeaAtsApiUrl + 'command/updateProductInformation/', postData);
  }

  

}
