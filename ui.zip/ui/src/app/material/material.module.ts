import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule,MatTabsModule,MatSelectModule,MatOptionModule,MatToolbarModule, MatButtonModule, MatSidenavModule,
  MatIconModule, MatListModule, MatCardModule,MatTableModule,MatMenuModule, MatFormFieldControl,MatPaginatorModule,MatInputModule,
  MatDatepickerModule, MatRadioModule, MatSlideToggleModule, MatNativeDateModule, MatTooltipModule, MatDialogModule, MatCheckboxModule, MatAutocompleteModule  } from '@angular/material';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MatTabsModule,
    MatFormFieldModule,
    MatSelectModule,
    MatOptionModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatCardModule,
    MatTableModule,
    MatMenuModule,
    MatPaginatorModule,
    MatInputModule, MatDatepickerModule, MatRadioModule, MatSlideToggleModule, MatNativeDateModule, MatTooltipModule, MatDialogModule, MatCheckboxModule, MatAutocompleteModule
  ],
  exports: [
    CommonModule,
    MatTabsModule,
    MatFormFieldModule,
    MatSelectModule,
    MatOptionModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatCardModule,
    MatTableModule,
    MatMenuModule,
    MatPaginatorModule,
    MatInputModule, MatDatepickerModule, MatRadioModule, MatSlideToggleModule, MatNativeDateModule, MatTooltipModule, MatCheckboxModule, MatAutocompleteModule
  ],
})
export class MaterialModule { }
