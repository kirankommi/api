﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsProductCatalog
    {
        public int CountryID { get; set; }
        public string CountryName { get; set; }
        public int CatalogID { get; set; }
        public bool SalesViewVisibility { get; set; }
        public string eQuote { get; set; }
        public string OrderQuote { get; set; }
    }
}