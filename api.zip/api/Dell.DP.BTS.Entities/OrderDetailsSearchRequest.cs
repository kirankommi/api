﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class OrderDetailsSearchRequest
    {
        public string CountryIds { get; set; }
        public string SiteIds { get; set; }
        public string ProductTypeIds { get; set; }
        public string Parts { get; set; }
        public int StatusAge { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}
