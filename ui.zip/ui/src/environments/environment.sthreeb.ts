export const environment = {
  production: true,
  ApjEmeaAtsApiUrl: 'https://dpemeaapjbtsinternalapi.ausmpc.pcf.dell.com/api/'

};
