export class AtsItemSearchRequest {
  sku: string;
  type: string;
  part: string;
  countryId: string;
  catalogGroupIds: string;
  regionId: number;
  stockStatus: string;
  catalogId: string;
  locationCode: string;
  isContinueToSell: string;
  isActive: string;
  salesChannel: number;
  sdsEnable: number;
  pageNumber: number;
  pageSize: number;
}
export interface UserData {

  sku: string;
  part: string;
  brand: string;
  description: string;
  type: string;
  offerType: string;
  catalogGroup: string;
  ats: string;
  onHand: string;
  commit: string;
  checkout: string;
  cart: string;
  status: string;
  threshold: string;
  leadTime: string;
  ltSource: string;
  defaultLT: string;
  continueToSell: string;
  active: string;

}
export class itemdetail {
  ProductCountryId: number;
  Sku: string;
  Catalog: string;
}
export class productManagementReff {
  ProductId: number;
  Sku: string;
  CatalogGroupId: string;
}
export class FGADetailsList {
  active: boolean;
  ats: number;
  brand: string;
  cart: number;
  catalogGroup: string;
  checkout: number;
  commit: number;
  continueToSell: boolean;
  createdOn: string;
  defaultLT: number;
  description: string;
  extendedLeadTime: number;
  id: number;
  isSDSEnabledCountry: boolean;
  leadTime: number;
  ltSource: string;
  offerType: string;
  onHand: number;
  part: string;
  productCountryId: number;
  sds: boolean;
  sku: string;
  status: string;
  statusId: number;
  threshold: string;
  type: string;
  updatedOn: string;
}
export class datalist {
  atsFGAItems: FGADetailsList[];
  recordCount: number;
}
