﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class InsertUpdateLeadTimeAdderRuleCondition
    {
        public int RuleId { get; set; }
        public string ModifiedBy { get; set; }
        public IEnumerable<LeadTimeAdderConditionsType> _LeadTimeAdderConditionsType { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class InsertUpdateLeadTimeAdderRule
    {
        public Nullable<int> RuleId { get; set; }
        public string RuleName { get; set; }
        public int LeadTime { get; set; }
        public int Weightage { get; set; }
        public string ModifiedBy { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class LeadTimeAdderConditionsType
    {
        public int ParameterId { get; set; }
        public string Operator { get; set; }
        public string ParameterValue { get; set; }

    }
}
