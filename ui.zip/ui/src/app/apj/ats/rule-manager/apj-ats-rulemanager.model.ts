export class Applications {
  code: string;
  id: number;
  isActive: boolean;
  name: string;
}

export class Configurations {
  atsApplicationConfigurationList: AtsApplicationConfigurationList[];
  recordCount: number;
}

export class AtsApplicationConfigurationList {
  applicationID: number;
  applicationName: string;
  brandId: number;
  brandName: string;
  catalogId: number;
  catalogName: string;
  configID: number;
  configName: string;
  configValue: string;
  familyId: number;
  familyName: string;
  isActive: boolean;
  operation: string;
  preDefinitionCode: string;
  productLine: string;
  productLineId: number;
  trimmedConfigName: string;
  userName: string;
  xmlConfigValue: string;
  Edit: boolean;
  add: boolean;
}

export class Filter {
  ApplicationIds: string;
  ConfigIDs: string;
  ConfigValues: string;
  Status: string
  PageNumber: number;
  PageSize: number;
}
