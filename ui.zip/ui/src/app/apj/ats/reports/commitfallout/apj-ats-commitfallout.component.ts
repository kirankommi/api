import { Component, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import {FormBuilder, FormGroup, Validators, FormsModule, NgForm} from '@angular/forms';
import { ApjAtsCommitfalloutService } from './apj-ats-commitfallout.service';
import { ApjAtsFacadeService } from '@App/shared/apj-ats-facade.service';
import { CommitFalloutRequest,CommitCalloutDetail,CommitCalloutDetailResponse} from './apj-ats-commitfallout.model';
import { Global } from '@App/shared/global';
import { ExcelService } from '@App/shared/exportservice';
import { LocalStorageService } from 'angular-2-local-storage';

@Component({
  selector: 'app-apj-ats-commitfallout',
  templateUrl: './apj-ats-commitfallout.component.html',
  styleUrls: ['./apj-ats-commitfallout.component.css'],
})

export class ApjAtsCommitFalloutComponent  {
    apjAtsCommitFalloutForm: FormGroup;
    commitCalloutDetail: CommitCalloutDetail[];
    commitCalloutDetailFilter: CommitCalloutDetail[]; 
    commitCalloutDetailResponse: CommitCalloutDetailResponse;
    private commitFalloutRequest: CommitFalloutRequest = new CommitFalloutRequest();
    ErrorMsg: any; SuccessMsg: any;
    indLoading: boolean = false;
    displayedColumns = ['sku','fga','orderNumber','quantity','countryCode','updatedDateTime','tieNumber','productType'];
    dataSource: MatTableDataSource<CommitCalloutDetail>;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    pageIndex: number = 1;
    pageSize: number = 10;
    filterBy: string;

    constructor(private fb: FormBuilder,
                private apjAtsCountryService: ApjAtsCommitfalloutService,
                private _ApjAtsFacadeService:ApjAtsFacadeService,
                private excelService: ExcelService,
                private _localStorageService: LocalStorageService
                ) {
        // To initialize FormGroup , Validators.required 
        this.apjAtsCommitFalloutForm = fb.group({
        });
    }

    ngOnInit(){
        this.indLoading = true;
        this.commitFalloutRequest.RegionId = this._localStorageService.get('selRegion');
        this.commitFalloutRequest.PageNumber = 1;
        this.commitFalloutRequest.PageSize = -1;
        this._ApjAtsFacadeService.getCommitFallout(this.commitFalloutRequest)
        .subscribe(data => {
            this.commitCalloutDetailResponse = data;
            this.commitCalloutDetail = this.commitCalloutDetailResponse.commitCalloutDetails;
            this.dataSource = new MatTableDataSource(this.commitCalloutDetail);
            this.dataSource.paginator = this.paginator;
            this.indLoading = false;
        }, 
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
    }

    doFilter(value: string) {
      value = value.trim();
      this.filterBy = value;
      value = value.toLowerCase();
      
      this.dataSource.filter = value;
        if (this.dataSource.paginator) {
          this.dataSource.paginator.firstPage();
        }
    }

    exportAsXLSX() {
      this.indLoading = true;
      if (this.filterBy != null && this.filterBy != "") {
        var filterBy = this.filterBy.toUpperCase();
        this.commitCalloutDetailFilter = this.commitCalloutDetail.filter(function (el) {
          return (el.countryCode.toUpperCase().includes(filterBy) ||
            el.sku.toUpperCase().includes(filterBy) ||
            el.fga.toUpperCase().includes(filterBy) ||
            el.orderNumber.toUpperCase().includes(filterBy) ||
            el.quantity.toUpperCase().includes(filterBy) ||
            el.updatedDateTime.toUpperCase().includes(filterBy) ||
            (el.tieNumber != undefined ? el.tieNumber.includes(filterBy) : false) ||
            el.productType.toUpperCase().includes(filterBy))
        });
        this.excelService.exportAsExcelFile(this.commitCalloutDetailFilter, 'CommitFalloutReport');
      }
      else
        this.excelService.exportAsExcelFile(this.commitCalloutDetail, 'CommitFalloutReport');
      
      this.indLoading = false;
    }
}




