﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class FutureCommitResponse
    {
        public long? OrderNumber { get; set; }
        public string Country { get; set; }
        public string Sku { get; set; }
        public string Part { get; set; }
        public int? Quantity { get; set; }
        public DateTime? ReservedOn {get; set;}
        public string LocationCode { get; set; }
        public Guid? ReservationId { get; set; }
        public int? Status { get; set; }
        public DateTime? ReleaseDate { get; set; }
        public bool? OverrideScdh { get; set; }
        public DateTime? MustArriveByDate { get; set; }
        public int? TieNumber { get; set; }
        public string OrderTie { get; set; }
        public string ShipToContactName { get; set; }
        public string BillingCompanyName { get; set; }
        public string CustomerName { get; set; }
        public string FDDSKUs { get; set; }
        public DateTime? FuturisticDeliveryDate { get; set; }
    }
}
