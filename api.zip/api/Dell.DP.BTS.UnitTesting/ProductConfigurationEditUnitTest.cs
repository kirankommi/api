﻿using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    /// <summary>
    /// Summary description for ProductConfigurationUnitTest
    /// </summary>
    
    public class ProductConfigurationEditUnitTest:UnitTestInitializer
    {


        [Fact]
        public void UpdateProductConfigurationDataShouldReturnOKResult()
        {
            var result = btsCommandController.UpdateProductConfiguration(productConfiguration);
            Assert.NotNull(result);
        }
    }
}
