import { Injectable } from '@angular/core';
import {DataservicesProvider} from '@Dataservice/dataservices/dataservices';
import { Global } from '@App/shared/global';
import { Observable } from 'rxjs/Observable';
import { Configurations } from './apj-ats-rulemanager.model';
import { environment } from '@Environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ApjAtsRuleManagerService {

  constructor(private _DataservicesProvider: DataservicesProvider) {
  }

  getapplicationruleconfigurations(filter): Observable<Configurations> {
    return this._DataservicesProvider.PostData(environment.ApjEmeaAtsApiUrl + 'getapplicationruleconfigurations/', filter);
  }
}
