﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsCountry
    {
        public int Id { get; set; }
        public string CountryName { get; set; }
        public string Code { get; set; }
        public int? RegionId { get; set; }
        public bool Active { get; set; }
        public string ModifiedBy { get; set; }
        public int Sequence { get; set; }
        public string Operation { get; set; }
        public AtsSite site { get; set; }

        public string CatalogCountryBindingID { get; set; }
        public bool? IsCatalogGroup { get; set; }
        public string CountryIds { get; set; }

        public bool? AllowFutureCommit { get; set; }
    }
}
