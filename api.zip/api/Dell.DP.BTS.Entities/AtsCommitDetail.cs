﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsCommitDetail : AtsCommon
    {
        public string ReservationId { get; set; }
        public string Name { get; set; }
        public string IRN { get; set; }
        public string Segment { get; set; }
        public string OrderNumber { get; set; }
        public int Quantity { get; set; }
        public string FacilityCode { get; set; }
        public string TieNumber { get; set; }
        public string FulfillmentLocation { get; set; }
        public string ShipToContactName { get; set; }
        public string BillingCompanyName { get; set; }
        public DateTime? ReservedOn { get; set; }
        public DateTime? CommitedOn { get; set; }
        public DateTime? MustArriveByDate { get; set; }
        public DateTime? FuturisticDeliveryDate { get; set; }
        public string CustomerName { get; set; }
        public DateTime? ReleaseDate { get; set; }
        public bool? OverrideTPB { get; set; }
        public string GossStatus { get; set; }
        public string BusinessUnitCode { get; set; }
        public bool FulfillWarning { get; set; }
        public bool CancelWarning { get; set; }
    }
}
