export class Global {
  public static VinNum = '';
  //public static ApjEmeaAtsApiUrl = 'http://localhost:7140/api/';
  //public static EmeaAtsApiUrl = 'https://dpemeaapjbtsapi-dit.ausvdc02.pcf.dell.com/api/';
  //public static ApjEmeaAtsApiUrl = 'https://dpemeaapjbtsapi-g1.ausvdc02.pcf.dell.com/api/';
  //public static ApjEmeaAtsApiUrl = 'https://dpemeaapjbtsinternalapi.ausmpc.pcf.dell.com/api/';
  public static ApjEmeaAtsApiUrl = 'https://dpemeaapjbtsapi-g2.ausvdc02.pcf.dell.com/api/';

  public static UI_BASE_URL = 'https://localhost:4300/';
  public static EmeaAtsProdApiUrl = 'http://ausfwatsws04.aus.amer.dell.com:1000/DPMBTSEMEAAPI/api/atsquery/';
  public static MandatoryMessage = 'Please enter all mandatory fields';
  public static IsEndDateBeforeStartDate = 'End Date should be greater than start date';
  public static SaveMessage = 'Record saved successfully';
  public static DocumentUploadMessage = 'Document uploaded';
  public static SaveErrorMessage = '';
  public static UpdateMessage = 'Record updated successfully';
  public static DeleteMessage = 'Record deleted successfully';
  public static AddMessage = 'Record added successfully';
  public static NUMBER_REGEX = "^\-?[0-9]{0,3}$";
  public static NUMBER6_REGEX = "^\-?[0-9]{0,6}$";

}
