﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class IsgProductToSiteAssignment
    {
        public int RecordId { get; set; }
        public string ProductId { get; set; }
        public string ProductDescription { get; set; }
        public string SalesOrgId { get; set; }
        public string SalesOrgDescription { get; set; }
        public string PlantId { get; set; }
        public string Plant { get; set; }
        public string VendorSiteId { get; set; }
        public string Vendor { get; set; }
        public int defaultLeadtime { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDate { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class IsgProductToSiteAssignmentSearch
    {
        public string ProductId { get; set; }
        public string SalesOrgId { get; set; }
        public string plantId { get; set; }
        public string vendorSiteId { get; set; }
        public string defaultLeadtime { get; set; }
    }
}
