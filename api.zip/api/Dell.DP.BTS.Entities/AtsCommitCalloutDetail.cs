﻿using System;
using System.Collections.Generic;

namespace Dell.DP.BTS.Entities
{
    public class CommitCalloutDetail
    {
        public string SKU { get; set; }
        public string FGA { get; set; }
        public string OrderNumber { get; set; }
        public string Quantity { get; set; }
        public string CountryCode { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public string TieNumber { get; set; }
        public string ProductType { get; set; }
    }

    public class CommitCalloutDetailResponse
    {
        public List<CommitCalloutDetail> CommitCalloutDetails { get; set; }
        public int? RecordCount { get; set; }
    }
}
