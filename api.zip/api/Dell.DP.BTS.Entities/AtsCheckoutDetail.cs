﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class AtsCheckoutDetail
    {
        public string ReservationId { get; set; }
        public string Name { get; set; }
        public string IRN { get; set; }
        public string Segment { get; set; }
        public int Quantity { get; set; }
        public DateTime? ReservedOn { get; set; }
        public string Id { get; set; }
    }
}
