export class Applications {
  code: string;
  id: number;
  isActive: boolean;
  name: string;
}

export class ruleDetail {
}


export class Configurations {
  atsApplicationConfigurationList: AtsApplicationConfigurationList[];
  recordCount: number;
}

export class AtsApplicationConfigurationList {
  applicationID: number;
  applicationName: string;
  brandId: number;
  brandName: string;
  catalogId: number;
  catalogName: string;
  configID: number;
  configName: string;
  configValue: string;
  familyId: number;
  familyName: string;
  isActive: boolean;
  operation: string;
  preDefinitionCode: string;
  productLine: string;
  productLineId: number;
  trimmedConfigName: string;
  userName: string;
  xmlConfigValue: string;
  Edit: boolean;
  add: boolean;
}

export class AtsCatalog {
  id: number;
  countryId: number;
  countryName: string;
  regionCode: string;
  catalogId: number;
  catalogGroupId: number;
  catalogGroup: string;
  countryCodes: string;
  countryIdsCsv: string;
  countryIds: number[] = [];
  userID: string;
  regionId: number;
  Edit: boolean;
}

export class Data {
  CountryName: string;
  RegionCode: string;
  CatalogId: string;
  RegionId: string;
}

export class AtsProductInfo {
  id: number;
  SKU: string;
  name: string;
  Description: string; 
  FGA: string;
  Brand: string; 
  Offer: string;
  SeperateMessaging: boolean;
  Active: boolean;
  ProductType: number;
  ProductTypeName: string;
  ProductCountries: null;
  ProductCatalogs: null; 
}

export class AtsBrand {
  id: number;
  name: string;
}
