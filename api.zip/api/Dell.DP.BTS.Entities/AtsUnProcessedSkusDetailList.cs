﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsUnProcessedSkusDetailList
    {
        public List<AtsUnProcessedSkus> AtsUnProcessedSkusList { get; set; }
        public int? RecordCount { get; set; }
    }
}
