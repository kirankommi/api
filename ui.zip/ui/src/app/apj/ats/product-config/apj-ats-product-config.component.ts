import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { ApjAtsFacadeService } from '@App/shared/apj-ats-facade.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ConfirmationDialogComponent, ConfirmDialogModel } from '@App/shared/confirmation-dialog/confirmation-dialog.component';
import { MatDialog, MatSlideToggleChange, MatTableDataSource } from '@angular/material';
import { NotifierService } from 'angular-notifier';
import { LocalStorageService } from 'angular-2-local-storage';
import { AtsProductConfiguration, PostData } from './apj-ats-product-config.model';

@Component({
  selector: 'app-apj-ats-product-config',
  templateUrl: './apj-ats-product-config.component.html',
  styleUrls: ['./apj-ats-product-config.component.css']
})
export class ApjAtsProductConfigComponent implements OnInit {
  isLoading: boolean = false;
  ProductThresholdForm: FormGroup;
  InventoryActionsForm: FormGroup;
  atsProductConfiguration: AtsProductConfiguration;
  private readonly notifier: NotifierService;
  isLowInventory: boolean;
  isIncludeCart: boolean;
  isIncludeCheckout: boolean;
  isContinueToSell: boolean;
  lowThreshold: number;
  bufferThreshold: number;
  oversellThreshold: number;
  oversoldThreshold: number;
  postData: PostData = new PostData()
  edit: boolean = false;

  constructor(private fb: FormBuilder,
    private _ApjAtsFacadeService: ApjAtsFacadeService,
    notifierService: NotifierService) {

    this.ProductThresholdForm = fb.group({
      txtlowThreshold: new FormControl(''),
      txtBufferThreshold: new FormControl(''),
      txtOversellThreshold: new FormControl(''),
      txtOversoldThreshold: new FormControl('')
    });

    this.InventoryActionsForm = fb.group({
      swchLowInventory: new FormControl(''),
      swchIncludeCart: new FormControl(''),
      swchIncludeCheckout: new FormControl(''),
      swchContinueToSell: new FormControl(''),
    });

    this.notifier = notifierService;
  }

  ngOnInit() {
    this.init();
  }

  init() {
    this.isLoading = true;

    this._ApjAtsFacadeService.getProductConfiguration()
      .subscribe(data => {
        if (data) {
          this.atsProductConfiguration = data;
          this.isLowInventory = this.atsProductConfiguration.displayLowInventory;
          this.isIncludeCart = this.atsProductConfiguration.includePreCheckout;
          this.isIncludeCheckout = this.atsProductConfiguration.includeCheckout;
          this.isContinueToSell = this.atsProductConfiguration.sellAction;
          this.lowThreshold = this.atsProductConfiguration.lowThreshold;
          this.bufferThreshold = this.atsProductConfiguration.bufferThreshold;
          this.oversellThreshold = this.atsProductConfiguration.oversellThreshold;
          this.oversoldThreshold = this.atsProductConfiguration.oversoldThreshold;
        }
        else {
          this.atsProductConfiguration = null;
        }
        this.isLoading = false;
      },
      error => {
        this.notifier.notify('error', 'Error while fetching product configuration');
        this.isLoading = false;
      });
  }

  toggleEdit() {
    (<FormControl>this.ProductThresholdForm.controls['txtlowThreshold'])
      .setValue(this.lowThreshold, { onlySelf: true });
    (<FormControl>this.ProductThresholdForm.controls['txtBufferThreshold'])
      .setValue(this.bufferThreshold, { onlySelf: true });
    (<FormControl>this.ProductThresholdForm.controls['txtOversellThreshold'])
      .setValue(this.oversellThreshold, { onlySelf: true });
    (<FormControl>this.ProductThresholdForm.controls['txtOversoldThreshold'])
      .setValue(this.oversoldThreshold, { onlySelf: true });
  }

  updateThreshold() {
    if (this.ProductThresholdForm.controls['txtlowThreshold'].value == this.atsProductConfiguration.lowThreshold &&
      this.ProductThresholdForm.controls['txtBufferThreshold'].value == this.atsProductConfiguration.bufferThreshold &&
      this.ProductThresholdForm.controls['txtOversellThreshold'].value == this.atsProductConfiguration.oversellThreshold &&
      this.ProductThresholdForm.controls['txtOversoldThreshold'].value == this.atsProductConfiguration.oversoldThreshold) {
      this.notifier.notify('error','No Product Threshold has been Modified.')
      this.edit = true;
      return;
    }
    else if (this.ProductThresholdForm.controls['txtlowThreshold'].value <= this.ProductThresholdForm.controls['txtBufferThreshold'].value ||
      this.ProductThresholdForm.controls['txtlowThreshold'].value <= this.ProductThresholdForm.controls['txtOversellThreshold'].value ||
      this.ProductThresholdForm.controls['txtlowThreshold'].value <= this.ProductThresholdForm.controls['txtOversoldThreshold'].value) {
      this.notifier.notify('error','LOW Threshold should be greater than others');
      this.edit = true;
      return;
    }
    else if (this.ProductThresholdForm.controls['txtBufferThreshold'].value <= this.ProductThresholdForm.controls['txtOversellThreshold'].value ||
      this.ProductThresholdForm.controls['txtBufferThreshold'].value <= this.ProductThresholdForm.controls['txtOversellThreshold'].value) {
      this.notifier.notify('error','SDS Threshlod should be greater than XLT and OOS');
      this.edit = true;
      return;
    }
    else if(this.ProductThresholdForm.controls['txtOversellThreshold'].value <= this.ProductThresholdForm.controls['txtOversoldThreshold'].value) {
      this.notifier.notify('error', 'XLT Threshold should be greater than OOS');
      this.edit = true;
      return;
    }
    else {
      this.postData.LowThreshold = this.ProductThresholdForm.controls['txtlowThreshold'].value;
      this.postData.BufferThreshold = this.ProductThresholdForm.controls['txtBufferThreshold'].value;
      this.postData.OversellThreshold = this.ProductThresholdForm.controls['txtOversellThreshold'].value;
      this.postData.OversoldThreshold = this.ProductThresholdForm.controls['txtOversoldThreshold'].value;
      this.postData.UserName = "Kiran Kumar K";
      this.postData.UpdateAction = 'ProductThreshold';

      this.isLoading = true;
      this._ApjAtsFacadeService.updateProductConfiguration(this.postData)
        .subscribe(data => {
          this.init();
          this.edit = false;
          this.notifier.notify('success', 'Default Configurations Saved successfully');
        },
        error => {
          this.notifier.notify('error', 'Error while updating Defualut Configurations');
          this.isLoading = false;
        });
    }
  }

  updateInventoryAction(operation) {
    this.postData.DisplayLowInventory = this.InventoryActionsForm.controls['swchLowInventory'].value != '' ? this.InventoryActionsForm.controls['swchLowInventory'].value : 0;
    this.postData.IncludePreCheckout = this.InventoryActionsForm.controls['swchIncludeCart'].value != '' ? this.InventoryActionsForm.controls['swchIncludeCart'].value : 0;
    this.postData.IncludeCheckout = this.InventoryActionsForm.controls['swchIncludeCheckout'].value != '' ? this.InventoryActionsForm.controls['swchIncludeCheckout'].value : 0;
    this.postData.SellAction = this.InventoryActionsForm.controls['swchContinueToSell'].value != '' ? this.InventoryActionsForm.controls['swchContinueToSell'].value : 0;
    this.postData.FGASCDHOverride = this.atsProductConfiguration.fgascdhOverride;
    this.postData.UserName = "Kiran Kumar K";
    this.postData.UpdateAction = operation;

    this.isLoading = true;
    this._ApjAtsFacadeService.updateProductConfiguration(this.postData)
      .subscribe(data => {
        this.init();
        this.notifier.notify('success', 'Default Configurations Saved successfully');
      },
      error => {
        this.notifier.notify('error', 'Error while updating Defualut Configurations');
        this.isLoading = false;
      });
  }

}
