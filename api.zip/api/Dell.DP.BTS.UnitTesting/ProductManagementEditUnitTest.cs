﻿using Dell.DP.BTS.Entities;
using Dell.DP.BTS.API.Controllers;
using Dell.DP.BTS.DataServices;
using Dell.DP.BTS.BusinessServices;
using Xunit;
using System.Web.Http;
using Microsoft.AspNetCore.Mvc;

namespace Dell.DP.BTS.UnitTesting
{
    /// <summary>
    /// Summary description for ProductConfigurationUnitTest
    /// </summary>
    
    public class ProductManagementEditUnitTest:UnitTestInitializer
    {


        [Fact]
        public void ProductManagementEditSave()
        {
            AtsProductInfoAddUpdateRequest atsProductInfoAddUpdateRequest = new AtsProductInfoAddUpdateRequest();
            atsProductInfoAddUpdateRequest.ProductId = "6";
            atsProductInfoAddUpdateRequest.FgaId = "PART N";
            atsProductInfoAddUpdateRequest.ProductInfo = atsProductInfo;
            var result = btsCommandController.UpdateProductInformation(atsProductInfoAddUpdateRequest);
            Asserts(result);
        }
        public void Asserts(IActionResult result)
        {
            Assert.NotNull(result);
        }
    }
}
