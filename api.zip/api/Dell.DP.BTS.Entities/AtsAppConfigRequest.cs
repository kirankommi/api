﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
   public class AtsAppConfigRequest
    {
        public string ConfigIDs { get; set; }
        public string ConfigValues { get; set; }
        public string ApplicationIds { get; set; }
        public string Status { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}
