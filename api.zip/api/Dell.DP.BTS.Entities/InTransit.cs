﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class InTransit
    {
        public string SKU { get; set; }
        public string PART { get; set; }
        public int QUANTITY { get; set; }
        public string ASSIN { get; set; }
        public string SHIPFROMFACILITY { get; set; }
        public string MERGECENTER { get; set; }
        public string ESTIMATEDARRIVAL { get; set; }
        public string TRANSPORTMODE { get; set; }
        public string INVENTORYOWNER { get; set; }
    }
}
