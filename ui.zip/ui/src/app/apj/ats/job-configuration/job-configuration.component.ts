import { Component, OnInit } from '@angular/core';
import { DataservicesProvider } from '@Dataservice/dataservices/dataservices';
import { FormBuilder, FormGroup, Validators, FormsModule, NgForm } from '@angular/forms';
import { MatPaginator, MatSort, MatTableDataSource, MatTooltip } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { AtsJobDetail, AtsJobTransactionStatus } from './job-configuration.model';
import { ApjAtsFacadeService } from '@App/shared/apj-ats-facade.service';
import { NotifierService } from 'angular-notifier';
import { LocalStorageService } from 'angular-2-local-storage';


@Component({
  selector: 'app-job-configuration',
  templateUrl: './job-configuration.component.html',
  styleUrls: ['./job-configuration.component.css'],
  providers: [DataservicesProvider]
})
export class JobConfigurationComponent implements OnInit {
  RegionId: string;
  // atsJobConfigurationForm: FormGroup;
  private notifier: NotifierService;
  atsJobDetailList: AtsJobDetail[];
  atsJobTransactionDetailList: AtsJobTransactionStatus[];
  selection = new SelectionModel<AtsJobDetail>(true, []);
  displayedJobDetailsColumns = ['Source', 'Name', 'Description', 'JobStage', 'ExecutionStatus', 'Schedule', 'LastRunTime', 'NextRunTime', 'ManualOverride', 'Action'];
  displayedJobTransactionDetailsColumns = ['Source', 'Name', 'Description', 'LastUpdatedAt'];
  displayedDGAColumns = ['Text', 'Trigger'];
  userIsEmeaReadOnly: boolean = false;
  dataSourceDatabaseJobDetails: MatTableDataSource<AtsJobDetail>;
  dataSourceDatabaseJobTransactionDetails: MatTableDataSource<AtsJobTransactionStatus>;

  constructor(private fb: FormBuilder,
    private _ApjAtsFacadeService: ApjAtsFacadeService,
    private _localStorageService: LocalStorageService,
    notifier: NotifierService) {
    this.RegionId = this._localStorageService.get('selRegion');
    this.notifier = notifier;
  }

  ngOnInit() {
    this.init();
  }

  init() {

    this._ApjAtsFacadeService.getJobConfigurationDetails(this.RegionId)
      .subscribe(data => {
        this.selection.clear();
        this.atsJobDetailList = data;
        this.dataSourceDatabaseJobDetails = new MatTableDataSource(this.atsJobDetailList);
      })

    this._ApjAtsFacadeService.getTransactionDetails(this.RegionId)
      .subscribe(data => {
        this.atsJobTransactionDetailList = data;
        this.dataSourceDatabaseJobTransactionDetails = new MatTableDataSource(this.atsJobTransactionDetailList);
      })
  }

  reStartWindowsService() {
    this._ApjAtsFacadeService.reStartWindowsService()
      .subscribe(data => {
        console.log(JSON.parse(data));
      })
  }

}
