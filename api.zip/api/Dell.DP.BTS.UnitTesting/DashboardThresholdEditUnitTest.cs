﻿using Dell.DP.BTS.Entities;
using Dell.DP.BTS.API.Controllers;
using Dell.DP.BTS.DataServices;
using Dell.DP.BTS.BusinessServices;
using Xunit;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc;

namespace Dell.DP.BTS.UnitTesting
{
    
    public class DashboardThresholdEditUnitTest : UnitTestInitializer
    {

        [Fact]

        public void Askingforconfirmationwhileupdatingvalidthresholdvalues()
        {
            AtsItemDetail _atsItemDetail = new AtsItemDetail()
            {
                ProductCountryId = 17,
                LowThreshold = 101,
                SameDayShippingThreshold = 25,
                ExtendedLeadTimeThresold = 3,
                OutOfStockThresold = 1,
                Sku = "998-BQVX",
                DefaultLT = 1,
                ExtendedLeadTime = 9,
                AutoXltIncrement = 3,
                UpdatedBy = "Jitendra_kumar_pradh",
                Active = false,
                AllowAutoXLT = false,
                ATS = null,
                AvailabletoSellQuantiry = 1,
                Brand = null,
                Cart = null,
                Catalog = null,
                CatalogGroup = null,
                CatalogGroupId = null,
                CatalogId = null,
                Checkout = null,
                Commit = null,
                ContinueToSell = false,
                CountDown = null,
                CreatedBy = null,
                CreatedOn = System.DateTime.Now,
                Description = null,
                DisplayLowInventry = false,
                FutureCommit = null,
                Id = 1,
                IsEligibleForSmartLogo = false,
                IsFirstTrackEligible = false,
                IsSDSEnabledCountry = false,
                ItemInventryStatus = null,
                LeadTime = null,
                LTSource = null,
                OfferType = null,
                OnHand = null,
                Part = null,
                ProductCountryIds = null,
                SDS = false,
                SDSShippingId = 1,
                Status = null,
                StatusId = 1,
                StdLeadTime = null,
                Threshold = null,
                Type = null,
                UpdatedOn = System.DateTime.Now
            };
            var result = btsCommandController.UpdateThreshold(_atsItemDetail);
            Asserts(result);
        }


        [Fact]

        public void RaisingAnErrorWhileTryingToUpdatingInValidThresholdValues()
        {
            AtsItemDetail _atsItemDetail = new AtsItemDetail()
            {
                ProductCountryId = 17,
                LowThreshold = 101,
                SameDayShippingThreshold = 25,
                ExtendedLeadTimeThresold = 3,
                OutOfStockThresold = 4,
                Sku = "998-BQVX",
                DefaultLT = 1,
                ExtendedLeadTime = 9,
                AutoXltIncrement = 3,
                UpdatedBy = "Jitendra_kumar_pradh",
                Active = false,
                AllowAutoXLT = false,
                ATS = null,
                AvailabletoSellQuantiry = 1,
                Brand = null,
                Cart = null,
                Catalog = null,
                CatalogGroup = null,
                CatalogGroupId = null,
                CatalogId = null,
                Checkout = null,
                Commit = null,
                ContinueToSell = false,
                CountDown = null,
                CreatedBy = null,
                CreatedOn = System.DateTime.Now,
                Description = null,
                DisplayLowInventry = false,
                FutureCommit = null,
                Id = 1,
                IsEligibleForSmartLogo = false,
                IsFirstTrackEligible = false,
                IsSDSEnabledCountry = false,
                ItemInventryStatus = null,
                LeadTime = null,
                LTSource = null,
                OfferType = null,
                OnHand = null,
                Part = null,
                ProductCountryIds = null,
                SDS = false,
                SDSShippingId = 1,
                Status = null,
                StatusId = 1,
                StdLeadTime = null,
                Threshold = null,
                Type = null,
                UpdatedOn = System.DateTime.Now
            };
            if (_atsItemDetail.LowThreshold <= _atsItemDetail.SameDayShippingThreshold)
            {
                Assert.NotNull(1);
            }
            else if (_atsItemDetail.SameDayShippingThreshold <= _atsItemDetail.ExtendedLeadTimeThresold)
            {
                Assert.NotNull(1);
            }
            else if (_atsItemDetail.ExtendedLeadTimeThresold <= _atsItemDetail.OutOfStockThresold)
            {
                Assert.NotNull(1);
            }
        }

        [Fact]

        public void Updatingvalidthresholdvalueswithoutachangeinthresholdstatus()
        {
            AtsItemDetail _atsItemDetail = new AtsItemDetail()
            {
                ProductCountryId = 17,
                LowThreshold = 100,
                SameDayShippingThreshold = 97,
                ExtendedLeadTimeThresold = 34,
                OutOfStockThresold = 32,
                Sku = "998-BBRZ",
                DefaultLT = 1,
                ExtendedLeadTime = 15,
                AutoXltIncrement = 3,
                UpdatedBy = "Jitendra_kumar_pradh",
                Active = false,
                AllowAutoXLT = false,
                ATS = 0,
                AvailabletoSellQuantiry = 1,
                Brand = null,
                Cart = null,
                Catalog = null,
                CatalogGroup = null,
                CatalogGroupId = null,
                CatalogId = null,
                Checkout = null,
                Commit = null,
                ContinueToSell = false,
                CountDown = null,
                CreatedBy = null,
                CreatedOn = System.DateTime.Now,
                Description = null,
                DisplayLowInventry = false,
                FutureCommit = null,
                Id = 1,
                IsEligibleForSmartLogo = false,
                IsFirstTrackEligible = false,
                IsSDSEnabledCountry = false,
                ItemInventryStatus = null,
                LeadTime = null,
                LTSource = null,
                OfferType = null,
                OnHand = null,
                Part = null,
                ProductCountryIds = null,
                SDS = false,
                SDSShippingId = 1,
                Status = null,
                StatusId = 1,
                StdLeadTime = null,
                Threshold = "XLT",
                Type = null,
                UpdatedOn = System.DateTime.Now
            };
            var result = btsCommandController.UpdateThreshold(_atsItemDetail);
            Asserts(result);
        }


        [Fact]

        public void Updatingvalidthresholdvalueswithachangeinthresholdstatusbutnocurrentleadtimechange()
        {
            AtsItemDetail _atsItemDetail = new AtsItemDetail()
            {
                ProductCountryId = 17,
                LowThreshold = 0,
                SameDayShippingThreshold = -11,
                ExtendedLeadTimeThresold = -12,
                OutOfStockThresold = -13,
                Sku = "998-BBRZ",
                DefaultLT = 1,
                ExtendedLeadTime = 9,
                AutoXltIncrement = 3,
                UpdatedBy = "Jitendra_kumar_pradh",
                Active = false,
                AllowAutoXLT = false,
                ATS = 0,
                AvailabletoSellQuantiry = 1,
                Brand = null,
                Cart = null,
                Catalog = null,
                CatalogGroup = null,
                CatalogGroupId = null,
                CatalogId = null,
                Checkout = null,
                Commit = 11,
                ContinueToSell = false,
                CountDown = null,
                CreatedBy = null,
                CreatedOn = System.DateTime.Now,
                Description = null,
                DisplayLowInventry = false,
                FutureCommit = null,
                Id = 1,
                IsEligibleForSmartLogo = false,
                IsFirstTrackEligible = false,
                IsSDSEnabledCountry = false,
                ItemInventryStatus = null,
                LeadTime = null,
                LTSource = "Standard",
                OfferType = null,
                OnHand = null,
                Part = null,
                ProductCountryIds = null,
                SDS = false,
                SDSShippingId = 1,
                Status = null,
                StatusId = 1,
                StdLeadTime = 1,
                Threshold = "Low",
                Type = "FGA-BTS",
                UpdatedOn = System.DateTime.Now
            };
            var result = btsCommandController.UpdateThreshold(_atsItemDetail);
            Asserts(result);
        }


        [Fact]

        public void Updatingvalidthresholdvalueswithachangeinthresholdstatusandcurrentleadtimechange()
        {
            AtsItemDetail _atsItemDetail = new AtsItemDetail()
            {
                ProductCountryId = 17,
                LowThreshold = 10,
                SameDayShippingThreshold = 9,
                ExtendedLeadTimeThresold = 0,
                OutOfStockThresold = -1,
                Sku = "998-BBRZ",
                DefaultLT = 1,
                ExtendedLeadTime = 15,
                AutoXltIncrement = 3,
                UpdatedBy = "Jitendra_kumar_pradh",
                Active = false,
                AllowAutoXLT = false,
                ATS = 0,
                AvailabletoSellQuantiry = 1,
                Brand = null,
                Cart = null,
                Catalog = null,
                CatalogGroup = null,
                CatalogGroupId = null,
                CatalogId = null,
                Checkout = null,
                Commit = null,
                ContinueToSell = false,
                CountDown = null,
                CreatedBy = null,
                CreatedOn = System.DateTime.Now,
                Description = null,
                DisplayLowInventry = false,
                FutureCommit = null,
                Id = 1,
                IsEligibleForSmartLogo = false,
                IsFirstTrackEligible = false,
                IsSDSEnabledCountry = false,
                ItemInventryStatus = "InStock:StopSelling",
                LeadTime = 15,
                LTSource = "Extended",
                OfferType = null,
                OnHand = 0,
                Part = null,
                ProductCountryIds = null,
                SDS = false,
                SDSShippingId = 1,
                Status = null,
                StatusId = 1,
                StdLeadTime = 1,
                Threshold = "XLT",
                Type = null,
                UpdatedOn = System.DateTime.Now
            };
            var result = btsCommandController.UpdateThreshold(_atsItemDetail);
            Asserts(result);
        }


        [Fact]

        public void Updatingvalidthresholdvalueswithachangeinthresholdstatustriggeringastopsell()
        {
            AtsItemDetail _atsItemDetail = new AtsItemDetail()
            {
                ProductCountryId = 17,
                LowThreshold = 10,
                SameDayShippingThreshold = 9,
                ExtendedLeadTimeThresold = 8,
                OutOfStockThresold = 0,
                Sku = "998-BBRZ",
                DefaultLT = 1,
                ExtendedLeadTime = 15,
                AutoXltIncrement = 3,
                UpdatedBy = "Jitendra_kumar_pradh",
                Active = false,
                AllowAutoXLT = false,
                ATS = 0,
                AvailabletoSellQuantiry = 1,
                Brand = null,
                Cart = null,
                Catalog = null,
                CatalogGroup = null,
                CatalogGroupId = null,
                CatalogId = null,
                Checkout = null,
                Commit = 11,
                ContinueToSell = false,
                CountDown = null,
                CreatedBy = null,
                CreatedOn = System.DateTime.Now,
                Description = null,
                DisplayLowInventry = false,
                FutureCommit = null,
                Id = 1,
                IsEligibleForSmartLogo = false,
                IsFirstTrackEligible = false,
                IsSDSEnabledCountry = false,
                ItemInventryStatus = null,
                LeadTime = 15,
                LTSource = "Extended",
                OfferType = null,
                OnHand = 0,
                Part = null,
                ProductCountryIds = null,
                SDS = false,
                SDSShippingId = 1,
                Status = null,
                StatusId = 1,
                StdLeadTime = 1,
                Threshold = "OOS/EOL",
                Type = null,
                UpdatedOn = System.DateTime.Now
            };
            var result = btsCommandController.UpdateThreshold(_atsItemDetail);
            Asserts(result);
        }

        public void Asserts(IActionResult result)
        {
            Assert.NotNull(result);
        }

    }
}
