﻿
using System;
using Xunit;
using Dell.DP.BTS.Entities;
using Dell.DP.BTS.API.Controllers;
using Dell.DP.BTS.DataServices;
using Dell.DP.BTS.BusinessServices;
using System.Web.Http;
using Microsoft.AspNetCore.Mvc;

namespace Dell.DP.BTS.UnitTesting
{
    
    public class InventoryStatusEditUnitTest : UnitTestInitializer
    {

        [Fact]
        public void UpdatingContinueToSell()
        {
            AtsItemDetail _atsItemDetail = new AtsItemDetail()
            {
                ProductCountryId = 17,
                LowThreshold = 101,
                SameDayShippingThreshold = 25,
                ExtendedLeadTimeThresold = 3,
                OutOfStockThresold = 1,
                Sku = "998-BQVX",
                DefaultLT = 1,
                ExtendedLeadTime = 9,
                AutoXltIncrement = 3,
                UpdatedBy = "Jitendra_kumar_pradh",
                Active = false,
                AllowAutoXLT = false,
                ATS = null,
                AvailabletoSellQuantiry = 1,
                Brand = null,
                Cart = null,
                Catalog = null,
                CatalogGroup = null,
                CatalogGroupId = null,
                CatalogId = null,
                Checkout = null,
                Commit = null,
                ContinueToSell = true,
                CountDown = null,
                CreatedBy = null,
                CreatedOn = System.DateTime.Now,
                Description = null,
                DisplayLowInventry = false,
                FutureCommit = null,
                Id = 1,
                IsEligibleForSmartLogo = false,
                IsFirstTrackEligible = false,
                IsSDSEnabledCountry = false,
                ItemInventryStatus = null,
                LeadTime = null,
                LTSource = null,
                OfferType = null,
                OnHand = null,
                Part = null,
                ProductCountryIds = null,
                SDS = false,
                SDSShippingId = 1,
                Status = null,
                StatusId = 1,
                StdLeadTime = null,
                Threshold = null,
                Type = null,
                UpdatedOn = System.DateTime.Now
            };
            var result = btsCommandController.UpdateContinueToSell(_atsItemDetail);
            Asserts(result);
        }

        [Fact]
        public void UpdatingDisplayLowInventory()
        {
            AtsItemDetail _atsItemDetail = new AtsItemDetail()
            {
                ProductCountryId = 17,
                LowThreshold = 101,
                SameDayShippingThreshold = 25,
                ExtendedLeadTimeThresold = 3,
                OutOfStockThresold = 1,
                Sku = "998-BQVX",
                DefaultLT = 1,
                ExtendedLeadTime = 9,
                AutoXltIncrement = 3,
                UpdatedBy = "Jitendra_kumar_pradh",
                Active = false,
                AllowAutoXLT = false,
                ATS = null,
                AvailabletoSellQuantiry = 1,
                Brand = null,
                Cart = null,
                Catalog = null,
                CatalogGroup = null,
                CatalogGroupId = null,
                CatalogId = null,
                Checkout = null,
                Commit = null,
                ContinueToSell = true,
                CountDown = null,
                CreatedBy = null,
                CreatedOn = System.DateTime.Now,
                Description = null,
                DisplayLowInventry = true,
                FutureCommit = null,
                Id = 1,
                IsEligibleForSmartLogo = false,
                IsFirstTrackEligible = false,
                IsSDSEnabledCountry = false,
                ItemInventryStatus = null,
                LeadTime = null,
                LTSource = null,
                OfferType = null,
                OnHand = null,
                Part = null,
                ProductCountryIds = null,
                SDS = false,
                SDSShippingId = 1,
                Status = null,
                StatusId = 1,
                StdLeadTime = null,
                Threshold = null,
                Type = null,
                UpdatedOn = System.DateTime.Now
            };
            var result = btsCommandController.UpdateDisplayLowInventory(_atsItemDetail);
            Asserts(result);
        }

        [Fact]
        public void UpdatingIsActive()
        {
            AtsItemDetail _atsItemDetail = new AtsItemDetail()
            {
                ProductCountryId = 17,
                LowThreshold = 101,
                SameDayShippingThreshold = 25,
                ExtendedLeadTimeThresold = 3,
                OutOfStockThresold = 1,
                Sku = "998-BQVX",
                DefaultLT = 1,
                ExtendedLeadTime = 9,
                AutoXltIncrement = 3,
                UpdatedBy = "Jitendra_kumar_pradh",
                Active = true,
                AllowAutoXLT = false,
                ATS = null,
                AvailabletoSellQuantiry = 1,
                Brand = null,
                Cart = null,
                Catalog = null,
                CatalogGroup = null,
                CatalogGroupId = null,
                CatalogId = null,
                Checkout = null,
                Commit = null,
                ContinueToSell = true,
                CountDown = null,
                CreatedBy = null,
                CreatedOn = System.DateTime.Now,
                Description = null,
                DisplayLowInventry = true,
                FutureCommit = null,
                Id = 1,
                IsEligibleForSmartLogo = false,
                IsFirstTrackEligible = false,
                IsSDSEnabledCountry = false,
                ItemInventryStatus = null,
                LeadTime = null,
                LTSource = null,
                OfferType = null,
                OnHand = null,
                Part = null,
                ProductCountryIds = null,
                SDS = false,
                SDSShippingId = 1,
                Status = null,
                StatusId = 1,
                StdLeadTime = null,
                Threshold = null,
                Type = null,
                UpdatedOn = System.DateTime.Now
            };
            var result = btsCommandController.UpdateIsActive(_atsItemDetail);
            Asserts(result);
        }
        public void Asserts(IActionResult result)
        {
            Assert.NotNull(result);
        }
    }
}
