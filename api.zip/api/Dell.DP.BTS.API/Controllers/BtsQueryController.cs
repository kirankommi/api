﻿using Dell.DP.BTS.BusinessServices.QueryBusiness.Interfaces;
using Dell.DP.BTS.Entities;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Dell.DP.BTS.API.Controllers
{
    [Route("api")]
    [ApiController]
    [EnableCors("CORSPolicy")]
    public class BtsQueryController : ControllerBase
    {
        #region Private Members
        /// <summary>
        /// This property can be used bts inventory query business object as dynamic
        /// </summary>
        private readonly IBtsQueryBusiness _btsQueryBusiness;
        #endregion

        #region Constructor
        /// <summary>
        /// Paramterised constructor with inventory query business object as parameter 
        /// </summary>
        /// <param name="inventoryQueryBusiness"></param>
        public BtsQueryController(IBtsQueryBusiness btsQueryBusiness) => _btsQueryBusiness = btsQueryBusiness;
        #endregion

        #region Http Get routes
        /// <summary>
        /// This end point can be used to test the API health
        /// </summary>
        /// <returns>boolean value</returns>
        [HttpGet]
        [Route("IsAlive")]
        public IActionResult IsAlive()
        {
            var result = _btsQueryBusiness.IsAlive();
            return Ok(result);
        }

        [HttpGet]
        [Route("getdatarefreshdetail/{productCountryId}")]
        public async Task<IActionResult> GetDataRefreshDetail(int productCountryId)
        {
            var result = await _btsQueryBusiness.GetAtsItemRefreshDetail(productCountryId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("getstatushistory/{productCountryId}")]
        public async Task<IActionResult> GetItemStatusHistory(int productCountryId)
        {
            var result = await _btsQueryBusiness.GetAtsStatusHistory(productCountryId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("getleadtimehistory/{productCountryId}")]
        public async Task<IActionResult> GetLeadTimeHistory(int productCountryId)
        {
            var result = await _btsQueryBusiness.GetLeadTimeHistory(productCountryId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("getatsitemdetail/{productCountryId}")]
        public async Task<IActionResult> GetAtsItemDetail(int productCountryId)
        {
            var result = await _btsQueryBusiness.GetAtsItemDetail(productCountryId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("getdaysofsupply/{productCountryId}")]
        public async Task<IActionResult> GetDaysofSupply(int productCountryId)
        {
            var result = await _btsQueryBusiness.GetDaysofSupply(productCountryId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpPost]
        [Route("getFGADetails")]
        public async Task<IActionResult> GetFGAItemDetails([FromBody] AtsItemSearchRequest Item)
        {

            var result = await _btsQueryBusiness.GetFGAItemDetails(Item);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpPost]
        [Route("exportFGADetails")]
        public async Task<IActionResult> ExportFGAItemDetails([FromBody] AtsItemSearchRequest Item)
        {

            var result = await _btsQueryBusiness.GetFGAItemExportDetails(Item);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpPost]
        [Route("exportFilteredFGADetails")]
        public async Task<IActionResult> ExportFilteredFGAItemDetails([FromBody] List<AtsItem> Items)
        {
            return Ok(Items);
        }

        [HttpGet]
        [Route("getStockStatus")]
        public async Task<IActionResult> GetStockStatus()
        {
            var result = await _btsQueryBusiness.GetStockStatus();
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("getCountriesAndCatalogGroups/{regionId}")]
        public async Task<IActionResult> GetCountriesAndCatalogGroups(int regionId)
        {
            var result = await _btsQueryBusiness.GetCountriesAndCatalogGroups(regionId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpPost]
        [Route("getCountryUsageDetail")]
        public async Task<IActionResult> GetCountryUsageDetail([FromBody] AtsCountry atsCountry)
        {

            //Dictionary<string, int> atsCountryUsageDetail = await _btsQueryBusiness.GetCountryUsageDetail(atsCountry.Id);
            //if (atsCountryUsageDetail["Limit"] > 0 || atsCountryUsageDetail["ProductCountry"] > 0)
            //{
            //    throw new HttpResponseException(new HttpResponseMessage
            //    {
            //        StatusCode = HttpStatusCode.Conflict,
            //        ReasonPhrase = "conflict data",
            //        Content = new StringContent("Product(s) are already configured for this country and cannot be deleted.")
            //    });
            //}
            //else if (atsCountryUsageDetail["Region"] > 0 || atsCountryUsageDetail["FulfillmentLocation"] > 0)
            //{
            //    throw new HttpResponseException(new HttpResponseMessage
            //    {
            //        StatusCode = HttpStatusCode.Conflict,
            //        ReasonPhrase = "conflict data",
            //        Content = new StringContent("The country is configured for region(s) / fulfillment Location(s).Kindly delete(disassociate) the same before deleting the country.")
            //    });
            //}
            return Ok();
        }


        [HttpGet]
        [Route("getcataloggroup/{regionId}")]
        public async Task<IActionResult> GetCatalogGroup(int regionId)
        {
            var result = await _btsQueryBusiness.GetCatalogGroup(regionId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("getLocationCode/{regionId}")]
        public async Task<IActionResult> GetFulfillmentLocation(int regionId)
        {
            var result = await _btsQueryBusiness.GetFulfillmentLocation(regionId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("GetProductCountryDefaults")]
        public async Task<IActionResult> GetProductCountryDefaults()
        {
            var result = await _btsQueryBusiness.GetProductCountryDefaults();
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("GetProductTypes")]
        public async Task<IActionResult> GetProductTypes()
        {
            var result = _btsQueryBusiness.GetProductTypes();
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("getAllRegions")]
        public async Task<IActionResult> GetAllRegions()
        {
            var result = await _btsQueryBusiness.GetAllRegions();
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("getCountries/{regionId}")]
        public async Task<IActionResult> GetCountries(int regionId)
        {
            var result = await _btsQueryBusiness.GetCountries(regionId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("GetProductDetails/{productID}/{regionId}")]
        public async Task<IActionResult> GetProductDetails([FromQuery] int productID, int regionId)
        {
            var result = await _btsQueryBusiness.GetProductInformation(productID, regionId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("getDefaultCatalog/{countryId}")]
        public async Task<IActionResult> GetDefaultCatalog([FromQuery] int countryId)
        {
            var result = await _btsQueryBusiness.GetDefaultCatalog(countryId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpPost]
        [Route("getDefaultCatalogs")]
        public async Task<IActionResult> GetDefaultCatalogs([FromBody] List<int> CountryIds)
        {
            var result = await _btsQueryBusiness.GetDefaultCatalogs(CountryIds);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpPost]
        [Route("getcatalog")]
        public async Task<IActionResult> GetCatalog([FromBody] AtsCatalog Item)
        {
            var result = await _btsQueryBusiness.GetCatalog(Item);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpPost]
        [Route("getcatalogs")]
        public async Task<IActionResult> GetCatalogs([FromBody] AtsCatalog Item)
        {
            var result = await _btsQueryBusiness.GetCatalogs(Item);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("getapplications")]
        public async Task<IActionResult> GetApplications()
        {
            var result = await _btsQueryBusiness.GetApplications();
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpPost]
        [Route("getapplicationconfigurations")]
        public async Task<IActionResult> GetApplicationConfigurations([FromBody] AtsAppConfigRequest appConfigReq)
        {
            var result = await _btsQueryBusiness.GetApplicationConfigurations(appConfigReq);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpPost]
        [Route("getapplicationruleconfigurations")]
        public async Task<IActionResult> GetApplicationRuleConfigurations([FromBody] AtsAppConfigRequest appConfigReq)
        {

            var result = await _btsQueryBusiness.GetApplicationRuleConfigurations(appConfigReq);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("getatscommitdetails/{productCountryId}")]
        public async Task<IActionResult> GetCommitDetail(int productCountryId)
        {
            var result = await _btsQueryBusiness.GetCommitDetail(productCountryId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("exportatscommitdetails/{productCountryId}")]
        public async Task<IActionResult> ExportCommitDetail(int productCountryId)
        {
            var result = await _btsQueryBusiness.GetCommitDetail(productCountryId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("gettransactiondetails/{regionId}")]
        public async Task<IActionResult> GetTransactionDetails(int regionId)
        {
            var result = await _btsQueryBusiness.GetTransactionDetails(regionId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("getjobdetails/{regionId}")]
        public async Task<IActionResult> GetJobDetails(int regionId)
        {
            var result = await _btsQueryBusiness.GetJobDetails(regionId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("getinventorystatus/{productCountryId}")]
        public async Task<IActionResult> GetInventoryStatus(int productCountryId)
        {
            var result = await _btsQueryBusiness.GetInventoryStatus(productCountryId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("GetProductConfiguration")]
        public async Task<IActionResult> GetProductConfiguration()
        {
            var result = await _btsQueryBusiness.GetProductConfiguration();
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("getBrands/{productLineId}")]
        public async Task<IActionResult> GetBrands(int productLineId)
        {
            var result = await _btsQueryBusiness.GetBrands(productLineId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("getProductLines/{catalogId}")]
        public async Task<IActionResult> GetProductLines(int catalogId)
        {
            var result = await _btsQueryBusiness.GetProductLines(catalogId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpGet]
        [Route("getProductFulfillmentLocation/{productCountryId}/{regionId}")]
        public async Task<IActionResult> GetProductFulfillmentLocation(int productCountryId, int regionId)
        {
            var result = await _btsQueryBusiness.GetProductFulfillmentLocation(productCountryId, regionId);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }
        [HttpPost]
        [Route("GetInTransit")]
        public async Task<IActionResult> GetInTransit([FromBody] AtsInTransitSearchRequest Item)
        {
            var result = await _btsQueryBusiness.GetInTransit(Item);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }
        [HttpPost]
        [Route("exportInTransit")]
        public async Task<IActionResult> ExportInTransitDetails([FromBody] AtsInTransitSearchRequest Item)
        {
            var result = await _btsQueryBusiness.GetInTransitExport(Item);
            return result == null ? (IActionResult)NotFound() : Ok(result);

        }

        [HttpPost]
        [Route("getOrderDetails")]
        public async Task<IActionResult> GetOrderDetails([FromBody]OrderDetailsSearchRequest request)
        {
            var result = await _btsQueryBusiness.GetOrderDetails(request);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpPost]
        [Route("exportOrderDetails")]
        public async Task<IActionResult> ExportOrderDetails([FromBody]OrderDetailsSearchRequest Item)
        {

            var result = await _btsQueryBusiness.GetOrderExportDetails(Item);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpPost]
        [Route("getCommitFallout")]
        public async Task<IActionResult> GetCommitCalloutDetails(CommitFalloutRequest request)
        {
            var result = await _btsQueryBusiness.GetCommitCalloutDetails(request);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        [HttpPost]
        [Route("getExportCommitFallout")]
        public async Task<IActionResult> ExportCommitCalloutDetails(CommitFalloutRequest request)
        {

            var result = await _btsQueryBusiness.GetCommitCalloutExportDetails(request);
            return result == null ? (IActionResult)NotFound() : Ok(result);
        }

        #endregion

        #region Http Post routes

        #endregion
    }
}