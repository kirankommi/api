import { Injectable } from '@angular/core';
import { DataservicesProvider } from '@Dataservice/dataservices/dataservices';
import { environment } from '@Environments/environment';


@Injectable({
  providedIn: 'root'

})
export class ItemDetailsService {

  constructor(private _DataservicesProvider: DataservicesProvider) {

  }
  getDaysofSupply(ProductCountryId) {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getdaysofsupply/' + ProductCountryId);
  }
  getAtsItemDetail(ProductCountryId) {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getatsitemdetail/' + ProductCountryId);
  }
  getInventoryStatus(ProductCountryId,RegionId) {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getinventorystatus/' + ProductCountryId + '/' + RegionId);
  }
  getLeadTimeHistory(ProductCountryId) {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getLeadTimeHistory/' + ProductCountryId);
  }
  getItemStatusHistory(ProductCountryId) {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getstatushistory/' + ProductCountryId);
  }
  getDataRefreshDetail(ProductCountryId) {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getdatarefreshdetail/' + ProductCountryId);
  }
  getIncomingSupply(ProductCountryId) {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getincomingsupply/' + ProductCountryId);
  }
  updateThreshold(postData) {
    return this._DataservicesProvider.PostDataWithHeader(environment.ApjEmeaAtsApiUrl + 'command/updateThreshold/', postData);
  }
  updateAutoXLT(postData) {
    return this._DataservicesProvider.PostDataWithHeader(environment.ApjEmeaAtsApiUrl + 'command/updateAutoXLT/', postData);
  }
  updateLeadTime(postData) {
    return this._DataservicesProvider.PostDataWithHeader(environment.ApjEmeaAtsApiUrl + 'command/updateLeadTime/', postData);
  }
  updateContinueToSell(postData) {
    return this._DataservicesProvider.PostDataWithHeader(environment.ApjEmeaAtsApiUrl + 'command/updateContinueToSell/', postData);
  }
  updateLowInventory(postData) {
    return this._DataservicesProvider.PostDataWithHeader(environment.ApjEmeaAtsApiUrl + 'command/updateDisplayLowInventory/', postData);
  }
  updateIsActive(postData) {
    return this._DataservicesProvider.PostDataWithHeader(environment.ApjEmeaAtsApiUrl + 'command/updateIsActive/', postData);
  }

}
