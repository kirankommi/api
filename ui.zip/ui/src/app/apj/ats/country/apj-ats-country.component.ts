import { Component, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatDialog } from '@angular/material';
import {FormBuilder, FormGroup, Validators, FormsModule, NgForm} from '@angular/forms';
import { ApjAtsCountryService } from './apj-ats-country.service';
import{ApjAtsFacadeService} from '@App/shared/apj-ats-facade.service';
import { ApjAtsCountry,Region} from './apj-ats-country.model';
import { Global } from '@App/shared/global';
import {MatSnackBar} from '@angular/material/snack-bar';
import { Action } from 'rxjs/internal/scheduler/Action';
import { LocalStorageService } from 'angular-2-local-storage';
import { NotifierService } from 'angular-notifier';
import { ConfirmationDialogComponent, ConfirmDialogModel } from '@App/shared/confirmation-dialog/confirmation-dialog.component';

@Component({
  selector: 'app-apj-ats-country',
  templateUrl: './apj-ats-country.component.html',
  styleUrls: ['./apj-ats-country.component.css'],
})

export class ApjAtsCountryComponent {
  apjAtsCountryForm: FormGroup;
  CountryList: ApjAtsCountry[];
  RegionList: Region[];
  private apjAtsCountry: ApjAtsCountry = new ApjAtsCountry();
  duplicateCountryList = [];
  showResult: boolean = true;
  ResultBody:boolean = false;
  AddNewResultForNotFound:boolean = false;
  showText:boolean = false;
  selFCSite:string = '-1';
  showAdd: boolean = false;
  userIsEmeaReadOnly: boolean = false;
  searchText: string = ''; 
  searchBy: string = '';
  ResultMessage: boolean = false;
  NoResultAdd: boolean = false;
  selRegion: string = '';
  selProdutType: string = '';
  FulfillmentLocations = [];
  dynamicSelpickersHTML = [];
  dynamicSelpickersData = [];
  indLoading: boolean = false;
  displayedColumns = ['Code','CountryName','RegionId','Action'];
  dataSource: MatTableDataSource<ApjAtsCountry>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  addNewRow: boolean = false;
  private readonly notifier: NotifierService;
  message: string;

  constructor(private fb: FormBuilder,
    private apjAtsCountryService: ApjAtsCountryService,
    private _ApjAtsFacadeService:ApjAtsFacadeService,
    private _snackBar: MatSnackBar,
    private _localStorageService: LocalStorageService,
    notifierService: NotifierService,
    public dialog: MatDialog) {
    // To initialize FormGroup , Validators.required 
    this.apjAtsCountryForm = fb.group({
        'ddlSearchBy': [null],
        'txtSearch': [null],
        'txtCode': [null],
        'txtCountryName': [null],
        'ddlRegionId': [null],
    });
    this.notifier = notifierService;
  }

  ngOnInit(){
    this.init();
  }

  init() {
    this.fillRegions();
    this.dynamicSelpickersHTML.push("<select selectpicker=\"FulfillmentLocations\" ng-model=\"item.site.Id\"><option value=\"-1\">Select Site</option><option ng-repeat=\"f in FulfillmentLocations | orderBy:'SiteCode'\" value=\"{{f.Id}}\">{{::f.SiteCode +' - '+ f.SiteName}}</option></select>");
    this.selRegion = this._localStorageService.get('selRegion');
    this.selProdutType = "ATS";
    this.apjAtsCountryForm.get('ddlSearchBy').setValue('All');
    this.getFulfillmentLocations();
    this.clearSearchText();
    this.searchCountry();
  }

  fillRegions(){
    this.RegionList = [{"name": "AMER", "value":1},{"name": "APJ", "value": 2},{"name": "EMEA", "value": 3}];
  }

  getFulfillmentLocations() {
    this.indLoading = true;
    this._ApjAtsFacadeService.getLocationCode(this.selRegion)
    .subscribe(data => {
      if (data.length > 0) {
        this.FulfillmentLocations = data;
        this.dynamicSelpickersData[0] = this.FulfillmentLocations;
      }
      else {
        this.FulfillmentLocations = [];
      }  
      this.indLoading = false;
    }, 
    error => {
      this.notifier.notify('error', 'Error while fetching Fulfillment Locations');
      this.indLoading = false;
    });
  }

  searchCountry(){
    if (!this.validation('search')) {
      var regEx = new RegExp('^' + this.apjAtsCountryForm.get('txtSearch').value, 'gi');
      this.indLoading = true;
      this.addNewRow = false;
      this._ApjAtsFacadeService.getCountries(this.selRegion)
      .subscribe(data => {
        if(this.apjAtsCountryForm.get('ddlSearchBy').value == "Code") {
          this.CountryList = data.filter(function (el) { return el.code.match(regEx) });
          this.dataSource = new MatTableDataSource(this.CountryList);
          this.dataSource.paginator = this.paginator;
          this.indLoading = false;
        }
        if (this.apjAtsCountryForm.get('ddlSearchBy').value == "Name") {
          this.CountryList = data.filter(function (el) { return el.countryName.match(regEx) });
          this.dataSource = new MatTableDataSource(this.CountryList);
          this.dataSource.paginator = this.paginator;
          this.indLoading = false;
        }
        if (this.apjAtsCountryForm.get('ddlSearchBy').value == "All") {
          this.CountryList = data;
          this.dataSource = new MatTableDataSource(this.CountryList);
          this.dataSource.paginator = this.paginator;
          this.indLoading = false;
        }    
      }, 
      error => {
        this.notifier.notify('error', 'Error while fetching Countries');
        this.indLoading = false;
      });
    }
  }

  saveEdit(item) {
    if (!this.validation((item.Operation == null || undefined) ? 'update' : 'add')) {
      var request = {
        "Operation": (item.Operation == null || undefined) ? 'update' : 'add',
        "Id": item.id,
        "Code": this.apjAtsCountryForm.get('txtCode').value,
        "CountryName": this.apjAtsCountryForm.get('txtCountryName').value,
        "RegionId": this.apjAtsCountryForm.get('ddlRegionId').value,
        "AllowFutureCommit": item.Operation == 'update' ? item.AllowFutureCommit : null,
        "ModifiedBy": "ASIA-PACIFIC\\Kiran_kumar_Kommi",
        "Edit": false,
        "Active": true,
        "site": {
          "Id": item.site == null || undefined ? null : item.site.Id,
          "SiteName": '',
          "SiteCode":'',
          "Description":'',
          "CountryName":'',
          "ModifiedBy":'',
          "CountryId":0,
          "OldCountryId":0,
          "Sequence":0,
          "Type":'',
          "IsActive":false,
          "ProductCountryId":0,
          "Operation":''
        }
      }
      this.indLoading = true;
      this._ApjAtsFacadeService.updateCountry(request)
      .subscribe(data => {
        this.searchCountry();
        this.notifier.notify('success', Global.UpdateMessage);
      },
      error => {
        //this.indLoading = false;
        this.searchCountry();
        this.notifier.notify('error', 'error while updating Country');
      });
    }
    else{
      item.Edit = true;
    }
  }

  createNewUser(): ApjAtsCountry {
    return {
      Id: 0,
      id: 0,
      Code:'',
      code:'',
      CountryName:'',
      countryName:'',
      RegionId: 0,
      regionId: 0,
      Operation: 'add',
      AllowFutureCommit: false,
      Site: null,
      ModifiedBy: "ASIA-PACIFIC\\Kiran_kumar_Kommi",
      Edit: true,
      Active: true,
    };
  }
      
  addRow() {
    if (!this.addNewRow) {
      this.CountryList.forEach(country => {
        country.Edit = false;
      });
      this.addNewRow = true;
      this.dataSource.data.unshift(this.createNewUser());
      this.dataSource.filter = "";
      this.paginator.pageIndex = 0;
      this.dataSource.paginator = this.paginator;
    }
  }

  deleteEntry(postData) {
    this.message = 'Do you want to delete this Country ?';
    const dialogData = new ConfirmDialogModel("Country Delete", this.message);
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, { maxWidth: "100%", data: dialogData, disableClose: true, width: "100%" });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult) {
        var request = {
          "Operation": 'delete',
          "Id": postData.id,
          "Code": postData.code,
          "CountryName": postData.countryName,
          "RegionId": postData.regionId,
          "Active": true,
          "AllowFutureCommit": postData.AllowFutureCommit,
          "ModifiedBy": "ASIA-PACIFIC\\Kiran_kumar_Kommi",
          "Edit": false,
          "site": {
            "Id": postData.site.Id,
            "SiteName": '',
            "SiteCode": '',
            "Description": '',
            "CountryName": '',
            "ModifiedBy": '',
            "CountryId": 0,
            "OldCountryId": 0,
            "Sequence": 0,
            "Type": '',
            "IsActive": false,
            "ProductCountryId": 0,
            "Operation": ''
          }
        }

        this.indLoading = true;
        this._ApjAtsFacadeService.updateCountry(request)
          .subscribe(data => {
            this.searchCountry();
            this.notifier.notify('success', Global.DeleteMessage);
        },
        error => {
          this.indLoading = false;
          this.notifier.notify('error', 'error while updating Country');
        });
      }
    });
  }
    
  toggleEditMode(item) {
    if (!this.addNewRow) {
      this.CountryList.forEach(country => {
        country.Edit = false;
      });
      item.Edit = true;
    }
  }

  cancel(item) {
    if (item.Id == 0) {
      this.searchCountry();
    }
  }

  clearSearchText() {
    if (this.apjAtsCountryForm.get('ddlSearchBy').value == "All") {
      this.apjAtsCountryForm.get('txtSearch').setValue('');
      this.showText = false;
    }
    else {
      this.showText = true;
    }
  }

  validation (type) {
    if (type == 'search') {
      if (this.apjAtsCountryForm.get('ddlSearchBy') == undefined) {
        this.notifier.notify('error', 'Please select SearchBy');
        return true;
      }
      if (this.apjAtsCountryForm.get('ddlSearchBy').value.toUpperCase() == "NAME") {
        if (this.apjAtsCountryForm.get('txtSearch').value < 1) {
          this.notifier.notify('error', 'Please enter Country Name for search.');
          return true;
        };
      }
      if (this.apjAtsCountryForm.get('ddlSearchBy').value.toUpperCase() == "CODE") {
        if (this.apjAtsCountryForm.get('txtSearch').value.length < 1) {
          this.notifier.notify('error', 'Please enter Country Code for search.');
          return true;
        };
      }
      return false;
    }

    if (type == 'update' || type == 'add') {
      if (this.apjAtsCountryForm.get('txtCode').value == undefined || this.apjAtsCountryForm.get('txtCode').value.trim().length == 0) {
        this.notifier.notify('error', 'Please enter Code');
        return true;
      }
      if (this.apjAtsCountryForm.get('txtCode').value.length < 2) {
        this.notifier.notify('error', 'Please enter minimum 2 characters for the Country Code.');
        return true;
      }
      if (this.apjAtsCountryForm.get('txtCountryName').value == undefined || this.apjAtsCountryForm.get('txtCountryName').value.trim().length == 0) {
        this.notifier.notify('error', 'Please enter Name');
        return true;
      }
      if (this.apjAtsCountryForm.get('txtCountryName').value.length < 3) {
        this.notifier.notify('error', 'Please enter minimum 3 characters for the Country Name.');
        return true;
      }
      if (this.apjAtsCountryForm.get('ddlRegionId').value == undefined || this.apjAtsCountryForm.get('ddlRegionId').value == 0) {
        this.notifier.notify('error', 'Please select a Region');
        return true;
      }
    }

    if (type == 'add') {
      var code = this.apjAtsCountryForm.get('txtCode').value;
      this.duplicateCountryList = this.CountryList.filter(function (el) { return el.code.toUpperCase() === code.toUpperCase() });
      if (this.duplicateCountryList.length > 0) {
        this.notifier.notify('error', 'Duplicate Country Code');
        return true;
      }
    }
  }
}




