﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsItemSiteInventory : AtsCommon
    {
        public int OnHand { get; set; }
        public int Commit { get; set; }
        public int FutureCommit { get; set; }
        public int RoutingThresold { get; set; }
        public int Shipped { get; set; }
        public int AvailableToSell { get; set; }
        public string FulfillmentLocationName { get; set; }
        public int FulfillmentLocationId { get; set; }
        public string FacilityCode { get; set; }
        public int ProductCountryID { get; set; }



    }
}
