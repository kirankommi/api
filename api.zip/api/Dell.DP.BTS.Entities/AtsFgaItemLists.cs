﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsFgaItemLists
    {
        public List<AtsItem> AtsFGAItems { get; set; }
        public int? RecordCount { get; set; }
    }
}
