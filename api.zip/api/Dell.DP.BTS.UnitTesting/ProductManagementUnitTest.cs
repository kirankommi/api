﻿using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    /// <summary>
    /// Summary description for ProductConfigurationUnitTest
    /// </summary>
    
    public class ProductManagementUnitTest:UnitTestInitializer
    {


        [Fact]
        public void GetProductManagementDataShouldReturnOKResult()
        {
            int productID = 6;
            int regionId = 3;
            var result = btsQueryController.GetProductDetails(productID, regionId);
            Assert.NotNull(result);
        }
    }
}
