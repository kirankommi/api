﻿using Dell.DP.BTS.Entities;
using Dell.DP.BTS.API.Controllers;
using Dell.DP.BTS.DataServices;
using Dell.DP.BTS.BusinessServices;
using Xunit;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.AspNetCore.Mvc;

namespace Dell.DP.BTS.UnitTesting
{
    
    public class DashboardItemDetailsAddRemoveFulfillmentCentersUnitTest : UnitTestInitializer
    {
        List<AtsSite> sites;
        AtsSite _AtsSite_1st, _AtsSite_2nd, _AtsSite_3rd, _AtsSite_4th, _AtsSite_5th = null;


        [Fact]
        public void AnewsingleFulfillmentcenterarelinkedaSKUforwhichnopriorcommitsexists()
        {
            sites = new List<AtsSite>();
            _AtsSite_1st = new AtsSite();
            _AtsSite_1st.Id = 16;
            _AtsSite_1st.IsActive = false;
            _AtsSite_1st.ProductCountryId = 52165;
            _AtsSite_1st.UpdatedBy = "Jitendra_kumar_Pradh";
            _AtsSite_1st.UpdatedOn = System.DateTime.Now;
            sites.Add(_AtsSite_1st);

            _AtsSite_2nd = new AtsSite();
            _AtsSite_2nd.Id = 21;
            _AtsSite_2nd.IsActive = false;
            _AtsSite_2nd.ProductCountryId = 52165;
            _AtsSite_2nd.UpdatedBy = "Jitendra_kumar_Pradh";
            _AtsSite_2nd.UpdatedOn = System.DateTime.Now;
            sites.Add(_AtsSite_2nd);

            _AtsSite_3rd = new AtsSite();
            _AtsSite_3rd.Id = 28;
            _AtsSite_3rd.IsActive = false;
            _AtsSite_3rd.ProductCountryId = 52165;
            _AtsSite_3rd.UpdatedBy = "Jitendra_kumar_Pradh";
            _AtsSite_3rd.UpdatedOn = System.DateTime.Now;
            sites.Add(_AtsSite_3rd);

            _AtsSite_4th = new AtsSite();
            _AtsSite_4th.Id = 29;
            _AtsSite_4th.IsActive = false;
            _AtsSite_4th.ProductCountryId = 52165;
            _AtsSite_4th.UpdatedBy = "Jitendra_kumar_Pradh";
            _AtsSite_4th.UpdatedOn = System.DateTime.Now;
            sites.Add(_AtsSite_4th);

            _AtsSite_5th = new AtsSite();
            _AtsSite_5th.Id = 34;
            _AtsSite_5th.IsActive = true;
            _AtsSite_5th.ProductCountryId = 52165;
            _AtsSite_5th.UpdatedBy = "Jitendra_kumar_Pradh";
            _AtsSite_5th.UpdatedOn = System.DateTime.Now;
            sites.Add(_AtsSite_5th);

            var result = btsCommandController.UpdateFulfillmentLocation(sites);
            Asserts(result);
        }


        [Fact]

        public void AnewsingleFulfillmentcenterlinkedSKUforwhichpriorcommitsexists()
        {
            sites = new List<AtsSite>();
            _AtsSite_1st = new AtsSite();
            _AtsSite_1st.Id = 16;
            _AtsSite_1st.IsActive = false;
            _AtsSite_1st.ProductCountryId = 52165;
            _AtsSite_1st.UpdatedBy = "Jitendra_kumar_Pradh";
            _AtsSite_1st.UpdatedOn = System.DateTime.Now;
            sites.Add(_AtsSite_1st);

            _AtsSite_2nd = new AtsSite();
            _AtsSite_2nd.Id = 21;
            _AtsSite_2nd.IsActive = false;
            _AtsSite_2nd.ProductCountryId = 52165;
            _AtsSite_2nd.UpdatedBy = "Jitendra_kumar_Pradh";
            _AtsSite_2nd.UpdatedOn = System.DateTime.Now;
            sites.Add(_AtsSite_2nd);

            _AtsSite_3rd = new AtsSite();
            _AtsSite_3rd.Id = 28;
            _AtsSite_3rd.IsActive = false;
            _AtsSite_3rd.ProductCountryId = 52165;
            _AtsSite_3rd.UpdatedBy = "Jitendra_kumar_Pradh";
            _AtsSite_3rd.UpdatedOn = System.DateTime.Now;
            sites.Add(_AtsSite_3rd);

            _AtsSite_4th = new AtsSite();
            _AtsSite_4th.Id = 29;
            _AtsSite_4th.IsActive = true;
            _AtsSite_4th.ProductCountryId = 52165;
            _AtsSite_4th.UpdatedBy = "Jitendra_kumar_Pradh";
            _AtsSite_4th.UpdatedOn = System.DateTime.Now;
            sites.Add(_AtsSite_4th);

            _AtsSite_5th = new AtsSite();
            _AtsSite_5th.Id = 34;
            _AtsSite_5th.IsActive = true;
            _AtsSite_5th.ProductCountryId = 52165;
            _AtsSite_5th.UpdatedBy = "Jitendra_kumar_Pradh";
            _AtsSite_5th.UpdatedOn = System.DateTime.Now;
            sites.Add(_AtsSite_5th);

            var result = btsCommandController.UpdateFulfillmentLocation(sites);
            Asserts(result);
        }

        public void Asserts(IActionResult result)
        {
            Assert.NotNull(result);
        }

    }
}
