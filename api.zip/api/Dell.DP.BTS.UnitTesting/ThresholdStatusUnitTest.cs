﻿using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    
    public class ThresholdStatusUnitTest : UnitTestInitializer
    {

        [Fact]
        public void GetThresholdStatusDetailShouldReturnOKResult()
        {
            var productCountryId = 5988;
            var result = btsQueryController.GetAtsItemDetail(productCountryId);
            Assert.NotNull(result);
        }      
    }
}
