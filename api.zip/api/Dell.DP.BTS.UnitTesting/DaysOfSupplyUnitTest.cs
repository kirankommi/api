﻿using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    
    public class DaysOfSupplyUnitTest : UnitTestInitializer
    {

        [Fact]
        public void GetDaysOfSupplyShouldReturnOKResult()
        {
            var productCountryId = 5988;
            var result = btsQueryController.GetDaysofSupply(productCountryId);
            Assert.NotNull(result);
        }      
    }
}
