﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class InTransitDetailSearchResponse
    {
        public string Type { get; set; }
        public string Catalog { get; set; }
        public string Sku { get; set; }
        public string Part { get; set; }
        public int? AggregateATS { get; set; }
        public int? SDSThreshold { get; set; }
        public int? NetSDS { get; set; }
        public int? InOversellThreshold { get; set; }
        public int? NetOversell { get; set; }
        public int? InOversoldThreshold { get; set; }
        public int? NetOversold { get; set; }
        public string LTSource { get; set; }
        public int? CurrentLT { get; set; }
        public int? DefaultLT { get; set; }
        public int? ExtendedLT { get; set; }
        public string SiteCode { get; set; }
        public int? OnHandQuantity { get; set; }
        public int? Commit { get; set; }
        public int? RoutingThreshold { get; set; }
        public int? NetATS { get; set; }
        public int? InboundSupply { get; set; }
        public string SupplyETA { get; set; }
        public string ShipmentMode { get; set; }
        public string GroupName { get; set; }
        public string Status { get; set; }
    }
}
