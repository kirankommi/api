import { Injectable } from '@angular/core';
import { DataservicesProvider } from '@Dataservice/dataservices/dataservices';
import { environment } from '@Environments/environment';

@Injectable({
  providedIn: 'root'
})
export class FulfillmentCenterService {

  constructor(private _DataservicesProvider: DataservicesProvider) {

  }
  getProductFulfillment(ProductCountryId, RegionId) {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getProductFulfillmentLocation/' + ProductCountryId + "/" + RegionId);
  }
  updateFulfillmentLocation(postData) {
    return this._DataservicesProvider.PostDataWithHeader(environment.ApjEmeaAtsApiUrl + 'command/updateFulfillmentLocation/', postData);
  }

}
