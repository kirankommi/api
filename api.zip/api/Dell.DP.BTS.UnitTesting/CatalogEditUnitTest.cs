﻿using Dell.DP.BTS.Entities;
using Dell.DP.BTS.API.Controllers;
using Dell.DP.BTS.DataServices;
using Dell.DP.BTS.BusinessServices;
using Xunit;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.AspNetCore.Mvc;


namespace Dell.DP.BTS.UnitTesting
{
  
    public class CatalogEditUnitTest : UnitTestInitializer
    {
        [Fact]
        public void UpdateCatalogsDataShouldReturnOKResult()
        {
            AtsCatalog items = new AtsCatalog()
            {
                CountryName= "MEXICO", RegionCode= "MX COMMERCIAL", CatalogId= 323203, RegionId= 3, CatalogGroup = string.Empty, CatalogGroupId = 0, CountryCodes = string.Empty, CountryId = 25, CountryIds = new int[0], CountryIdsCsv = string.Empty, Id = 37, UserID = string.Empty
            };
            var result = btsCommandController.UpdateCatalog(items);
            Asserts(result);
        }
        public void Asserts(IActionResult result)
        {
            Assert.NotNull(result);
        }
    }
}
