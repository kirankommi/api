export const environment = {
  production: false,
  ApjEmeaAtsApiUrl: 'https://dpemeaapjbtsinternalapi.ausmpc.pcf.dell.com/api/'

};
