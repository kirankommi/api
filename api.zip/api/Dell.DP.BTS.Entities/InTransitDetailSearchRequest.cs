﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class InTransitDetailSearchRequest
    {
        public string CountryIds { get; set; }
        public string SiteIds { get; set; }
        public string TypeId { get; set; }
        public string Parts { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}
