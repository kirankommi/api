﻿using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    
    public class DataRefreshUnitTest : UnitTestInitializer
    {

        [Fact]
        public void GetDataRefreshDetailShouldReturnOKResult()
        {
            var productCountryId = 5988;
            var result = btsQueryController.GetDataRefreshDetail(productCountryId);
            Assert.NotNull(result);
        }      
    }
}
