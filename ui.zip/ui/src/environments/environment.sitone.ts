export const environment = {
  production: false,
  ApjEmeaAtsApiUrl: 'https://dpemeaapjbtsapi-g1.ausvdc02.pcf.dell.com/api/'

};
