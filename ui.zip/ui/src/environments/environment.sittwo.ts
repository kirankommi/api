export const environment = {
  production: false,
  ApjEmeaAtsApiUrl: 'https://dpemeaapjbtsapi-g2.ausvdc02.pcf.dell.com/api/'

};
