﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class InTransitDetailSearchResultList
    {
        public List<InTransitDetailSearchResponse> inTransitDetailList { get; set; }
        public int? RecordCount { get; set; }
    }
}
