export class AtsJobDetail {
  Source: string;
  Name: string;
  Description: string;
  Status: string;
  ExecutionStatus: string;
  Schedule: string;
  LastRunTime: string;
  NextRunTime: string;
  ManualOverride: string;
  Action: string;
}

export class AtsJobTransactionStatus {
  name: string;
  reservationStatus: string;
  lastUpdatedAt: string;
  lastUpdatedBy: string;
}
