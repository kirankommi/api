import { NgModule } from '@angular/core';
import { CommonModule, HashLocationStrategy, LocationStrategy } from '@angular/common';
import { Routes, RouterModule, ɵROUTER_PROVIDERS } from '@angular/router';
import { CustomtableComponent } from '../customtable/customtable.component';
import { HomeComponent } from '../home/home.component';
import { DashboardComponent } from '../america/dashboard/dashboard.component'
import { ApjAtsDashboardComponent } from '../apj/ats/dashboard/apj-ats-dashboard.component';
import { FileuploadComponent } from '../apj/ats/fileupload/fileupload.component';
import { ApjAtsCountryComponent } from '../apj/ats/country/apj-ats-country.component';
import { ApjAtsCommitFalloutComponent } from '../apj/ats/reports/commitfallout/apj-ats-commitfallout.component';
import { CommitDetailsComponent } from '../apj/ats/commit-details/commit-details.component';
import { MassuploadProductManagementComponent } from '../apj/ats/massupload/massupload-product-management/massupload-product-management.component';
import { MassuploadLeadtimeManagementComponent } from '../apj/ats/massupload/massupload-leadtime-management/massupload-leadtime-management.component';
import { AgedReportComponent } from '../apj/ats/reports/aged-report/aged-report.component'
import { ApjAtsConfigMgmtComponent } from '../apj/ats/configuration-management/apj-ats-configmgmt.component';
import { JobConfigurationComponent } from '../apj/ats/job-configuration/job-configuration.component';
import { ApjAtsProductConfigComponent } from '../apj/ats/product-config/apj-ats-product-config.component';
import { ApjAtsCatalogComponent } from '../apj/ats/catalog/apj-ats-catalog.component';
import { ItemExceptionReportComponent  } from '../apj/ats/reports/item-exception-report/item-exception-report.component'
import { ApjAtsRuleManagerComponent } from '../apj/ats/rule-manager/apj-ats-rulemanager.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'ats-dashboard', component: ApjAtsDashboardComponent },
  { path: 'FileUpload', component: FileuploadComponent },
  { path: 'MassuploadProductManagement', component: MassuploadProductManagementComponent },
  { path: 'MassuploadLeadtimeManagement', component: MassuploadLeadtimeManagementComponent },
  { path: 'ats-country', component: ApjAtsCountryComponent },
  { path: 'ats-commitfallout', component: ApjAtsCommitFalloutComponent },
  { path: 'ats-commitdetails', component: CommitDetailsComponent },
  { path: 'aged-report', component: AgedReportComponent },
  { path: 'ats-configmgmt', component: ApjAtsConfigMgmtComponent },
  { path: 'ats-jobConfiguration', component: JobConfigurationComponent },
  { path: 'ats-productconfig', component: ApjAtsProductConfigComponent },
  { path: 'ats-catalog', component: ApjAtsCatalogComponent },
  { path: 'ats-ruleManager', component: ApjAtsRuleManagerComponent },

  { path: 'item-exception-report', component: ItemExceptionReportComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' }

];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  providers: [{ provide: LocationStrategy, useClass: HashLocationStrategy }],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class RoutingModule { }
