﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsJobDetails
    {
        public string Source { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public string ExecutionStatus { get; set; }
        public string Schedule { get; set; }
        public string LastRunTime { get; set; }
        public string NextRunTime { get; set; }
        public string ManualOverride { get; set; }
        public int Action { get; set; }
    }
}
