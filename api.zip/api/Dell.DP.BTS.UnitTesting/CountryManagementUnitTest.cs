﻿using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    /// <summary>
    /// Summary description for CountryManagementUnitTest
    /// </summary>
    
    public class CountryManagementUnitTest:UnitTestInitializer
    {

        [Fact]
        public void GetCountriesDataShouldReturnOKResult()
        {
            int region = 3;
            var result = btsQueryController.GetCountries(region);
            Assert.NotNull(result);
        }
        [Fact]
        public void GetCountriesByCodeDataShouldReturnOKResult()
        {
            int region = 3;
            string code = "UK";
            var result = btsQueryController.GetCountries(region);
            Assert.NotNull(result);
        }

        [Fact]
        public void GetCountriesByNameDataShouldReturnOKResult()
        {
            int region = 3;
            string name = "UNITED KINGDOM";
            var result = btsQueryController.GetCountries(region);
            Assert.NotNull(result);
        }
    }
}
