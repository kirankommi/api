export const environment = {
  production: false,
  ApjEmeaAtsApiUrl: 'https://dpemeaapjbtsapi-dev.ausvdc02.pcf.dell.com/api/'

};
