﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dell.DP.BTS.Entities
{
    public class Context
    {
        public string RegionName { get; set; }
        public int RegionId { get; set; }
    }
}
