﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class FutureCommitRequest
    {
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public int? Status { get; set; }
        public string OrderNumbers { get; set; }
        public string Parts { get; set; }
        public string SelectedLobIds { get; set; }
        public string SelectedFamilyParentIds { get; set; }
        public string SelectedMarketingIds { get; set; }
        public string SKUs { get; set; }
        public int? SelectedRange { get; set; }
    }
}
