﻿using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    /// <summary>
    /// Summary description for CountryManagementUnitTest
    /// </summary>
    
    public class fulfillmentLocationEditUnitTest : UnitTestInitializer
    {

        [Fact]
        public void UpdatefulfillmentLocationsDataShouldReturnOKResult()
        {
            var result = btsCommandController.UpdateFulfillmentLocations(atsSites);
            Assert.NotNull(result);
        }
    }
}
