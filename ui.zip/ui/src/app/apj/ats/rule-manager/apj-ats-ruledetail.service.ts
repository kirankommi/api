import { Injectable } from '@angular/core';
import {DataservicesProvider} from '@Dataservice/dataservices/dataservices';
import { Global } from '@App/shared/global';
import { Observable } from 'rxjs/Observable';
import { Configurations } from './apj-ats-rulemanager.model';
import { environment } from '@Environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ApjAtsRuleDetailService {

  constructor(private _DataservicesProvider: DataservicesProvider) {
  }

  getCatalog(data) {
    return this._DataservicesProvider.PostData(environment.ApjEmeaAtsApiUrl + 'getCatalog', data);
  }

  getapplicationruleconfigurations(filter): Observable<Configurations> {
    return this._DataservicesProvider.PostData(environment.ApjEmeaAtsApiUrl + 'getapplicationruleconfigurations/', filter);
  }

  getProductLines(catalogId) {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getProductLines/' + catalogId);
  }

  getBrands(productLineId) {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getBrands/' + productLineId);
  }

  updateapplicationruleconfiguration(atsApplicationConfigurationList) {
    return this._DataservicesProvider.PostData(environment.ApjEmeaAtsApiUrl + 'command/updateapplicationruleconfiguration/', atsApplicationConfigurationList);
  }
}
