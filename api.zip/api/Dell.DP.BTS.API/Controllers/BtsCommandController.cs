﻿using Dell.DP.BTS.BusinessServices.CommandBusiness.Interfaces;
using Dell.DP.BTS.Entities;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Dell.DP.BTS.API.Controllers
{
    [Route("api/command")]
    [ApiController]
    [EnableCors("CORSPolicy")]
    public class BtsCommandController : ControllerBase
    {
        #region Private Members
        /// <summary>
        /// This property can be used bts inventory Command business object as dynamic
        /// </summary>
        private readonly IBtsCommandBusiness _btsCommandBusiness;
        #endregion

        #region Constructor
        /// <summary>
        /// Paramterised constructor with inventory Command business object as parameter 
        /// </summary>
        /// <param name="inventoryCommandBusiness"></param>
        public BtsCommandController(IBtsCommandBusiness btsCommandBusiness) => _btsCommandBusiness = btsCommandBusiness;
        #endregion

        #region Http Get routes
        /// <summary>
        /// This end point can be used to test the API health
        /// </summary>
        /// <returns>boolean value</returns>
        [HttpGet]
        [Route("IsAlive")]
        public IActionResult IsAlive()
        {
            var result = _btsCommandBusiness.IsAlive();
            return Ok(result);
        }

        [HttpPost]
        [Route("updateCatalog")]
        public IActionResult UpdateCatalog([FromBody] AtsCatalog atsCatalog)
        {
            _btsCommandBusiness.UpdateCatalog(atsCatalog);
            return Ok(_btsCommandBusiness.DbCommandResult);
        }

        [HttpPost]
        [Route("deleteCatalog")]
        public IActionResult DeleteCatalog([FromBody] AtsCatalog atsCatalog)
        {
            _btsCommandBusiness.DeleteCatalog(atsCatalog);
            return Ok(_btsCommandBusiness.DbCommandResult);
        }

        [HttpPost]
        [Route("updateCountry")]
        public IActionResult UpdateCountry([FromBody] AtsCountry atsCountry)
        {
            _btsCommandBusiness.UpdateCountry(atsCountry);
            return Ok(_btsCommandBusiness.DbCommandResult);

        }
        [HttpPost]
        [Route("updateapplicationconfiguration")]
        public IActionResult UpdateApplicationConfiguration([FromBody] AtsApplicationConfiguration atsAppConfig)
        {
            _btsCommandBusiness.UpdateApplicationConfiguration(atsAppConfig);
            return Ok(_btsCommandBusiness.DbCommandResult);
        }

        [HttpPost]
        [Route("updateapplicationruleconfiguration")]
        public IActionResult UpdateApplicationRuleConfiguration([FromBody] AtsApplicationConfiguration atsAppConfig)
        {
            _btsCommandBusiness.UpdateApplicationConfiguration(atsAppConfig);
            return Ok(_btsCommandBusiness.DbCommandResult);
        }
        [HttpPost]
        [Route("UpdateProductConfiguration")]
        public IActionResult UpdateProductConfiguration([FromBody] AtsProductConfiguration productConfiguration)
        {
            _btsCommandBusiness.UpdateProductConfiguration(productConfiguration);
            return Ok(_btsCommandBusiness.DbCommandResult);
        }

        [HttpPost]
        [Route("updateProductInformation")]
        public IActionResult UpdateProductInformation([FromBody] AtsProductInfoAddUpdateRequest prodRequest)
        {
            _btsCommandBusiness.UpdateProductInformation(prodRequest);
            return Ok(_btsCommandBusiness.DbCommandResult);
        }

        [HttpPost]
        [Route("updateContinueToSell")]
        public IActionResult UpdateContinueToSell([FromBody] AtsItemDetail atsItemDetail)
        {
            _btsCommandBusiness.UpdateContinueToSell(atsItemDetail);
            return Ok(_btsCommandBusiness.DbCommandResult);
        }

        [HttpPost]
        [Route("updateDisplayLowInventory")]
        public IActionResult UpdateDisplayLowInventory([FromBody] AtsItemDetail atsItemDetail)
        {
            _btsCommandBusiness.UpdateDisplayLowInventory(atsItemDetail);
            return Ok(_btsCommandBusiness.DbCommandResult);
        }

        [HttpPost]
        [Route("updateIsActive")]
        public IActionResult UpdateIsActive([FromBody] AtsItemDetail atsItemDetail)
        {
            _btsCommandBusiness.UpdateIsActive(atsItemDetail);
            return Ok(_btsCommandBusiness.DbCommandResult);
        }

        [HttpPost]
        [Route("updateLeadTime")]
        public IActionResult updateLeadTime([FromBody] AtsItemDetail prodRequest)
        {
            _btsCommandBusiness.UpdateLeadTime(prodRequest);
            return Ok(_btsCommandBusiness.DbCommandResult);
        }
        [HttpPost]
        [Route("updateFulfillmentLocation")]
        public IActionResult UpdateFulfillmentLocation([FromBody] List<AtsSite> sites)
        {
            _btsCommandBusiness.UpdateFulfillmentLocation(sites);
            return Ok(_btsCommandBusiness.DbCommandResult);
        }
        [HttpPost]
        [Route("updateFulfillmentLocations")]
        public IActionResult UpdateFulfillmentLocations([FromBody] AtsSite sites)
        {
            //TODO:: Try catch
            _btsCommandBusiness.UpdateFulfillmentLocations(sites);

            return Ok(_btsCommandBusiness.DbCommandResult);
        }
        [HttpPost]
        [Route("updateThreshold")]
        public IActionResult UpdateThreshold([FromBody] AtsItemDetail prodRequest)
        {
            _btsCommandBusiness.UpdateThreshold(prodRequest);
            return Ok(_btsCommandBusiness.DbCommandResult);
        }

        [HttpPost]
        [Route("cancelCommitOrder")]
        public IActionResult CancelCommitOrder([FromBody] List<AtsCommitDetail> commitDetail)
        {
            _btsCommandBusiness.CancelReservation(commitDetail);
            return Ok(_btsCommandBusiness.DbCommandResult);
        }

        [HttpPost]
        [Route("updateMarkAsFulfill")]
        public IActionResult UpdateMarkAsFulfill([FromBody] List<AtsCommitDetail> commitDetail)
        {
            _btsCommandBusiness.MarkAsFulfill(commitDetail);
            return Ok(_btsCommandBusiness.DbCommandResult);
        }

        #endregion

        #region Http Post routes

        #endregion
    }
}