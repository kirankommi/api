﻿using Dell.DP.BTS.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.BusinessServices.CommandBusiness.Interfaces
{
    public interface IBtsCommandBusiness
    {
        bool IsAlive();
        DbCommandResult DbCommandResult { get; }
        void UpdateCatalog(AtsCatalog atsCatalog);
        void DeleteCatalog(AtsCatalog Item);
        void UpdateCountry(AtsCountry atsCountry);
        void UpdateApplicationConfiguration(AtsApplicationConfiguration Item);
        void UpdateProductConfiguration(AtsProductConfiguration productConfig);
        void UpdateProductInformation(AtsProductInfoAddUpdateRequest prodRequest);
        void UpdateContinueToSell(AtsItemDetail atsItemDetail);
        void UpdateDisplayLowInventory(AtsItemDetail atsItemDetail);
        void UpdateIsActive(AtsItemDetail atsItemDetail);
        void UpdateLeadTime(AtsItemDetail AtsDetail);
        void UpdateFulfillmentLocation(List<AtsSite> sites);
        void UpdateFulfillmentLocations(AtsSite sites);
        void MarkAsFulfill(List<AtsCommitDetail> Items);
        void CancelReservation(List<AtsCommitDetail> Items);
        void UpdateThreshold(AtsItemDetail AtsDetail);
    }
}
