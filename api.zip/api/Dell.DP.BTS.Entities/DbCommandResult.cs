﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class DbCommandResult
    {
        public int? TotalRecords { get; set; }
        public int? FailedRecords { get; set; }
        public string ErrorMessage { get; set; }
        public int? RowsModifiedInDb { get; set; }
        public AtsProductInfoAddUpdateResponse AtsResponse { get; set; }
    }
}
