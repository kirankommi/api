﻿using Dell.DP.BTS.DataServices.DbFactory;
using Dell.DP.BTS.DataServices.CommandRepository.Interfaces;
using Dell.DP.BTS.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace Dell.DP.BTS.DataServices.CommandRepository.Implementation
{
    public class BtsCommandRepository : IBtsCommandRepository
    {
        private readonly IDbFactory _atsCommandDbFactory;
        public DbCommandResult DbCommandResult { get; private set; }
        public BtsCommandRepository(IDbFactory atsCommandDbFactory)
        {
            this._atsCommandDbFactory = atsCommandDbFactory;
        }
        public int UpdateCatalog(AtsCatalog atsCatalog)
        {
            var prmId = new SqlParameter("@Id", atsCatalog.Id);
            var prmRegionCode = new SqlParameter("@Name", atsCatalog.RegionCode);
            var prmCountryId = new SqlParameter("@CountryId", atsCatalog.CountryId);
            var prmCatalogId = new SqlParameter("@CatalogId", atsCatalog.CatalogId);

            int numOfRowsEffected = 0;
            using (var connection = _atsCommandDbFactory.Database.CreateConnection())
            {
                connection.Open();
                using (var dbCommand = connection.CreateCommand())
                {
                    dbCommand.CommandType = CommandType.StoredProcedure;
                    dbCommand.CommandText = "DPM_ATS_UpdateRegion";

                    dbCommand.Parameters.Add(prmId);
                    dbCommand.Parameters.Add(prmRegionCode);
                    dbCommand.Parameters.Add(prmCountryId);
                    dbCommand.Parameters.Add(prmCatalogId);

                    dbCommand.CommandTimeout = 180;

                    numOfRowsEffected = _atsCommandDbFactory.Database.ExecuteNonQuery(dbCommand);

                }
                connection.Close();
                return numOfRowsEffected;
            }
        }
        public void DeleteCatalog(AtsCatalog Item)
        {


            var prmId = new SqlParameter("@Id", Item.Id);

            using (var connection = _atsCommandDbFactory.Database.CreateConnection())
            {
                connection.Open();
                using (var dbCommand = connection.CreateCommand())
                {
                    dbCommand.CommandType = CommandType.StoredProcedure;
                    dbCommand.CommandText = "DPM_ATS_DeleteRegion";

                    dbCommand.Parameters.Add(prmId);

                    dbCommand.CommandTimeout = 180;

                    _atsCommandDbFactory.Database.ExecuteNonQuery(dbCommand);

                }
                connection.Close();
            }
        }
        public int UpdateProductConfiguration(AtsProductConfiguration productConfig)
        {
            int numOfRowsEffected = 0;
            var prmLowThreshold = new SqlParameter("@LowThreshold", productConfig.LowThreshold);
            var prmRoutingThreshold = new SqlParameter("@RoutingThreshold", productConfig.RoutingThreshold);
            var prmInOversellThreshold = new SqlParameter("@InOversellThreshold", productConfig.OversellThreshold);
            var prmInOversoldThreshold = new SqlParameter("@InOversoldThreshold", productConfig.OversoldThreshold);
            var prmBufferThreshold = new SqlParameter("@BufferThreshold", productConfig.BufferThreshold);
            var prmDisplayLowInventory = new SqlParameter("@DisplayLowInventory", productConfig.DisplayLowInventory);
            var prmIncludePreCheckout = new SqlParameter("@IncludePreCheckout", productConfig.IncludePreCheckout);
            var prmIncludeCheckout = new SqlParameter("@IncludePostCheckout", productConfig.IncludeCheckout);
            var prmSellAction = new SqlParameter("@SellAction", productConfig.SellAction);
            var prmFGASCDHOverride = new SqlParameter("@FGASCDHOverride", productConfig.FGASCDHOverride);
            var prmSnPSCDHOverride = new SqlParameter("@SnPSCDHOverride", productConfig.SnPSCDHOverride);
            var prmModifiedBy = new SqlParameter("@ModifiedBy", productConfig.UserName);
            var prmUpdateAction = new SqlParameter("@UpdateAction", productConfig.UpdateAction);

            using (var connection = _atsCommandDbFactory.Database.CreateConnection())
            {
                connection.Open();
                using (var dbCommand = connection.CreateCommand())
                {
                    dbCommand.CommandType = CommandType.StoredProcedure;
                    dbCommand.CommandText = "DPM_ATS_updateProductConfiguration";

                    dbCommand.Parameters.Add(prmLowThreshold);
                    dbCommand.Parameters.Add(prmRoutingThreshold);
                    dbCommand.Parameters.Add(prmInOversellThreshold);
                    dbCommand.Parameters.Add(prmInOversoldThreshold);
                    dbCommand.Parameters.Add(prmBufferThreshold);
                    dbCommand.Parameters.Add(prmDisplayLowInventory);
                    dbCommand.Parameters.Add(prmIncludePreCheckout);
                    dbCommand.Parameters.Add(prmIncludeCheckout);
                    dbCommand.Parameters.Add(prmSellAction);
                    dbCommand.Parameters.Add(prmFGASCDHOverride);
                    dbCommand.Parameters.Add(prmSnPSCDHOverride);
                    dbCommand.Parameters.Add(prmModifiedBy);
                    dbCommand.Parameters.Add(prmUpdateAction);

                    dbCommand.CommandTimeout = 180;

                    numOfRowsEffected = _atsCommandDbFactory.Database.ExecuteNonQuery(dbCommand);

                }
            }
            return numOfRowsEffected;
        }
        public void UpdateProductInformation(AtsProductInfoAddUpdateRequest prodRequest)
        {
            using (var connection = _atsCommandDbFactory.Database.CreateConnection())
            {
                connection.Open();
                using (var dbCommand = connection.CreateCommand())
                {
                    dbCommand.CommandType = CommandType.StoredProcedure;
                    dbCommand.CommandText = "DPM_ATS_UpdateProductManagement";

                    string xmlBody = GetProductXML(prodRequest.ProductInfo);

                    var paramXml = new SqlParameter() { ParameterName = "@Request", Direction = ParameterDirection.Input, SqlDbType = SqlDbType.Xml, Value = xmlBody };
                    var paramProdId = new SqlParameter() { ParameterName = "@ProductID", Direction = ParameterDirection.Output, SqlDbType = SqlDbType.Int, Value = prodRequest.ProductId };
                    var paramFgaId = new SqlParameter() { ParameterName = "@FgaID", Direction = ParameterDirection.Output, SqlDbType = SqlDbType.VarChar, Value = prodRequest.FgaId };
                    var paramError = new SqlParameter() { ParameterName = "@Error", Direction = ParameterDirection.Output, SqlDbType = SqlDbType.VarChar, Size = -1 };

                    dbCommand.Parameters.Add(paramXml);
                    dbCommand.Parameters.Add(paramProdId);
                    dbCommand.Parameters.Add(paramFgaId);
                    dbCommand.Parameters.Add(paramError);

                    dbCommand.CommandTimeout = 180;

                    _atsCommandDbFactory.Database.ExecuteNonQuery(dbCommand);
                    AtsProductInfoAddUpdateResponse response = new AtsProductInfoAddUpdateResponse();
                    response.ProductID = Convert.ToInt32(paramProdId.Value);
                    response.FGAID = Convert.ToString(paramFgaId.Value);
                    response.Error = Convert.ToString(paramError.Value);
                    this.DbCommandResult.AtsResponse = response;
                }
                connection.Close();
            }
        }
        string BuildRuleInfo(AtsApplicationConfiguration atsAppConfig)
        {
            XmlDocument xml = new XmlDocument();
            XmlElement root = xml.CreateElement("Rule");
            xml.AppendChild(root);

            XmlElement configName = xml.CreateElement("Name");
            configName.InnerText = atsAppConfig.ConfigName;
            root.AppendChild(configName);

            XmlElement applicationID = xml.CreateElement("ApplicationID");
            applicationID.InnerText = Convert.ToString(atsAppConfig.ApplicationID);
            root.AppendChild(applicationID);

            XmlElement applicationName = xml.CreateElement("ApplicationName");
            applicationName.InnerText = atsAppConfig.ApplicationName;
            root.AppendChild(applicationName);

            XmlElement catalogID = xml.CreateElement("CatalogID");
            catalogID.InnerText = Convert.ToString(atsAppConfig.CatalogId);
            root.AppendChild(catalogID);

            XmlElement catalogName = xml.CreateElement("CatalogName");
            catalogName.InnerText = atsAppConfig.CatalogName;
            root.AppendChild(catalogName);

            XmlElement productLineID = xml.CreateElement("ProductLineID");
            productLineID.InnerText = Convert.ToString(atsAppConfig.ProductLineId);
            root.AppendChild(productLineID);

            XmlElement productLineName = xml.CreateElement("ProductLineName");
            productLineName.InnerText = atsAppConfig.ProductLine;
            root.AppendChild(productLineName);

            XmlElement brandID = xml.CreateElement("BrandID");
            brandID.InnerText = Convert.ToString(atsAppConfig.BrandId);
            root.AppendChild(brandID);

            XmlElement brandName = xml.CreateElement("BrandName");
            brandName.InnerText = atsAppConfig.BrandName;
            root.AppendChild(brandName);

            XmlElement familyID = xml.CreateElement("FamilyID");
            familyID.InnerText = Convert.ToString(atsAppConfig.FamilyId);
            root.AppendChild(familyID);

            XmlElement familyName = xml.CreateElement("FamilyName");
            familyName.InnerText = atsAppConfig.FamilyName;
            root.AppendChild(familyName);

            return xml.OuterXml;
        }
        public int UpdateCountry(AtsCountry atsCountry)
        {
            var prmOperation = new SqlParameter("@Operation", atsCountry.Operation);
            var prmId = new SqlParameter("@Id", atsCountry.Id);
            var prmCountryName = new SqlParameter("@Name", atsCountry.CountryName);
            var prmCode = new SqlParameter("@Code", atsCountry.Code);
            var prmRegionId = new SqlParameter("@RegionId", atsCountry.RegionId);
            var prmActive = new SqlParameter("@IsActive", atsCountry.Active);
            var prmModifiedBy = new SqlParameter("@ModifiedBy", atsCountry.ModifiedBy);
            var prmDefaultFulfillmentLocation = new SqlParameter("@DefaultFulfillmentLocationId", (atsCountry.site.Id == -1 ? null : atsCountry.site.Id));
            var allowFutureCommit = new SqlParameter("@AllowFutureCommit", atsCountry.AllowFutureCommit);

            int numOfRowsEffected = 0;
            using (var connection = _atsCommandDbFactory.Database.CreateConnection())
            {
                connection.Open();
                using (var dbCommand = connection.CreateCommand())
                {
                    dbCommand.CommandType = CommandType.StoredProcedure;
                    dbCommand.CommandText = "DPM_ATS_AddUpdateDeleteCountry";

                    dbCommand.Parameters.Add(prmOperation);
                    dbCommand.Parameters.Add(prmId);
                    dbCommand.Parameters.Add(prmCountryName);
                    dbCommand.Parameters.Add(prmCode);
                    dbCommand.Parameters.Add(prmRegionId);
                    dbCommand.Parameters.Add(prmModifiedBy);
                    dbCommand.Parameters.Add(prmActive);
                    dbCommand.Parameters.Add(prmDefaultFulfillmentLocation);
                    dbCommand.Parameters.Add(allowFutureCommit);

                    dbCommand.CommandTimeout = 180;

                    numOfRowsEffected = _atsCommandDbFactory.Database.ExecuteNonQuery(dbCommand);
                    if (numOfRowsEffected > 0)
                    {
                        this.DbCommandResult = new DbCommandResult();//TODO:::
                        this.DbCommandResult.RowsModifiedInDb = numOfRowsEffected;
                    }
                }
                connection.Close();
                return numOfRowsEffected;
            }
        }
        public int UpdateApplicationConfiguration(AtsApplicationConfiguration Item)
        {
            if (Item.CatalogId > -1 && Item.ProductLineId > 0)
                Item.ConfigValue = BuildRuleInfo(Item);
            var prmOperation = new SqlParameter("@Operation", Item.Operation);
            var prmAppId = new SqlParameter("@AppId", Item.ApplicationID);
            var prmUpdatedBy = new SqlParameter("@UpdatedBy", Item.UserName);
            var prmStatus = new SqlParameter("@Status", Item.IsActive);
            var prmConfigId = new SqlParameter("@ConfigId", Item.ConfigID);
            var prmConfigName = new SqlParameter("@ConfigName", Item.ConfigName);
            var prmConfigValue = new SqlParameter("@ConfigValue", Item.ConfigValue);
            var prmPreDefinitionCode = new SqlParameter("@CustomRule", Item.PreDefinitionCode);


            int numOfRowsEffected = 0;
            using (var connection = _atsCommandDbFactory.Database.CreateConnection())
            {
                connection.Open();
                using (var dbCommand = connection.CreateCommand())
                {
                    dbCommand.CommandType = CommandType.StoredProcedure;
                    dbCommand.CommandText = "DPM_ATS_AddUpdateApplicationConfiguration";

                    dbCommand.Parameters.Add(prmOperation);
                    dbCommand.Parameters.Add(prmAppId);
                    dbCommand.Parameters.Add(prmUpdatedBy);
                    dbCommand.Parameters.Add(prmStatus);
                    dbCommand.Parameters.Add(prmConfigId);
                    dbCommand.Parameters.Add(prmConfigName);
                    dbCommand.Parameters.Add(prmConfigValue);
                    dbCommand.Parameters.Add(prmPreDefinitionCode);

                    dbCommand.CommandTimeout = 180;

                    numOfRowsEffected = _atsCommandDbFactory.Database.ExecuteNonQuery(dbCommand);

                }
                connection.Close();
                return numOfRowsEffected;
            }
        }
        private string GetProductXML(AtsProductInfo product)
        {
            var headerNode = new XElement("Request");
            headerNode.Add(new XElement("SKU", product.SKU));
            headerNode.Add(new XElement("FGA", product.FGA));
            headerNode.Add(new XElement("Name", product.Name));
            headerNode.Add(new XElement("Description", product.Description));
            headerNode.Add(new XElement("ProductType", product.ProductType));
            headerNode.Add(new XElement("OfferType", product.Offer));
            headerNode.Add(new XElement("Messaging", product.SeperateMessaging ? 1 : 0));
            headerNode.Add(new XElement("Active", product.Active ? 1 : 0));

            PopulateCountriesNode(product, headerNode);
            PopulateCatalogsNode(product, headerNode);
            return headerNode.ToString();
        }
        private void PopulateCatalogsNode(AtsProductInfo product, XElement headerNode)
        {
            var catalogsNode = new XElement("Catalogs");

            foreach (AtsProductCatalog productCatalog in product.ProductCatalogs)
            {
                var catalogNode = new XElement("Catalog");
                catalogNode.Add(new XElement("CountryID", productCatalog.CountryID));
                catalogNode.Add(new XElement("CatalogID", productCatalog.CatalogID));
                catalogNode.Add(new XElement("SVVisibility", productCatalog.SalesViewVisibility ? 1 : 0));
                catalogNode.Add(new XElement("eQuote", productCatalog.eQuote));
                catalogNode.Add(new XElement("OrderQuote", productCatalog.OrderQuote));
                catalogsNode.Add(catalogNode);
            }

            headerNode.Add(catalogsNode);
        }
        private void PopulateCountriesNode(AtsProductInfo product, XElement headerNode)
        {
            var countryItemsNode = new XElement("Countries");
            foreach (AtsProductCountry productCountry in product.ProductCountries)
            {

                var paramCountryIds = productCountry.CountryIds.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                bool isCatalogGroup = paramCountryIds.Length > 1;
                var paramCatalogCountryBindingID = productCountry.CatalogCountryBindingID.Split(new string[] { "_" }, StringSplitOptions.RemoveEmptyEntries);

                int? catalogGroupId = (paramCatalogCountryBindingID[0].Trim() == "1") ? (int?)int.Parse(paramCatalogCountryBindingID[1].Trim()) : null;
                foreach (var CountryID in paramCountryIds)
                {
                    var countryItemNode = new XElement("Country");
                    countryItemNode.Add(new XElement("CountryID", int.Parse(CountryID)));
                    countryItemNode.Add(new XElement("SDSEnabled", (isCatalogGroup) ? 0 : productCountry.SDSEnabled ? 1 : 0));//TODO:::Confirm
                    countryItemNode.Add(new XElement("LeadTime", productCountry.LeadTime));
                    countryItemNode.Add(new XElement("ExtendedLeadTime", productCountry.ExtendedLeadTime));
                    countryItemNode.Add(new XElement("SalesChannel", productCountry.SalesChannel));
                    countryItemNode.Add(new XElement("LowInventory", productCountry.DisplayLowInventory ? 1 : 0));
                    countryItemNode.Add(new XElement("IncludePreCheckout", productCountry.IncludePreCheckout ? 1 : 0));
                    countryItemNode.Add(new XElement("IncludePostCheckout", productCountry.IncludePostCheckout ? 1 : 0));
                    countryItemNode.Add(new XElement("ContinueToSell", productCountry.ContinueToSell));
                    countryItemNode.Add(new XElement("Low", productCountry.Low));
                    countryItemNode.Add(new XElement("Buffer", productCountry.SDS));
                    countryItemNode.Add(new XElement("OverSell", productCountry.Oversell));
                    countryItemNode.Add(new XElement("OverSold", productCountry.Oversold));
                    countryItemNode.Add(new XElement("OverSoldOffline", productCountry.OversoldOffline));
                    countryItemNode.Add(new XElement("CatalogGroupId", catalogGroupId));
                    countryItemsNode.Add(countryItemNode);
                }
            }

            headerNode.Add(countryItemsNode);
        }
        public int UpdateContinueToSell(AtsItemDetail atsItemDetail)
        {
            int numOfRowsEffected = 0;
            using (var connection = _atsCommandDbFactory.Database.CreateConnection())
            {
                connection.Open();
                using (var dbCommand = connection.CreateCommand())
                {
                    dbCommand.CommandType = CommandType.StoredProcedure;
                    dbCommand.CommandText = "DPM_ATS_UpdateSellAction_CatalogGroupWrapper";

                    var isContinueToSell = new SqlParameter("@IsContinueToSell", atsItemDetail.ContinueToSell);
                    var productCountryId = new SqlParameter("@ProductCountryId", atsItemDetail.ProductCountryId);
                    var modifiedBy = new SqlParameter("@ModifiedBy", atsItemDetail.UpdatedBy);

                    dbCommand.Parameters.Add(isContinueToSell);
                    dbCommand.Parameters.Add(productCountryId);
                    dbCommand.Parameters.Add(modifiedBy);
                    numOfRowsEffected = _atsCommandDbFactory.Database.ExecuteNonQuery(dbCommand);
                }
                connection.Close();
                return numOfRowsEffected;
            }
        }
        public int UpdateDisplayLowInventory(AtsItemDetail atsItemDetail)
        {
            int numOfRowsEffected = 0;
            using (var connection = _atsCommandDbFactory.Database.CreateConnection())
            {
                connection.Open();
                using (var dbCommand = connection.CreateCommand())
                {
                    dbCommand.CommandType = CommandType.StoredProcedure;
                    dbCommand.CommandText = "DPM_ATS_UpdateDisplayLowInventory_CatalogGroupWrapper";

                    var productCountryId = new SqlParameter("@ProductCountryId", atsItemDetail.ProductCountryId);
                    var isContinueToSell = new SqlParameter("@DisplayLowInventory", atsItemDetail.DisplayLowInventry);
                    var modifiedBy = new SqlParameter("@ModifiedBy", atsItemDetail.UpdatedBy);

                    dbCommand.Parameters.Add(isContinueToSell);
                    dbCommand.Parameters.Add(productCountryId);
                    dbCommand.Parameters.Add(modifiedBy);
                    numOfRowsEffected = _atsCommandDbFactory.Database.ExecuteNonQuery(dbCommand);
                }
                connection.Close();
                return numOfRowsEffected;
            }
        }
        public int UpdateIsActive(AtsItemDetail atsItemDetail)
        {
            int numOfRowsEffected = 0;
            using (var connection = _atsCommandDbFactory.Database.CreateConnection())
            {
                connection.Open();
                using (var dbCommand = connection.CreateCommand())
                {
                    dbCommand.CommandType = CommandType.StoredProcedure;
                    dbCommand.CommandText = "DPM_ATS_UpdateProductStatus";

                    var productCountryId = new SqlParameter("@ProductCountryId", atsItemDetail.ProductCountryId);
                    var isContinueToSell = new SqlParameter("@IsActive", atsItemDetail.Active);
                    var modifiedBy = new SqlParameter("@ModifiedBy", atsItemDetail.UpdatedBy);

                    dbCommand.Parameters.Add(isContinueToSell);
                    dbCommand.Parameters.Add(productCountryId);
                    dbCommand.Parameters.Add(modifiedBy);
                    numOfRowsEffected = _atsCommandDbFactory.Database.ExecuteNonQuery(dbCommand);
                }
                connection.Close();
                return numOfRowsEffected;
            }
        }
        public int UpdateLeadTime(AtsItemDetail AtsDetail)
        {
            int numOfRowsEffected = 0;

            using (var connection = _atsCommandDbFactory.Database.CreateConnection())
            {
                connection.Open();
                using (var dbCommand = connection.CreateCommand())
                {
                    dbCommand.CommandType = CommandType.StoredProcedure;
                    dbCommand.CommandText = "DPM_ATS_UpdateLeadTime_CatalogGroupWrapper";

                    var productCountryId = new SqlParameter("@ProductCountryId", AtsDetail.ProductCountryId);
                    var sku = new SqlParameter("@SKU", AtsDetail.Sku);
                    var defaultLT = new SqlParameter("@DefaultLeadTime", AtsDetail.DefaultLT);
                    var extLeadTime = new SqlParameter("@ExtendedLeadTime", AtsDetail.ExtendedLeadTime);
                    var autoXltIncrement = new SqlParameter("@AutoXltIncrement", AtsDetail.AutoXltIncrement);

                    var updatedBy = new SqlParameter("@UpdatedBy", AtsDetail.UpdatedBy);
                    var updatingApp = new SqlParameter("@ModifyingApplication", "Lead Time Edit");


                    dbCommand.Parameters.Add(productCountryId);
                    dbCommand.Parameters.Add(sku);
                    dbCommand.Parameters.Add(extLeadTime);
                    dbCommand.Parameters.Add(defaultLT);
                    dbCommand.Parameters.Add(autoXltIncrement);
                    dbCommand.Parameters.Add(updatedBy);
                    dbCommand.Parameters.Add(updatingApp);

                    dbCommand.CommandTimeout = 180;
                    numOfRowsEffected = _atsCommandDbFactory.Database.ExecuteNonQuery(dbCommand);
                }
                connection.Close();
                return numOfRowsEffected;

            }

        }
        public int UpdateFulfillmentLocation(List<AtsSite> sites)
        {
            int numOfRowsEffected = 0;
            var fulfillmentLocationTable = ConvertToFulfillmentLocationTable(sites);
            var fulfillmentLocationTableParam = new SqlParameter("@ProductFulfillment", System.Data.SqlDbType.Structured)
            {
                Value = fulfillmentLocationTable,
                TypeName = "ProductFulfillmentLocationType"
            };
            var modifiedBy = new SqlParameter("@ModifiedBy", sites[0].UpdatedBy);
            using (var connection = _atsCommandDbFactory.Database.CreateConnection())
            {
                connection.Open();
                using (var dbCommand = connection.CreateCommand())
                {
                    dbCommand.CommandType = CommandType.StoredProcedure;
                    dbCommand.CommandText = "DPM_ATS_UpdateProductFulfillmentLocation";

                    dbCommand.Parameters.Add(fulfillmentLocationTableParam);
                    dbCommand.Parameters.Add(modifiedBy);
                    numOfRowsEffected = _atsCommandDbFactory.Database.ExecuteNonQuery(dbCommand);
                }
                connection.Close();
                return numOfRowsEffected;
            }
        }
        public int UpdateFulfillmentLocations(AtsSite sites)
        {
            int numOfRowsEffected = 0;
            var Operation = new SqlParameter("@Operation", sites.Operation);
            var Id = new SqlParameter("@FulfillmentLocationId", sites.Id);
            var Name = new SqlParameter("@Name", sites.SiteName);
            var Description = new SqlParameter("@Description", sites.Description);
            var FacilityCode = new SqlParameter("@FacilityCode", sites.SiteCode);
            var CountryId = new SqlParameter("@CountryId", sites.CountryId);
            var OldCountryId = new SqlParameter("@OldCountryId", sites.OldCountryId);
            var Type = new SqlParameter("@Type", sites.Type);
            var IsActive = new SqlParameter("@IsActive", sites.IsActive);
            var ModifiedBy = new SqlParameter("@ModifiedBy", sites.ModifiedBy);
            using (var connection = _atsCommandDbFactory.Database.CreateConnection())
            {
                connection.Open();
                using (var dbCommand = connection.CreateCommand())
                {
                    dbCommand.CommandType = CommandType.StoredProcedure;
                    dbCommand.CommandText = "CreateUpdateFulfillmentLocation";

                    dbCommand.Parameters.Add(Operation);
                    dbCommand.Parameters.Add(Id);
                    dbCommand.Parameters.Add(Name);
                    dbCommand.Parameters.Add(Description);
                    dbCommand.Parameters.Add(FacilityCode);
                    dbCommand.Parameters.Add(CountryId);
                    dbCommand.Parameters.Add(OldCountryId);
                    dbCommand.Parameters.Add(Type);
                    dbCommand.Parameters.Add(IsActive);
                    dbCommand.Parameters.Add(ModifiedBy);

                    numOfRowsEffected = _atsCommandDbFactory.Database.ExecuteNonQuery(dbCommand);

                }
                connection.Close();
                return numOfRowsEffected;
            }
        }
        private DataTable ConvertToFulfillmentLocationTable(List<AtsSite> sites)
        {
            DataTable locationTable = new DataTable("ProductFulfillmentLocations");
            locationTable.Columns.Add("ProductCountryId", typeof(int));
            locationTable.Columns.Add("FulfillmentLocationId", typeof(int));
            locationTable.Columns.Add("IsActive", typeof(bool));

            foreach (var site in sites)
            {
                DataRow row;
                row = locationTable.NewRow();
                row["ProductCountryId"] = site.ProductCountryId;
                row["FulfillmentLocationId"] = site.Id;
                row["IsActive"] = site.IsActive;

                locationTable.Rows.Add(row);
            }

            return locationTable;
        }
        public int UpdateThreshold(AtsItemDetail AtsDetail)
        {
            int numOfRowsEffected = 0;
            using (var connection = _atsCommandDbFactory.Database.CreateConnection())
            {
                connection.Open();
                using (var dbCommand = connection.CreateCommand())
                {
                    dbCommand.CommandType = CommandType.StoredProcedure;
                    dbCommand.CommandText = "DPM_ATS_UpdateThresholds_CatalogGroupWrapper";

                    var productCountryId = new SqlParameter("@ProductCountryId", AtsDetail.ProductCountryId);
                    var lowThreshold = new SqlParameter("@LowThreshold", AtsDetail.LowThreshold);
                    var sameDayShippingId = new SqlParameter("@SameDayShippingThreshold", AtsDetail.SameDayShippingThreshold);
                    var extLeadTimeThreshold = new SqlParameter("@ExtendedLeadTimeThreshold", AtsDetail.ExtendedLeadTimeThresold);
                    var outOfStockThreshold = new SqlParameter("@OutOfStockThreshold", AtsDetail.OutOfStockThresold);
                    var updatedBy = new SqlParameter("@ModifiedBy", AtsDetail.UpdatedBy);
                    var updatingApp = new SqlParameter("@ModifyingApplication", "Threshold Edit");

                    dbCommand.Parameters.Add(productCountryId);
                    dbCommand.Parameters.Add(lowThreshold);
                    dbCommand.Parameters.Add(sameDayShippingId);
                    dbCommand.Parameters.Add(extLeadTimeThreshold);
                    dbCommand.Parameters.Add(outOfStockThreshold);
                    dbCommand.Parameters.Add(updatedBy);
                    dbCommand.Parameters.Add(updatingApp);


                    dbCommand.CommandTimeout = 180;
                    numOfRowsEffected = _atsCommandDbFactory.Database.ExecuteNonQuery(dbCommand);
                }
                connection.Close();
                return numOfRowsEffected;
            }
        }
        public int CancelReservation(List<AtsCommitDetail> Items)
        {
            int numOfRowsEffected = 0;
            var cancelReservationTable = ConvertToFulfillmentLocationTable(Items);
            var cancelReservationTableParam = new SqlParameter("@Reservations", System.Data.SqlDbType.Structured)
            {
                Value = cancelReservationTable,
                TypeName = "RESERVATIONSTYPE"
            };
            var modifiedBy = new SqlParameter("@ModifiedBy", Items[0].UpdatedBy);
            using (var connection = _atsCommandDbFactory.Database.CreateConnection())
            {
                connection.Open();
                using (var dbCommand = connection.CreateCommand())
                {
                    dbCommand.CommandType = CommandType.StoredProcedure;
                    dbCommand.CommandText = "DPM_ATS_CancelReservations";

                    dbCommand.Parameters.Add(cancelReservationTableParam);
                    dbCommand.Parameters.Add(modifiedBy);
                    numOfRowsEffected = _atsCommandDbFactory.Database.ExecuteNonQuery(dbCommand);
                }
                connection.Close();

            }
            return numOfRowsEffected;
        }
        public int MarkAsFulfill(List<AtsCommitDetail> Items)
        {
            int numOfRowsEffected = 0;
            var cancelReservationTable = ConvertToFulfillmentLocationTable(Items);
            var cancelReservationTableParam = new SqlParameter("@Reservations", System.Data.SqlDbType.Structured)
            {
                Value = cancelReservationTable,
                TypeName = "RESERVATIONSTYPE"
            };
            var modifiedBy = new SqlParameter("@ModifiedBy", Items[0].UpdatedBy);
            using (var connection = _atsCommandDbFactory.Database.CreateConnection())
            {
                connection.Open();
                using (var dbCommand = connection.CreateCommand())
                {
                    dbCommand.CommandType = CommandType.StoredProcedure;
                    dbCommand.CommandText = "DPM_ATS_FulFilllReservations";

                    dbCommand.Parameters.Add(cancelReservationTableParam);
                    dbCommand.Parameters.Add(modifiedBy);
                    numOfRowsEffected = _atsCommandDbFactory.Database.ExecuteNonQuery(dbCommand);
                }
                connection.Close();
            }
            return numOfRowsEffected;

        }
        public DataTable ConvertToFulfillmentLocationTable(List<AtsCommitDetail> site)
        {
            DataTable reservationTable = new DataTable("ReservationsType");
            reservationTable.Columns.Add("ReservationId", typeof(string));
            DataRow row;
            foreach (var item in site)
            {
                row = reservationTable.NewRow();
                row["ReservationId"] = item.ReservationId;
                reservationTable.Rows.Add(row);
            }
            return reservationTable;
        }
    }
}
