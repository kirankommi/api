import { Injectable } from '@angular/core';
import {DataservicesProvider} from '@Dataservice/dataservices/dataservices';
import { environment } from '@Environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AgedReportService {

  //Variable Declarations
  queryApiBaseUrl: string;

  //Constructor
  constructor(private _dataservicesProvider: DataservicesProvider) {
    this.queryApiBaseUrl = environment.ApjEmeaAtsApiUrl;
  }

  //Country
  //getCountries() {
  //  return this._dataservicesProvider.getData(this.queryApiBaseUrl + 'getCountries');
  //}

  ////Site
  //getLocationCode() {
  //  return this._dataservicesProvider.getData(this.queryApiBaseUrl + 'getLocationCode');
  //} 

  ////Product Type
  //getProductTypes() {
  //  //TODO: filter items
  //  return this._dataservicesProvider.getData(this.queryApiBaseUrl + 'getProductTypes');
  //}

  agedReportSearch(agedReportRequest) {
    return this._dataservicesProvider.PostData(this.queryApiBaseUrl + 'getOrderDetails', agedReportRequest);
  }
}
