﻿using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    
    public class LeadTimeHistoryUnitTest : UnitTestInitializer
    {

        [Fact]
        public void GetLeadTimeHistoryDetailShouldReturnOKResult()
        {
            var productCountryId = 5988;
            var result = btsQueryController.GetLeadTimeHistory(productCountryId);
            Assert.NotNull(result);
        }
    }
}
