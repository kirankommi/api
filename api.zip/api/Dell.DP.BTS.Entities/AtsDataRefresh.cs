﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsDataRefresh
    {
        public string Item { get; set; }
        public DateTime? RefreshTime { get; set; }
    }
}
