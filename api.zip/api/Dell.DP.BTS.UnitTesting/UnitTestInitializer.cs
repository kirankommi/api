﻿using System;
using Xunit;
using System.Diagnostics.CodeAnalysis;
using Moq;
using System.Collections.Generic;
using Dell.DP.BTS.Entities;
using Dell.DP.BTS.API.Controllers;
using Dell.DP.BTS.BusinessServices.QueryBusiness.Interfaces;
using Dell.DP.BTS.BusinessServices.CommandBusiness.Interfaces;
using Dell.DP.BTS.BusinessServices.QueryBusiness.Interfaces;
using Dell.DP.BTS.BusinessServices.CommandBusiness.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace Dell.DP.BTS.UnitTesting
{
    
    public class UnitTestInitializer
    {
        protected BtsQueryController btsQueryController;
        protected Mock<IBtsQueryBusiness> MockBTSQueryBusiness;
        protected List<AtsLeadTimeHistory> atsLeadTimeHistory;
        protected List<AtsItemSiteInventory> atsItemSiteInventory;
        protected List<AtsItemDetail> atsItemDetail;
        protected List<AtsItem> atsItem;
        protected List<InTransit> inTransit;
        protected AtsAppConfigList atsAppConfigList;
        protected List<AtsItemDetail> atsItemDetaillist;
        protected List<AtsStatusHistory> atsStatusHistory;
        protected List<InTransit> inTransitList;
        protected AtsProductConfiguration productConfiguration;
        protected List<AtsDaysofSupply> atsDaysofSupply;
        protected List<AtsDataRefresh> atsDataRefresh;

        protected List<AtsApplicationConfiguration> atsApplicationConfigurationList;
        protected AtsApplicationConfiguration atsApplicationConfigurations;
        protected AtsFgaItemLists atsFgaItemLists;
        protected AtsCountry atsCountrys;
        protected AtsSite atsSites;
        protected List<AtsCountry> atsCountry;
        protected List<AtsCatalog> atsCatalog;
        protected AtsProductInfo atsProductInfo;
        protected OrderDetailsSearchResultList orderDetailsSearchResultList;
        protected List<OrderDetailsSearchResponse> orderDetailsSearchResultLists;
        protected CommitCalloutDetail commitCalloutDetail;
        protected CommitCalloutDetailResponse commitCalloutDetailResponse;
        protected List<CommitCalloutDetail> commitCalloutDetailResultLists;
        protected OrderDetailsSearchResponse orderDetailsSearchResponse;
        protected List<AtsCommitDetail> atsCommitDetail;
        protected List<AtsJobDetails> atsJobDetails;
        protected List<AtsSite> atsSite;
        protected List<AtsJobTransactionStatus> atsJobTransactionStatus;
        protected BtsCommandController btsCommandController;
        protected Mock<IBtsCommandBusiness> MockBTSCommandBusiness;

        [ExcludeFromCodeCoverage]
        public UnitTestInitializer()
        {
            MockBTSQueryBusiness = new Mock<IBtsQueryBusiness>();
            MockBTSCommandBusiness = new Mock<IBtsCommandBusiness>();
            btsQueryController = new BtsQueryController(MockBTSQueryBusiness.Object);
            btsCommandController = new BtsCommandController(MockBTSCommandBusiness.Object);
            StubData();
        }

        void StubData()
        {
            atsJobTransactionStatus = new List<AtsJobTransactionStatus>();
            atsJobTransactionStatus.Add(new AtsJobTransactionStatus()
            {
                LastUpdatedAt = "10/16/2018 04:33:40 PM ",
                LastUpdatedBy = "ASIA-PACIFIC\\Dhamodharan_Chakrava",
                Name = "Reservation Service",
                ReservationStatus = ""
            });
            atsSite = new List<AtsSite>();
            atsSite.Add(new AtsSite()
            {
                CreatedBy = "ASIA-PACIFIC\\Dhamodharan_Chakrava",
                CreatedOn = DateTime.Now,
                Id = 1,
                IsActive = true,
                ProductCountryId = 1588,
                SiteCode = "COV",
                SiteName = "COV",
                UpdatedBy = "ASIA-PACIFIC\\Dhamodharan_Chakrava",
                UpdatedOn = DateTime.Now
            });
            atsJobDetails = new List<AtsJobDetails>();
                atsJobDetails.Add(new AtsJobDetails() {
                    Action = 1,
                    Description = "No description available. ",
                    ExecutionStatus = "Succeeded   ",
                    LastRunTime = "10/17/2018 06:15:00 AM",
                    ManualOverride = "Nov 14 2017 3:11AM / Run / Atul_K_Arora ",
                    Name = "ATS_BTS_DSI_JOB ",
                    NextRunTime = "10/17/2018 12:15:00 PM ",
                    Schedule = "6 Hours",
                    Source = "",
                    Status = ""
                });
            atsCommitDetail = new List<AtsCommitDetail>();
            atsCommitDetail.Add(new AtsCommitDetail() {
                BillingCompanyName = "LOIC GAUDISSARD",
                CommitedOn = DateTime.Now,
                CreatedBy = "ASIA-PACIFIC\\Dhamodharan_Chakrava",
                CustomerName = "LOIC GAUDISSARD",
                FacilityCode = string.Empty,
                CreatedOn = DateTime.Now,
                FulfillmentLocation = "COV",
                FuturisticDeliveryDate = DateTime.Now,
                IRN = "FR2006-9292-71885",
                MustArriveByDate = DateTime.Now,
                Name = "FRANCE",
                OrderNumber = "33027964",
                OverrideTPB = false,
                Quantity = 15,
                ReleaseDate = DateTime.Now,
                ReservationId = string.Empty,
                ReservedOn = DateTime.Now,
                Segment = string.Empty,
                ShipToContactName = "LOIC GAUDISSARD",
                TieNumber = "1",
                UpdatedBy = "ASIA-PACIFIC\\Dhamodharan_Chakrava",
                UpdatedOn = DateTime.Now
            });
            orderDetailsSearchResultList = new OrderDetailsSearchResultList();
            orderDetailsSearchResultList.OrderDetailsList = new List<OrderDetailsSearchResponse>();
            orderDetailsSearchResponse = new OrderDetailsSearchResponse()
            {
                Country = "Netherlands",
                FGA = "FW2MM",
                OrderNumber = 105005769,
                OrderQuantity = 34,
                ProductType = "FGA-BTS",
                ProductTypeId = 2,
                SiteCode = "-",
                SiteId = 0,
                SiteName = "-",
                SKU = "998-BZKG",
                StatusAge = 524
            };
            orderDetailsSearchResultList.OrderDetailsList.Add(orderDetailsSearchResponse);

            orderDetailsSearchResultLists = new List<OrderDetailsSearchResponse>();
            orderDetailsSearchResultLists.Add(orderDetailsSearchResponse);


            commitCalloutDetailResponse = new CommitCalloutDetailResponse();
            commitCalloutDetailResponse.CommitCalloutDetails = new List<CommitCalloutDetail>();
            commitCalloutDetail = new CommitCalloutDetail()
            {
                CountryCode = "BR",
                Quantity = "5",
                TieNumber = "1",
                UpdatedDateTime = DateTime.UtcNow,
                FGA = "FW2MM",
                ProductType = "FGA-BTS",
                SKU = "998-BZKG",
            };
            orderDetailsSearchResultList.OrderDetailsList.Add(orderDetailsSearchResponse);

            commitCalloutDetailResultLists = new List<CommitCalloutDetail>();
            commitCalloutDetailResultLists.Add(commitCalloutDetail);

            atsProductInfo = new AtsProductInfo();
            atsProductInfo.Active = false;
            atsProductInfo.Description = "SKU DESC 1";
            atsProductInfo.FGA = "PART N";
            atsProductInfo.ID = 6;
            atsProductInfo.Name = "Brand NM";
            atsProductInfo.Offer = "OFFR";
            atsProductInfo.SKU = "210-0008";
            atsProductInfo.ProductType = 2;
            atsProductInfo.ProductTypeName = "FGA-BTS";
            atsProductInfo.SeperateMessaging = true;
            atsProductInfo.ProductCountries = new List<AtsProductCountry>();
            atsProductInfo.ProductCountries.Add(new AtsProductCountry(){
                CatalogCountryBindingID = "0_30",
                CatalogGroupId = null,
                ContinueToSell = true,
                CountryID = 30,
                CountryIds = "30",
                CountryName = "FRANCE",
                DisplayLowInventory = false,
                ExtendedLeadTime = 1,
                IncludePostCheckout = true,
                IncludePreCheckout = true,
                LeadTime = 1,
                Low = 30,
                Oversell = 10,
                Oversold = 5,
                OversoldOffline = 5,
                SalesChannel = 0,
                SDS = 0,
                SDSEnabled = false,
                SellActionOffline = string.Empty
            });
            atsProductInfo.ProductCatalogs = new List<AtsProductCatalog>();
            atsProductInfo.ProductCatalogs.Add(new AtsProductCatalog()
            {
                 CountryID = 11,
                 CatalogID = 14,
                 SalesViewVisibility = true,
                 eQuote = string.Empty,
                 OrderQuote = string.Empty
            });

            atsFgaItemLists = new AtsFgaItemLists();
            atsFgaItemLists.AtsFGAItems = new List<AtsItem>();
            atsFgaItemLists.AtsFGAItems.Add(new AtsItem()
            {
                Id = 1,
                Sku = "225-0716",
                Part = "VWN7F",
                Brand = "Inspiron 570, MT Black Bezel FTS3A",
                Type = "NON FGA",
                Description = "Inspiron...",
                OfferType = "NA",
                CatalogGroup = "US CNS",
                ATS = 0,
                OnHand = 0,
                Commit = 0,
                Checkout = 0,
                Cart = 0,
                Status = "Low",
                Threshold = "100",
                LeadTime = 1,
                LTSource = "Standard",
                DefaultLT = 1,
                ContinueToSell = true,
                Active = false,
                ProductCountryId = 1
            });
            atsFgaItemLists.RecordCount = 1;
            atsApplicationConfigurations = new AtsApplicationConfiguration()
            {
                ConfigID = 431,
                ConfigName = "StandardLeadTime",
                ConfigValue = "2",
                ApplicationID = 1,
                ApplicationName = "GLOBAL"
            };
            atsApplicationConfigurationList = new List<AtsApplicationConfiguration>();
            atsApplicationConfigurationList.Add(new AtsApplicationConfiguration()
            {
                ConfigID = 431,
                ConfigName = "StandardLeadTime",
                ConfigValue = "2",
                ApplicationID = 1,
                ApplicationName = "GLOBAL"
            });
            productConfiguration = new AtsProductConfiguration()
            {
                RoutingThreshold = 45,
                LowThreshold = 5,
                OversellThreshold = 3,
                OversoldThreshold = 2,
                BufferThreshold = 4,
                DisplayLowInventory = true,
                IncludePreCheckout = true,
                IncludeCheckout = false,
                SellAction = false,
                FGASCDHOverride = true,
                SnPSCDHOverride = true
            };

            InTransitLists inTransitLists = new InTransitLists();
            inTransitLists.AtsInTransit = new List<InTransit>();
            inTransitLists.AtsInTransit.Add(new InTransit()
            {
                SKU = "210-AAIT",
                PART = "XKK62",
                QUANTITY = 144,
                ASSIN = "GNBNA2C7BD",
                SHIPFROMFACILITY = "In-Transit",
                MERGECENTER = "NASHVILLE",
                ESTIMATEDARRIVAL = "2017-05-20 00:00:00.000",
                TRANSPORTMODE = "OT",
                INVENTORYOWNER = "Dell"

            });
            
            atsStatusHistory = new List<AtsStatusHistory>();
            atsStatusHistory.Add(new AtsStatusHistory()
            {
                CreatedBy = "ASIA-PACIFIC\\Dhamodharan_Chakrava",
                FromStatus = "OK",
                ToState = "Low",
                HistoryId = 1
            });
            atsDaysofSupply = new List<AtsDaysofSupply>();
            atsDaysofSupply.Add(new AtsDaysofSupply()
            {
                DSI = 1,
                Sales = 100,
                TimeFrame = "1 days"
            });
            atsLeadTimeHistory = new List<AtsLeadTimeHistory>();
            atsLeadTimeHistory.Add(new AtsLeadTimeHistory()
            {
                ChangedOn = DateTime.Now,
                FromLeadTime = 1,
                ToLeadTime = 2,
                Id = 1,
                UpdatedBy = "ASIA-PACIFIC\\Dhamodharan_Chakrava"
            });
            atsItemSiteInventory = new List<AtsItemSiteInventory>();
            atsItemSiteInventory.Add(new AtsItemSiteInventory()
            {
                OnHand = 0,
                Commit = 0,
                FutureCommit = 0,
                RoutingThresold = 0,
                Shipped = 0,
                AvailableToSell = 0,
                FulfillmentLocationName = "NAS",
                FulfillmentLocationId = 57,
                FacilityCode = "3NV"
            });
            atsDataRefresh = new List<AtsDataRefresh>();
            atsDataRefresh.Add(new AtsDataRefresh() { Item = "Commit", RefreshTime = DateTime.Now });
            atsDataRefresh.Add(new AtsDataRefresh() { Item = "In-transit", RefreshTime = DateTime.Now });
            atsDataRefresh.Add(new AtsDataRefresh() { Item = "OnHand", RefreshTime = DateTime.Now });
            atsItemDetail = new List<AtsItemDetail>();
            atsItemDetail.Add(new AtsItemDetail()
            {
                LeadTime = 1,
                DefaultLT = 1,
                ExtendedLeadTime = 1,
                LTSource = "Extended",
                AllowAutoXLT = false,
                LowThreshold = 10,
                SameDayShippingThreshold = 9,
                ExtendedLeadTimeThresold = 8,
                OutOfStockThresold = 7,
                ContinueToSell = false,
                DisplayLowInventry = true,
                IsEligibleForSmartLogo = false,
                ItemInventryStatus = "OutOfStock:StopSelling",
                IsFirstTrackEligible = false,
                ATS = 0,
                IsSDSEnabledCountry = false,
                AutoXltIncrement = 1,
                Active = true,
                ProductCountryId = 1588
            });
            atsCountrys = new AtsCountry()
            {
                Active = false,
                AllowFutureCommit = false,
                CatalogCountryBindingID = null,
                Code = "UK",
                CountryIds = null,
                CountryName = "UNITED KINGDOM",
                Id = 11,
                IsCatalogGroup = null,
                ModifiedBy = null,
                Operation = null,
                RegionId = 3,
                Sequence = 0
            };

            atsSites = new AtsSite()
            {
                CountryId = 11,
                CreatedBy = "ASIA-PACIFIC\\Dhamodharan_Chakrava",
                CreatedOn = DateTime.UtcNow,
                Description = "Coventry UK STK - propose delete",
                IsActive = true,
                OldCountryId = 11,
                SiteCode = "STKCOV",
                SiteName = "COVENTRY",
                Type = "FC",
                UpdatedBy = "ASIA-PACIFIC\\Dhamodharan_Chakrava",
                UpdatedOn = DateTime.UtcNow
            };

            atsSite = new List<AtsSite>();
            atsSite.Add(new AtsSite()
            {
                CountryId = 11,
                CreatedBy = "ASIA-PACIFIC\\Dhamodharan_Chakrava",
                CreatedOn = DateTime.UtcNow,
                Description = "Coventry UK STK - propose delete",
                IsActive = true,
                OldCountryId = 11,
                SiteCode = "STKCOV",
                SiteName = "COVENTRY",
                Type = "FC",
                UpdatedBy = "ASIA-PACIFIC\\Dhamodharan_Chakrava",
                UpdatedOn = DateTime.UtcNow
            });

            atsCountry = new List<AtsCountry>();
            atsCountry.Add(new AtsCountry()
            {
                Active = false,
                AllowFutureCommit = true,
                CatalogCountryBindingID = null,
                Code = "GLOBAL",
                CountryIds = null,
                CountryName = "ALL COUNTRIES",
                Id = 6,
                IsCatalogGroup = null,
                ModifiedBy = null,
                Operation = null,
                RegionId = 1,
                Sequence = 0
            });
            atsCountry.Add(new AtsCountry()
            {
                Active = false,
                AllowFutureCommit = false,
                CatalogCountryBindingID = null,
                Code = "UK",
                CountryIds = null,
                CountryName = "UNITED KINGDOM",
                Id = 11,
                IsCatalogGroup = null,
                ModifiedBy = null,
                Operation = null,
                RegionId = 3,
                Sequence = 0
            });
            atsCatalog = new List<AtsCatalog>();
            atsCatalog.Add(new AtsCatalog()
            {
                CatalogGroup = null,
                CatalogGroupId = 0,
                CatalogId = 202,
                CountryCodes = null,
                CountryId = 11,
                CountryIds = null,
                CountryIdsCsv = null,
                CountryName = "UNITED KINGDOM",
                Id = 13,
                RegionCode = "UK SMB",
                RegionId = 0,
                UserID = null
            });
            atsAppConfigList = new AtsAppConfigList();
            atsAppConfigList.AtsApplicationConfigurationList = new List<AtsApplicationConfiguration>();
            atsAppConfigList.AtsApplicationConfigurationList.Add(new AtsApplicationConfiguration()
            {
                ConfigID = 431,
                ConfigName = "StandardLeadTime",
                ConfigValue = "2",
                ApplicationID = 1,
                ApplicationName = "GLOBAL"
            });

            atsAppConfigList.AtsApplicationConfigurationList.Add(new AtsApplicationConfiguration()
            {
                ConfigID = 431,
                ConfigName = "StandardLeadTime",
                ConfigValue = "2",
                ApplicationID = 1,
                ApplicationName = "GLOBAL"
            });
            atsItem = new List<AtsItem>();
            atsItem.Add(new AtsItem()
            {
                LeadTime = 1,
                DefaultLT = 1,
                ExtendedLeadTime = 1,
                LTSource = "Extended",
                ContinueToSell = false,
                ATS = 0,
                IsSDSEnabledCountry = false,
                Active = true,
                ProductCountryId = 1588
            });

            MockBTSQueryBusiness.Setup(x => x.GetProductFulfillmentLocation(It.IsAny<int>(), It.IsAny<int>())).ReturnsAsync(atsSite);
            MockBTSQueryBusiness.Setup(x => x.GetJobDetails(It.IsAny<int>())).ReturnsAsync(atsJobDetails);
            MockBTSQueryBusiness.Setup(x => x.GetTransactionDetails(It.IsAny<int>())).ReturnsAsync(atsJobTransactionStatus);
            MockBTSQueryBusiness.Setup(x => x.GetCommitDetail(It.IsAny<int>())).ReturnsAsync(atsCommitDetail);
            MockBTSQueryBusiness.Setup(x => x.GetOrderDetails(It.IsAny<OrderDetailsSearchRequest>())).ReturnsAsync(orderDetailsSearchResultList);
            MockBTSQueryBusiness.Setup(x => x.GetOrderExportDetails(It.IsAny<OrderDetailsSearchRequest>())).ReturnsAsync(orderDetailsSearchResultLists);
            MockBTSQueryBusiness.Setup(x => x.GetProductInformation(It.IsAny<int>(), It.IsAny<int>())).ReturnsAsync(atsProductInfo);
            MockBTSQueryBusiness.Setup(x => x.GetAtsItemDetail(It.IsAny<int>())).ReturnsAsync(atsItemDetail);
            MockBTSQueryBusiness.Setup(x => x.GetAtsItemRefreshDetail(It.IsAny<int>())).ReturnsAsync(atsDataRefresh);
            MockBTSQueryBusiness.Setup(x => x.GetLeadTimeHistory(It.IsAny<int>())).ReturnsAsync(atsLeadTimeHistory);
            MockBTSQueryBusiness.Setup(x => x.GetInventoryStatus(It.IsAny<int>())).ReturnsAsync(atsItemSiteInventory);
            MockBTSQueryBusiness.Setup(x => x.GetDaysofSupply(It.IsAny<int>())).ReturnsAsync(atsDaysofSupply);
            MockBTSQueryBusiness.Setup(x => x.GetAtsStatusHistory(It.IsAny<int>())).ReturnsAsync(atsStatusHistory);
            MockBTSQueryBusiness.Setup(x => x.GetProductConfiguration()).ReturnsAsync(productConfiguration);
            MockBTSQueryBusiness.Setup(x => x.GetInTransit(It.IsAny<AtsInTransitSearchRequest>())).ReturnsAsync(inTransitLists);
            MockBTSQueryBusiness.Setup(x => x.GetFGAItemDetails(It.IsAny<AtsItemSearchRequest>())).ReturnsAsync(atsFgaItemLists);
            MockBTSQueryBusiness.Setup(x => x.GetInTransitExport(It.IsAny<AtsInTransitSearchRequest>())).ReturnsAsync(inTransitList);
            MockBTSQueryBusiness.Setup(x => x.GetCountries(It.IsAny<int>())).ReturnsAsync(atsCountry);
            MockBTSQueryBusiness.Setup(x => x.GetFulfillmentLocation(It.IsAny<int>())).ReturnsAsync(atsSite);
            MockBTSQueryBusiness.Setup(x => x.GetCatalog(It.IsAny<AtsCatalog>())).ReturnsAsync(atsCatalog);
            MockBTSQueryBusiness.Setup(x => x.GetApplicationConfigurations(It.IsAny<AtsAppConfigRequest>())).ReturnsAsync(atsAppConfigList);
            MockBTSQueryBusiness.Setup(x => x.GetApplicationRuleConfigurations(It.IsAny<AtsAppConfigRequest>())).ReturnsAsync(atsAppConfigList);
            MockBTSQueryBusiness.Setup(x => x.GetCommitCalloutDetails(It.IsAny<CommitFalloutRequest>())).ReturnsAsync(commitCalloutDetailResponse);
            MockBTSQueryBusiness.Setup(x => x.GetCommitCalloutExportDetails(It.IsAny<CommitFalloutRequest>())).ReturnsAsync(commitCalloutDetailResultLists);
            MockBTSQueryBusiness.Setup(x => x.GetFGAItemExportDetails(It.IsAny<AtsItemSearchRequest>())).ReturnsAsync(atsItem);
            MockBTSCommandBusiness.Setup(x => x.UpdateLeadTime(It.IsAny<AtsItemDetail>()));
            MockBTSCommandBusiness.Setup(x => x.UpdateContinueToSell(It.IsAny<AtsItemDetail>()));
            MockBTSCommandBusiness.Setup(x => x.UpdateDisplayLowInventory(It.IsAny<AtsItemDetail>()));
            MockBTSCommandBusiness.Setup(x => x.UpdateIsActive(It.IsAny<AtsItemDetail>()));
            MockBTSCommandBusiness.Setup(x => x.UpdateCatalog(It.IsAny<AtsCatalog>()));
            MockBTSCommandBusiness.Setup(x => x.UpdateThreshold(It.IsAny<AtsItemDetail>()));
            MockBTSCommandBusiness.Setup(x => x.UpdateApplicationConfiguration(It.IsAny<AtsApplicationConfiguration>()));
            MockBTSCommandBusiness.Setup(x => x.UpdateCountry(It.IsAny<AtsCountry>()));
            MockBTSCommandBusiness.Setup(x => x.UpdateFulfillmentLocations(It.IsAny<AtsSite>()));

        }

        protected bool isGreaterThanOrEqualtoZero(int Count)
        {
            return Count >= 0;
        }

        public void Asserts(IActionResult result)
        {
            Assert.NotNull(result);
        }

    }
}
