﻿using Dell.DP.BTS.Entities;
using Dell.DP.BTS.API.Controllers;
using Dell.DP.BTS.DataServices;
using Dell.DP.BTS.BusinessServices;
using Xunit;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.AspNetCore.Mvc;

namespace Dell.DP.BTS.UnitTesting
{
    
    public class CatalogUnitTest : UnitTestInitializer
    {

        [Fact]
        public void GetCatalogsDataShouldReturnOKResult()
        {
            AtsCatalog items = new AtsCatalog()
            {
                CountryName= null, RegionCode= null, CatalogId= null, RegionId= 3, CatalogGroup = string.Empty, CatalogGroupId = 0, CountryCodes = string.Empty, CountryId = 0, CountryIds = new int[0], CountryIdsCsv = string.Empty, Id = 0, UserID = string.Empty
            };
            var result = btsQueryController.GetCatalog(items);
            Asserts(result);
        }

        [Fact]
        public void GetCatalogsByRegionCodeDataShouldReturnOKResult()
        {
            AtsCatalog items = new AtsCatalog()
            {
                CountryName = null,
                RegionCode = "UK SMB",
                CatalogId = null,
                RegionId = 3,
                CatalogGroup = string.Empty,
                CatalogGroupId = 0,
                CountryCodes = string.Empty,
                CountryId = 0,
                CountryIds = new int[0],
                CountryIdsCsv = string.Empty,
                Id = 0,
                UserID = string.Empty
            };
            var result = btsQueryController.GetCatalog(items);
            Asserts(result);
        }

        [Fact]
        public void GetCatalogsByCountryNameDataShouldReturnOKResult()
        {
            AtsCatalog items = new AtsCatalog()
            {
                CountryName = "UNITED KINGDOM",
                RegionCode = null,
                CatalogId = null,
                RegionId = 3,
                CatalogGroup = string.Empty,
                CatalogGroupId = 0,
                CountryCodes = string.Empty,
                CountryId = 0,
                CountryIds = new int[0],
                CountryIdsCsv = string.Empty,
                Id = 0,
                UserID = string.Empty
            };
            var result = btsQueryController.GetCatalog(items);
            Asserts(result);
        }
        public void Asserts(Task<IActionResult> result)
        {
            Assert.NotNull(result);
        }
    }
}
