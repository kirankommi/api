﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class IsgLeadTimeAdderRules
    {
        public int RuleId { get; set; }
        public string RuleName { get; set; }
        public int LeadTimeAdder { get; set; }
        public int Weightage { get; set; }
        public string Conditions { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedOn { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedOn { get; set; }

    }
    [ExcludeFromCodeCoverage]
    public class IsgLeadTimeAdderRuleDetails
    {
        public int ParameterId { get; set; }
        public string Operator { get; set; }
        public string ParameterValue { get; set; }
        public string ParameterName { get; set; }

    }
    [ExcludeFromCodeCoverage]
    public class IsgLeadTimeAdderRuleSearch
    {
        public IList<IsgLeadTimeAdderRules> IsgLeadTimeAdderRulesList { get; set; }
        public IList<IsgLeadTimeAdderRuleDetails> IsgLeadTimeAdderRuleDetailsList { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class IsgLeadTimeAdderRulesFiltter
    {
        public int RuleId { get; set; }
        public string Conditions { get; set; }
        public int ParameterId { get; set; }

    }
}
