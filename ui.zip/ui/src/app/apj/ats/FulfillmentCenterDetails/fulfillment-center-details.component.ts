import { Component, OnInit, Input } from '@angular/core';
import { ApjAtsFacadeService } from '@App/shared/apj-ats-facade.service';
import { MatDialog, MatSlideToggleChange, MatTableDataSource, MatCheckbox } from '@angular/material';
import { NotifierService } from 'angular-notifier';
import { LocalStorageService } from 'angular-2-local-storage';
import { FulfillmentCenterData } from './fulfillment-center-details.model';
//import { SelectionModel } from '@angular/cdk/collections';
//export interface PeriodicElement {
//  siteCode: string;
//  isActive: string;
//}

@Component({
  selector: 'app-fulfillment-center-details',
  templateUrl: './fulfillment-center-details.component.html',
  styleUrls: ['./fulfillment-center-details.component.css']
})
export class FulfillmentCenterDetailsComponent implements OnInit {

  ProductCountryId: any;

  //dataSource: MatTableDataSource<FulfillmentCenterData>;

  private notifier: NotifierService;

  indLoading: boolean = false; isAnyCheckboxClicked: boolean = true;

  ProductFulfillmentCenter: any; ErrorMsg: any; SuccessMsg: any; RegionId: string;

  masterSelected: boolean = false;
  checklist: any;
  checkedList: any;

  constructor(private _ApjAtsFacadeService: ApjAtsFacadeService, public dialog: MatDialog, private _localStorageService: LocalStorageService, notifier: NotifierService) {
    this.notifier = notifier;
  }/*, notifier: NotifierService*/
  //displayedColumns = ['isActive', 'siteCode'];
  //selection = new SelectionModel<FulfillmentCenterData>(true, []);

  ngOnInit() {
    this.RegionId = this._localStorageService.get('selRegion');
    this.ProductCountryId = this._localStorageService.get('productCountryId');
    this.getProductFulfillment(this.ProductCountryId, this.RegionId);

  }
  getProductFulfillment(ProductCountryId, RegionId): void {
    this.indLoading = true;
    this._ApjAtsFacadeService.getProductFulfillment(ProductCountryId, RegionId)
      .subscribe(ProductFulfillmentCenters => {
        this.ProductFulfillmentCenter = ProductFulfillmentCenters;
        this.isAllSelected();
        //this.selection.clear();
        //this.dataSource = new MatTableDataSource<FulfillmentCenterData>(this.ProductFulfillmentCenter);
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }

  ///** Whether the number of selected elements matches the total number of rows. */
  //isAllSelected() {
  //  const numSelected = this.selection.selected.length;
  ////  console.log(JSON.stringify(this.dataSource));
  //  const numRows = this.dataSource.data.length;
  //  return numSelected === numRows;
  //}

  ///** Selects all rows if they are not all selected; otherwise clear selection. */
  //masterToggle() {
  //  this.isAllSelected() ?
  //    this.selection.clear() :
  //    this.dataSource.data.forEach(row => this.selection.select(row));
  //}

  ///** The label for the checkbox on the passed row */
  //checkboxLabel(row?: FulfillmentCenterData): void {
  //  //if (!row) {
  //  //  return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
  //  //}
  //  //return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.siteCode + 1}`;
  //}
  fulfillmentCenterSave() {
    this.indLoading = true;
    var request = [];
    for (var i = 0; i < this.ProductFulfillmentCenter.length; i++) {
        var r = {
          "ProductCountryId": this.ProductCountryId,
          "Id": this.ProductFulfillmentCenter[i].id,
          "IsActive": this.ProductFulfillmentCenter[i].isActive,
          "UpdatedBy": this._localStorageService.get('UserName')
        }
        request.push(r);
    }
      this._ApjAtsFacadeService.updateFulfillmentLocation(request)
        .subscribe(atsDetails => {
          this.notifier.notify('success', 'Fulfillment center selection updated');
          this.indLoading = false;
        },
          error => { this.ErrorMsg = <any>error; this.indLoading = false; });

  }


  checkUncheckAll() {
    for (var i = 0; i < this.ProductFulfillmentCenter.length; i++) {
      this.ProductFulfillmentCenter[i].isActive = this.masterSelected;
    }
    this.getCheckedItemList();
  }
  isAllSelected() {
    this.masterSelected = this.ProductFulfillmentCenter.every(function (item: any) {
      return item.isActive == true;
    })
    this.getCheckedItemList();
  }

  getCheckedItemList() {
    this.checkedList = [];
    for (var i = 0; i < this.ProductFulfillmentCenter.length; i++) {
      if (this.ProductFulfillmentCenter[i].isActive)
        this.checkedList.push(this.ProductFulfillmentCenter[i]);
    }

  }
}
