import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
// Must import to use Forms functionality  
import { FormBuilder, FormGroup, Validators, FormsModule, NgForm } from '@angular/forms';
import { DataservicesProvider } from '@Dataservice/dataservices/dataservices';
import{ApjAtsFacadeService} from '@App/shared/apj-ats-facade.service';
import { Global } from '@App/shared/global';
import {ExcelService} from '@App/shared/exportservice';
import { MatPaginator, MatSort, MatTableDataSource, MatTooltip } from '@angular/material';
import { LocalStorageService } from 'angular-2-local-storage';
import { CommitItemDetail } from '../commit-details/commit-details.model';

import { AtsItemSearchRequest, UserData, itemdetail, productManagementReff, FGADetailsList, datalist } from './dashboard.model';

@Component({
  selector: 'app-apj-ats-dashboard',
  templateUrl: './apj-ats-dashboard.component.html',
  styleUrls: ['./apj-ats-dashboard.component.css'],
  providers: [DataservicesProvider]
})
export class ApjAtsDashboardComponent implements OnInit {
  @ViewChild('ItemDetails') public panel: ElementRef;
  @ViewChild('dashboard') public dashboard: ElementRef;
  @ViewChild('CommitItemDetails') public commitDetails: ElementRef;
  @ViewChild('ProductManagement') public panelProductManagement: ElementRef;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  displayedColumns = ['sku', 'part', 'brand', 'description','type','offerType','catalogGroup','ats','onHand','commit','checkout',
  'cart','status','threshold','leadTime','ltSource','defaultLT','continueToSell','active'];
  dataSource: MatTableDataSource<UserData>;

  RegionId: number;

  pageIndex: number = 1;
  pageSize: number = 10;
  pageSizeOptions: number[] = [10,20, 30, 50, 100];
  length:any;totalPageSize:any;

  IsCommitDetails: boolean = false; IsFilter: boolean;
  indLoading: boolean = false; IsItemDetails: boolean = false; IsProductManagement: boolean = false;
  StockStatus: any; Countries: any; CatalogGroups: any; LocationCodes: any;
  getFGADetails: any; getFGADetailsExport: datalist;
  exportData: FGADetailsList[];
  parseData = [];

  ErrorMsg: any; SuccessMsg: any;
  private atsItemSearchRequest: AtsItemSearchRequest = new AtsItemSearchRequest();

  public itemdetail: itemdetail = new itemdetail();
  public _commitItemDetail: CommitItemDetail = new CommitItemDetail();
  public productManagementReff: productManagementReff = new productManagementReff();

  apjAtsDashboardForm: FormGroup;
  ddlActiveInactive: string = '';
  ddlType: string = '-1';
  ddlStatus: string = '';
  ddlContinueToSell: string = '';
  txtSKU: string = null;
  ddlCatalog: string = '';
  ddlFulfillmentCenter: string = '';
  ddlCountry: string = '-1';
  txtPart: string = null;

  constructor(private fb: FormBuilder, private _DataservicesProvider: DataservicesProvider,
    private excelService: ExcelService, private _ApjAtsFacadeService: ApjAtsFacadeService, private _localStorageService: LocalStorageService) {
    this.RegionId = this._localStorageService.get('selRegion');

    // To initialize FormGroup , Validators.required 
    this.apjAtsDashboardForm = fb.group({
      'ddlActiveInactive': [null],
      'ddlType': [null],
      'ddlStatus': [null],
      'ddlContinueToSell': [null],
      'txtSKU': [null],
      'ddlCatalog': [null],
      'ddlFulfillmentCenter': [null],
      'ddlCountry': [null],
      'txtPart': [null],
    });

  }

  ngOnInit() {
    this.RegionId = this._localStorageService.get('selRegion');
    this.LoadStockStatus();
    this.loadCountries(this.RegionId);
    this.loadCatalogGroup(this.RegionId);
    this.loadLocationCode(this.RegionId);
    this.Search(this.apjAtsDashboardForm.value,true);

  }
  LoadStockStatus(): void {
    this.indLoading = true;
      this._ApjAtsFacadeService.LoadStockStatus()
      .subscribe(configurations => {
        this.StockStatus = configurations;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }
  loadCountries(Id): void {
    this.indLoading = true;
    this._ApjAtsFacadeService.loadCountries(Id)
      .subscribe(countries => {
        this.Countries = countries;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }
  loadCatalogGroup(Id): void {
    this.indLoading = true;
    this._ApjAtsFacadeService.loadCatalogGroup(Id)
      .subscribe(cataloggroups => {
        this.CatalogGroups = cataloggroups;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }
  loadLocationCode(Id): void {
    this.indLoading = true;
    this._ApjAtsFacadeService.loadLocationCode(Id)
      .subscribe(locationcodes => {
        this.LocationCodes = locationcodes;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }

  getNext(event) {
    // offset = event.pageSize * event.pageIndex
    // call your api function here with the offset
    this.length = length;
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.Search(this.apjAtsDashboardForm.value,false);
  }
  
  doFilter(value: string) {
    debugger;
    value = value.trim();
    value = value.toLowerCase();
    this.dataSource.filter = value;
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  Search(objapjAtsDashboard, IsmainSearch) {
    //#region
    if (IsmainSearch) {
      this.pageIndex = 1;
    }
    this.IsProductManagement = false;
    this.IsItemDetails = false;
    this.IsCommitDetails = false;
    this.atsItemSearchRequest.sku = objapjAtsDashboard.txtSKU;
    if (objapjAtsDashboard.txtSKU==='' || objapjAtsDashboard.txtSKU==='undefined' || objapjAtsDashboard.txtSKU===null) {
      this.atsItemSearchRequest.sku =null;
    }
    this.atsItemSearchRequest.type = objapjAtsDashboard.ddlType;
    if (objapjAtsDashboard.ddlType==='' || objapjAtsDashboard.ddlType==='undefined' || objapjAtsDashboard.ddlType===null) {
      this.atsItemSearchRequest.type ="-1";
    }  
    this.atsItemSearchRequest.part = objapjAtsDashboard.txtPart;
    if (objapjAtsDashboard.txtPart==='' || objapjAtsDashboard.txtPart==='undefined' || objapjAtsDashboard.txtPart===null) {
      
    }
    this.atsItemSearchRequest.countryId = objapjAtsDashboard.ddlCountry;
    if (objapjAtsDashboard.ddlCountry==='' || objapjAtsDashboard.ddlCountry==='undefined' || objapjAtsDashboard.ddlCountry===null) {
      this.atsItemSearchRequest.countryId ="-1";
    }
    this.atsItemSearchRequest.catalogGroupIds = "-1";
    this.atsItemSearchRequest.regionId = this.RegionId;
    this.atsItemSearchRequest.stockStatus = objapjAtsDashboard.ddlStatus;
    if (objapjAtsDashboard.ddlStatus==='' || objapjAtsDashboard.ddlStatus==='undefined' || objapjAtsDashboard.ddlStatus===null) {
      this.atsItemSearchRequest.stockStatus ="-1";
    }
    this.atsItemSearchRequest.catalogId = objapjAtsDashboard.ddlCatalog;
    if (objapjAtsDashboard.ddlCatalog==='' || objapjAtsDashboard.ddlCatalog==='undefined' || objapjAtsDashboard.ddlCatalog===null) {
      this.atsItemSearchRequest.catalogId ="-1";
    }
    this.atsItemSearchRequest.locationCode = objapjAtsDashboard.ddlFulfillmentCenter;
    if (objapjAtsDashboard.ddlFulfillmentCenter==='' || objapjAtsDashboard.ddlFulfillmentCenter==='undefined' || objapjAtsDashboard.ddlFulfillmentCenter===null) {
      this.atsItemSearchRequest.locationCode ="-1";
    }

    this.atsItemSearchRequest.isContinueToSell = objapjAtsDashboard.ddlContinueToSell;
    if (objapjAtsDashboard.ddlContinueToSell === '' || objapjAtsDashboard.ddlContinueToSell === 'undefined' || objapjAtsDashboard.ddlContinueToSell === null) {
      this.atsItemSearchRequest.isContinueToSell = "-1";
    }

    this.atsItemSearchRequest.isActive = objapjAtsDashboard.ddlActiveInactive;
    if (objapjAtsDashboard.ddlActiveInactive==='' || objapjAtsDashboard.ddlActiveInactive==='undefined' || objapjAtsDashboard.ddlActiveInactive===null) {
      this.atsItemSearchRequest.isActive ="-1";
    }
 
    this.atsItemSearchRequest.salesChannel = 0;
    this.atsItemSearchRequest.sdsEnable = null;
    this.atsItemSearchRequest.pageNumber = this.pageIndex;
    this.atsItemSearchRequest.pageSize = this.pageSize;
//#endregion
    this.indLoading = true;
    this._ApjAtsFacadeService.Search(this.atsItemSearchRequest)
      .subscribe(FGADetails => {
       //this.pageIndex = 1;
       //this.pageSize= 15;

        this.getFGADetails=FGADetails['atsFGAItems']; 
        this.dataSource = new MatTableDataSource<UserData>(this.getFGADetails);
        this.totalPageSize = FGADetails['recordCount'];
        for (var i = 0; i < this.getFGADetails.length; i++) {
          this.getFGADetails[i].FontColor = 'black';
          if (this.getFGADetails[i].status === 'OK') {
              this.getFGADetails[i].BackgroundColor = 'limegreen';
          }
          if (this.getFGADetails[i].status === 'Low') {
              this.getFGADetails[i].BackgroundColor = 'lime';
          }
          if (this.getFGADetails[i].status === 'Buffer' || this.getFGADetails[i].status === 'SDS' || this.getFGADetails[i].status === 'SDS/Buffer' || this.getFGADetails[i].status === 'Buffer/SDS') {
              this.getFGADetails[i].BackgroundColor = 'yellow';
          }
          if (this.getFGADetails[i].status === 'XLT' || this.getFGADetails[i].status === 'In Oversell') {
              this.getFGADetails[i].BackgroundColor = 'darkorange';
          }
          if (this.getFGADetails[i].status === 'OOS/EOL' || this.getFGADetails[i].status === 'OOS' || this.getFGADetails[i].status === 'In Oversold') {
              this.getFGADetails[i].BackgroundColor = 'red';
              this.getFGADetails[i].FontColor = 'white';
          }
      }
        this.indLoading = false;
        this.SuccessMsg = Global.SaveMessage;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }
  exportAsXLSX():void {
    this.indLoading = true;
    this.atsItemSearchRequest.pageSize=this.totalPageSize;
    this._ApjAtsFacadeService.Search(this.atsItemSearchRequest)
      .subscribe(FGADetails => {
        this.getFGADetailsExport = FGADetails;
        this.exportData = this.getFGADetailsExport.atsFGAItems;


        this.exportData.map(item => {
          return {
              SKU: item.sku,
              Part: item.part,
              'Brand Name': item.brand,
              Description: item.description,
              Type: item.type,
              'Offer Type': item.offerType == '' ? "NA" : item.offerType,
              Catalog: item.catalogGroup,
              ATS: item.ats,
              'On Hand': item.onHand,
              Commit: item.commit,
              'Check Out': item.checkout,
              Cart: item.cart,
              Status: item.status,
              Threshold: item.threshold,
              'Current LT': item.leadTime,
              'LT Source': item.ltSource,
              'Std LT': item.defaultLT,
              'Continue To Sell': item.continueToSell == true ? "Y" : "N",
              Active: item.active == true ? "Y" : "N",

          }
        }).forEach(item => this.parseData.push(item));

        this.excelService.exportAsExcelFile(this.parseData, 'ATS_FGA_Items');

        this.indLoading = false;
        this.SuccessMsg = Global.SaveMessage;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }
  gotoParent() {
    setTimeout(() => {
      this.dashboard.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'start' });
      this.Search(this.apjAtsDashboardForm.value,false);

    });
    this.IsItemDetails = false;
    this.IsCommitDetails = false;

    this.IsProductManagement = false;
  }

  callitemDetails(row, event) {
    if (this.IsItemDetails) {
      this.IsItemDetails = false;
      this.delay(1000).then(any => {
        this.IsItemDetails = true;
        setTimeout(() => {
          this.panel.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'start' });
        });
      });
    }
    else {
      this.IsItemDetails = true;
      this.IsCommitDetails = false;
      this.IsProductManagement = false;
      setTimeout(() => {
        this.panel.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'start' });
      });
    }
      this.itemdetail.ProductCountryId = row.productCountryId;
      this.itemdetail.Sku = row.sku;
      this.itemdetail.Catalog = row.catalogGroup;
      this._localStorageService.set('productCountryId', row.productCountryId)
    
  }
  callProductManagement(row, event) {
    if (this.IsProductManagement) {
      this.IsProductManagement = false;

      this.delay(100).then(any => {
        this.IsProductManagement = true;
        setTimeout(() => {
          this.panelProductManagement.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'start' });
        });

      });
    }
    else {
      this.IsProductManagement = true;
      this.IsItemDetails = false;
      this.IsCommitDetails = false;
      setTimeout(() => {
        this.panelProductManagement.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'start' });
      });
    }
    this.productManagementReff.ProductId = row.id;
    this.productManagementReff.Sku = row.sku;
    this.productManagementReff.CatalogGroupId = row.catalogGroupId;

  }
  async delay(ms: number) {
    await new Promise(resolve => setTimeout(() => resolve(), ms)).then(() => console.log("fired"));
  }
  callCommitItemDetails(row, event) {
    this.IsItemDetails = false;
    this.IsCommitDetails = true;
    this.IsProductManagement = false;
    setTimeout(() => {
      this.commitDetails.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'start' });
    });
    this._commitItemDetail.ProductCountryId = row.productCountryId;
    this._commitItemDetail.Sku = row.sku;
    this._localStorageService.set('productCountryId', row.productCountryId)
    this._localStorageService.set('sku', row.sku)

  }



  // Executed When Form Is Submitted  
  onFormSubmit(form: NgForm) {
    console.log(form);
  }

}
//id:string;statusId: string;sds: string;productCountryId: string;extendedLeadTime: string;isSDSEnabledCountry: string;updatedOn: string;createdOn: string;
