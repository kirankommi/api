﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class AtsStates 
    {
        public int? Id { get; set; }
        public int? StateId { get; set; }
        public string StateCode { get; set; }
        public string StateName { get; set; }
        public int? CountryId { get; set; }
        public string Action { get; set; }
        public AtsSite site { get; set; }
    }
}
