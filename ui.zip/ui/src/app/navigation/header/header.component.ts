import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { MatSelectionListChange, MatOptionSelectionChange } from '@angular/material';
import { LocalStorageService } from 'angular-2-local-storage';
import { Alert } from 'selenium-webdriver';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormControl  } from '@angular/forms';
export interface Region {
  value: string;
  viewValue: string;
}
export interface ProductType {
  value: string;
  viewValue: string;
}
declare const $: any;
declare interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    class: string;
}
export const ROUTES: RouteInfo[] = [
  { path: '/home', title: 'Home',  icon: 'home', class: '' },
  //{ path: '/user-profile', title: 'User Profile',  icon:'person', class: '' },
  //{ path: '/table-list', title: 'Table List',  icon:'content_paste', class: '' },
  //{ path: '/typography', title: 'Typography',  icon:'library_books', class: '' },
  //{ path: '/icons', title: 'Icons',  icon:'bubble_chart', class: '' },
  //{ path: '/maps', title: 'Maps',  icon:'location_on', class: '' },
  //{ path: '/notifications', title: 'Notifications',  icon:'notifications', class: '' },
];
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  @Output() public sidenavToggle = new EventEmitter();


  selRegion: string;
  productType: string;
  HeaderForm: FormGroup;
  IsApjAts: boolean = false; IsEmeaAts: boolean = false; IsNoRegion: boolean = false;
  //router: any;
  constructor(private _localStorageService: LocalStorageService, private route: Router) {
    this.HeaderForm = new FormGroup({
      ddlRegion: new FormControl(''),
      ddlProductType: new FormControl('')

    });

  }

  Regions: Region[] = [
    // {value: '1', viewValue: 'AMERICAS'},
    {value: '2', viewValue: 'APJ'},
    //{value: '3', viewValue: 'EMEA'},
    // {value: '4', viewValue: 'GLOBAL'}
  ];
  ProductTypes: ProductType[] = [
    {value: '1', viewValue: 'BASE'},
    {value: '2', viewValue: 'COMPONENT'},
    {value: '3', viewValue: 'FGA (BTS & BTP)'},
    {value: '4', viewValue: 'BTO / CTO'},
    {value: '5', viewValue: 'S & P ATS'},
    {value: '6', viewValue: 'ATS (BTS & BTP)'},
    {value: '7', viewValue: 'Ready Stock'}
  ];
  ngOnInit() {
    if (this.HeaderForm.controls['ddlRegion'].value === '' || this.HeaderForm.controls['ddlProductType'].value === '') {
      this.route.navigate(['/home']);
    }
    this._localStorageService.set('UserName', 'Jitendra_kumar_pradh');
  }
 
  public onToggleSidenav = () => {
    this.sidenavToggle.emit();
  }

  RegionChange(value) {
    if (this.HeaderForm.controls['ddlRegion'].value === '' || this.HeaderForm.controls['ddlProductType'].value === '') {
      this.route.navigate(['/home']);
    }

    this.selRegion = this.HeaderForm.controls['ddlRegion'].value;
    this._localStorageService.set('selRegion', this.HeaderForm.controls['ddlRegion'].value);
  }
  productTypeChange(value) {
    this.productType = value;
    if (this.HeaderForm.controls['ddlRegion'].value === "2" && this.HeaderForm.controls['ddlProductType'].value ==='ATS') {
      this.IsApjAts = true;
      this.IsEmeaAts = false;
      this.IsNoRegion = false;
      this.route.navigate(['/ats-dashboard']);
    }
    else if (this.HeaderForm.controls['ddlRegion'].value === "3" && this.HeaderForm.controls['ddlProductType'].value === 'ATS') {
      this.IsEmeaAts = true;
      this.IsApjAts = false;
      this.IsNoRegion = false;
      this.route.navigate(['/home']);
    }
    else {
      this.IsNoRegion = true;
      this.IsEmeaAts = false;
      this.IsApjAts = false;
      this.route.navigate(['/home']);

    }
  }
}
