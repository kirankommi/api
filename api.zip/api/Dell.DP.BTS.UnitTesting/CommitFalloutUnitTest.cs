﻿using Dell.DP.BTS.Entities;
using Dell.DP.BTS.API.Controllers;
using Dell.DP.BTS.DataServices;
using Dell.DP.BTS.BusinessServices;
using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    /// <summary>
    /// Summary description for ProductConfigurationUnitTest
    /// </summary>
    
    public class CommitFalloutUnitTest:UnitTestInitializer
    {


        [Fact]
        public void GetCommitFalloutDataShouldReturnOKResult()
        {
            CommitFalloutRequest commitFalloutRequest = new CommitFalloutRequest();
            commitFalloutRequest.PageNumber = 1;
            commitFalloutRequest.PageSize = 20;
            commitFalloutRequest.RegionId = "3";


            var result = btsQueryController.GetCommitCalloutDetails(commitFalloutRequest);
            Assert.NotNull(result);
        }
    }
}
