﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsCatalog
    {
        public int Id { get; set; }
        public int CountryId { get; set; }
        public string CountryName { get; set; }
        public string RegionCode { get; set; }
        public int? CatalogId { get; set; }
        public int CatalogGroupId { get; set; }
        public string CatalogGroup { get; set; }
        public string CountryCodes { get; set; }
        public string CountryIdsCsv { get; set; }
        public int[] CountryIds{ get; set; }
        public string UserID { get; set; }
        public int RegionId { get; set; }
    }
}
