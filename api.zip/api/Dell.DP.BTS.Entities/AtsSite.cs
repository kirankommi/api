﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsSite : AtsCommon
    {
        public int? Id { get; set; }
        public string SiteName { get; set; }
        public string SiteCode { get; set; }
        public string Description { get; set; }
        public string CountryName { get; set; }
        public string ModifiedBy { get; set; }
        public int CountryId { get; set; }
        public int OldCountryId { get; set; }
        public int Sequence { get; set; }
        public string Type { get; set; }
        public bool IsActive { get; set; }
        public int ProductCountryId { get; set; }

        public string Operation { get; set; }
    }
}
