import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { ApjAtsFacadeService } from '@App/shared/apj-ats-facade.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ConfirmationDialogComponent, ConfirmDialogModel } from '@App/shared/confirmation-dialog/confirmation-dialog.component';
import { MatDialog, MatSlideToggleChange, MatTableDataSource } from '@angular/material';
import { NotifierService } from 'angular-notifier';
import { forkJoin } from 'rxjs';
import { LocalStorageService } from 'angular-2-local-storage';

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.css']
})
export class ItemDetailsComponent implements OnInit {
  @ViewChild('FulfillmentCenter') public PanelFulfillmentCenter: ElementRef;
  @ViewChild('PanelItemDetails') public PanelItemDetails: ElementRef;

  @Input() itemdetail: itemdetail;
  RegionId: number;
  ProductCountryId: any;
  /*** Notifier service*/
  private notifier: NotifierService;
  userIsApjReadOnly: boolean = false;
  indLoading: boolean = false; ErrorMsg: any; SuccessMsg: any; editThreshold: boolean = false; editLeadTime: boolean = false; IsAutoXLT: boolean = false; IsFulfillmentCenter: boolean = false;
  IsContinueToSell: boolean = false; IsDisplayLowInventry: boolean = false; IsInventryActive: boolean = false; noInventoryStatus: boolean = false; noStatusHistoryFound: boolean = false;
  dateDiff: any;

  refreshData: any; Catalog: any; atsDetail: {}; result: string = '';
  leadTimeHistory: any; statusHistory: any; daysofSupply: any[]; IsleadTimeHistory: boolean = false;
  incomingsupply: any; inventoryStatusInfo: any; inventoryStatus: any;
  dataFormat = ['FacilityCode', 'OnHand'];

  xlt: number = 0; sds: number = 0; low: number = 0; oos: number = 0; ok: number = 0; total: number = 0; From: string; To: string;
  chartOptions = {
    cutoutPercentage: 80, responsive: true,
    maintainAspectRatio: false, legend: false
  };
  doughnutChartColors: any[];
  doughnutChartLabels: string[];
  doughnutChartData: number[];
  doughnutChartType: string;
  FromStatusHistory: any; ToStatusHistory: any;

  ThresholdForm: FormGroup; LeadTimeForm: FormGroup; InventoryStatusForm: FormGroup;

  public AtsItemDetail: AtsItemDetail = new AtsItemDetail();
  public objleadTimeHistory: LeadTimeHistory = new LeadTimeHistory();
  LeadTimeHistorydataSource: MatTableDataSource<LeadTimeHistory>;
  public autoXltIncrements: Array<autoXltIncrement>;


  constructor(private fb: FormBuilder, private _ApjAtsFacadeService: ApjAtsFacadeService, public dialog: MatDialog, notifier: NotifierService, private _localStorageService: LocalStorageService) {
    this.ThresholdForm = new FormGroup({
      txtlowThreshold: new FormControl('', [Validators.required, Validators.min(-100000), Validators.max(100000), Validators.maxLength(7)]),
      txtsameDayShippingThreshold: new FormControl('', [Validators.required, Validators.min(-100000), Validators.max(100000), Validators.maxLength(6)]),
      txtextendedLeadTimeThresold: new FormControl('', [Validators.required, Validators.min(-100000), Validators.max(100000), Validators.maxLength(6)]),
      txtoutOfStockThresold: new FormControl('', [Validators.required, Validators.min(-100000), Validators.max(100000), Validators.maxLength(6)])
      //,txtoutOfStockThresholdOffline: new FormControl('', [Validators.required, Validators.min(-100000), Validators.max(100000), Validators.maxLength(6)])

    });
    this.LeadTimeForm = new FormGroup({
      txtdefaultLT: new FormControl('', [Validators.required, Validators.min(1), Validators.max(999), Validators.maxLength(3), Validators.pattern('^[0-9]{0,3}$')]),
      txtExtendedLeadTime: new FormControl('', [Validators.required, Validators.min(1), Validators.max(999), Validators.maxLength(3), Validators.pattern('^[0-9]{0,3}$')]),
      ddlautoXltIncrement: new FormControl(''),
      swchAllowAutoXLT: new FormControl('')
    });
    this.InventoryStatusForm = new FormGroup({
      swchContinueToSellDisable: new FormControl(''),
      swchContinueToSellEnable: new FormControl(''),
      swchDisplayLowInventryEnable: new FormControl(''),
      swchDisplayLowInventryDisable: new FormControl(''),
      swchActiveDisable: new FormControl(''),
      swchActiveEnable: new FormControl('')

    });
    this.notifier = notifier;
    this.RegionId = this._localStorageService.get('selRegion');
    this.ProductCountryId = this._localStorageService.get('productCountryId');

  }

  ngOnInit() {
    this.autoXltIncrements = Array<autoXltIncrement>();
    this.autoXltIncrements.push(new autoXltIncrement(1, '1'));
    this.autoXltIncrements.push(new autoXltIncrement(2, '2'));
    this.autoXltIncrements.push(new autoXltIncrement(3, '3'));
    this.autoXltIncrements.push(new autoXltIncrement(4, '4'));
    this.autoXltIncrements.push(new autoXltIncrement(5, '5'));
    this.autoXltIncrements.push(new autoXltIncrement(6, '6'));
    this.autoXltIncrements.push(new autoXltIncrement(7, '7'));
    this.autoXltIncrements.push(new autoXltIncrement(8, '8'));
    this.autoXltIncrements.push(new autoXltIncrement(9, '9'));
    this.autoXltIncrements.push(new autoXltIncrement(10, '10'));

    this.getAtsItemDetail(this.itemdetail.ProductCountryId);
    this.getInventoryStatus(this.itemdetail.ProductCountryId);
    this.getLeadTimeHistory(this.itemdetail.ProductCountryId);
    this.getItemStatusHistory(this.itemdetail.ProductCountryId);
    this.getDataRefreshDetail(this.itemdetail.ProductCountryId);
    this.getDaysofSupply(this.itemdetail.ProductCountryId);
    this.getIncomingSupply(this.itemdetail.ProductCountryId);

  }
  //#region "Edit Continue To Sell"
  updateLowInventory(event: MatSlideToggleChange) {
    this.IsDisplayLowInventry = event.checked;
    var message = 'Display Low Inventory will be updated. Do you want to Continue ?';
    const dialogData = new ConfirmDialogModel("Display Low Inventory Edit", message);

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      maxWidth: "100%",
      data: dialogData,
      disableClose: true,
      width: "100%",
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult) {
        this.AtsItemDetail.displayLowInventry = this.IsDisplayLowInventry;
        this.AtsItemDetail.productCountryId = this.itemdetail.ProductCountryId;
        this.AtsItemDetail.updatedBy = 'jitendra_kumar_pradh';

        this.indLoading = true;
        this._ApjAtsFacadeService.updateLowInventory(this.AtsItemDetail)
          .subscribe(atsDetails => {
            this.getAtsItemDetail(this.itemdetail.ProductCountryId);
            this.notifier.notify('success', 'Information updated successfully');
            this.editThreshold = false;
            this.indLoading = false;
          },
            error => { this.notifier.notify('error', 'Error while updating Continue to Sell'); this.indLoading = false; });
      }
      else {
        this.IsDisplayLowInventry = !this.IsDisplayLowInventry;
      }
      this.result = dialogResult;
    });
  }
  updateContinueToSell(event: MatSlideToggleChange) {
    this.IsContinueToSell = event.checked;
    var message = 'Continue To Sell will be updated. Do you want to Continue ?';
    const dialogData = new ConfirmDialogModel("ContinueToSell Edit", message);

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      maxWidth: "100%",
      data: dialogData,
      disableClose: true,
      width: "100%",
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult) {
        this.AtsItemDetail.continueToSell = this.IsContinueToSell;
        this.AtsItemDetail.productCountryId = this.itemdetail.ProductCountryId;
        this.AtsItemDetail.updatedBy = 'jitendra_kumar_pradh';

        this.indLoading = true;
        this._ApjAtsFacadeService.updateContinueToSell(this.AtsItemDetail)
          .subscribe(atsDetails => {
            this.getAtsItemDetail(this.itemdetail.ProductCountryId);
            this.notifier.notify('success', 'Information updated successfully');
            this.editThreshold = false;
            this.indLoading = false;
          },
            error => { this.notifier.notify('error', 'Error while updating Continue to Sell'); this.indLoading = false; });
      }
      else {
        this.IsContinueToSell = !this.IsContinueToSell;
      }
      this.result = dialogResult;
    });
  }
  updateIsActive(event: MatSlideToggleChange) {
    this.IsInventryActive = event.checked;
    var message = 'Active status will be updated. Do you want to Continue ?';
    const dialogData = new ConfirmDialogModel("Active status Edit", message);

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      maxWidth: "100%",
      data: dialogData,
      disableClose: true,
      width: "100%",
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult) {
        this.AtsItemDetail.active = this.IsInventryActive;
        this.AtsItemDetail.productCountryId = this.itemdetail.ProductCountryId;
        this.AtsItemDetail.updatedBy = 'jitendra_kumar_pradh';

        this.indLoading = true;
        this._ApjAtsFacadeService.updateIsActive(this.AtsItemDetail)
          .subscribe(atsDetails => {
            this.getAtsItemDetail(this.itemdetail.ProductCountryId);
            this.notifier.notify('success', 'Information updated successfully');
            this.editThreshold = false;
            this.indLoading = false;
          },
            error => { this.notifier.notify('error', 'Error while updating Active status'); this.indLoading = false; });
      }
      else {
        this.IsInventryActive = !this.IsInventryActive;
      }
      this.result = dialogResult;
    });
  }
  //#endregion
  //#region "LeadTime Edit"
  toggleLeadTimeEditMode() {
    (<FormControl>this.LeadTimeForm.controls['swchAllowAutoXLT'])
      .setValue(this.AtsItemDetail.allowAutoXLT, { onlySelf: true });
    if (this.AtsItemDetail.allowAutoXLT) {
      (<FormControl>this.LeadTimeForm.controls['ddlautoXltIncrement'])
        .setValue(this.AtsItemDetail.autoXltIncrement, { onlySelf: true });

      //for (let state of this.states) {
      //  if (objTowCompany.StateId == state.StateId) {
      //    (<FormControl>this.TowCompanyForm.controls['stateCtrl'])
      //      .setValue(state);
      //  }
      //}
    }
    (<FormControl>this.LeadTimeForm.controls['txtdefaultLT'])
      .setValue(this.AtsItemDetail.defaultLT, { onlySelf: true });
    (<FormControl>this.LeadTimeForm.controls['txtExtendedLeadTime'])
      .setValue(this.AtsItemDetail.extendedLeadTime, { onlySelf: true });
  }

  public useDefault = false;
  updateAutoXLT(event: MatSlideToggleChange) {
    this.useDefault = event.checked;
    this.IsAutoXLT = event.checked;
    var message = '';
    if (this.IsAutoXLT) {
      message = 'Auto XLT will be turned on. Do you want to Continue ?';
    }
    else {
      message = 'Turning-off Auto XLT may impact the accuracy of lead time and POI. Do you wish to Continue ?';

    }
    const dialogData = new ConfirmDialogModel("Threshold Edit", message);

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      maxWidth: "100%",
      data: dialogData,
      disableClose: true,
      width: "100%",
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult) {
        this.AtsItemDetail.allowAutoXLT = this.IsAutoXLT;
        this.AtsItemDetail.productCountryId = this.itemdetail.ProductCountryId;
        this.AtsItemDetail.updatedBy = 'jitendra_kumar_pradh';

        this.indLoading = true;
        this._ApjAtsFacadeService.updateAutoXLT(this.AtsItemDetail)
          .subscribe(atsDetails => {
            this.getAtsItemDetail(this.itemdetail.ProductCountryId);
            this.getLeadTimeHistory(this.itemdetail.ProductCountryId);
            this.getItemStatusHistory(this.itemdetail.ProductCountryId);
            this.notifier.notify('success', 'Information updated successfully');
            this.editThreshold = false;
            this.indLoading = false;
          },
            error => { this.notifier.notify('error', 'Error while updating AllowAutoXLT'); this.indLoading = false; });
      }
      else {
        this.IsAutoXLT = !this.IsAutoXLT;

        this.useDefault = !this.useDefault;
      }
      this.result = dialogResult;
    });
  }
  leadTimeEditDialog(LeadTimeForm) {
    if (this.LeadTimeForm.valid) {
      if (LeadTimeForm.controls['txtdefaultLT'].value === this.AtsItemDetail.defaultLT && LeadTimeForm.controls['txtExtendedLeadTime'].value === this.AtsItemDetail.extendedLeadTime
        && this.AtsItemDetail.autoXltIncrement === LeadTimeForm.controls['ddlautoXltIncrement'].value) {
        this.notifier.notify('warning', 'No LeadTime has been Modified');
        return;
      }
      else {
        var message = '';
        if (LeadTimeForm.controls['txtExtendedLeadTime'].value <= LeadTimeForm.controls['txtdefaultLT'].value) {
          message = 'Extended lead time should ideally be greater than the standard lead time. Continue ?';
        }
        else if (LeadTimeForm.controls['txtExtendedLeadTime'].value > LeadTimeForm.controls['txtdefaultLT'].value) {
          message = 'Leadtime will be updated, Do you want to proceed ?';

        }
        const dialogData = new ConfirmDialogModel("LeadTime Edit", message);

        const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
          maxWidth: "100%",
          data: dialogData,
          disableClose: true,
          width: "100%",
        });

        dialogRef.afterClosed().subscribe(dialogResult => {
          if (dialogResult) {
            this.AtsItemDetail.defaultLT = LeadTimeForm.controls['txtdefaultLT'].value;
            this.AtsItemDetail.extendedLeadTime = LeadTimeForm.controls['txtExtendedLeadTime'].value;
            this.AtsItemDetail.autoXltIncrement = LeadTimeForm.controls['ddlautoXltIncrement'].value;
            this.AtsItemDetail.sku = this.itemdetail.Sku;
            this.AtsItemDetail.productCountryId = this.itemdetail.ProductCountryId;
            this.AtsItemDetail.updatedBy = 'jitendra_kumar_pradh';

            this.indLoading = true;
            this._ApjAtsFacadeService.updateLeadTime(this.AtsItemDetail)
              .subscribe(atsDetails => {
                this.getAtsItemDetail(this.itemdetail.ProductCountryId);
                this.getLeadTimeHistory(this.itemdetail.ProductCountryId);
                this.getIncomingSupply(this.itemdetail.ProductCountryId);
                this.notifier.notify('success', 'Lead Time updated successfully');
                this.editLeadTime = false;
                this.indLoading = false;
              },
                error => { this.notifier.notify('error', 'Error while updating Lead Time'); this.indLoading = false; });
          }
          this.result = dialogResult;
        });
      }

    }

  }
  //#endregion
  //#region "Threshold Edit"
  getDaysofSupply(ProductCountryId): void {
    this.indLoading = true;
    this._ApjAtsFacadeService.getDaysofSupply(ProductCountryId)
      .subscribe(daysofSupplys => {
        this.daysofSupply = daysofSupplys;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }
  getAtsItemDetail(ProductCountryId): void {
    this.indLoading = true;
    this._ApjAtsFacadeService.getAtsItemDetail(ProductCountryId)
      .subscribe(atsItemDetails => {
        //this.threshold = atsItemDetails[0];
        this.AtsItemDetail = Object.assign(new AtsItemDetail(), atsItemDetails[0]);
        this.IsAutoXLT = this.AtsItemDetail.allowAutoXLT;
        this.IsContinueToSell = this.AtsItemDetail.continueToSell;
        this.IsDisplayLowInventry = this.AtsItemDetail.displayLowInventry;
        this.IsInventryActive = this.AtsItemDetail.active;

        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }
  getInventoryStatus(ProductCountryId): void {
    this.indLoading = true;
    var pdata = [];

    this._ApjAtsFacadeService.getInventoryStatus(ProductCountryId, this.RegionId)
      .subscribe(data => {
        if (data.length == 0) {
          this.noInventoryStatus = true;
        }
        else {
          this.noInventoryStatus = false;
          this.inventoryStatusInfo = data;
        }
        var Total = 0;
        for (var i = 0; i < this.dataFormat.length; i++) {
          var item = {
            Name: this.dataFormat[i],
            datas: [],
            Total: "0"
          }
          for (var j = 0; j < data.length; j++) {
            const tmp = item.Name.charAt(0).toLowerCase() + item.Name.slice(1);
            item.datas.push(data[j][tmp]);
            if (tmp !== 'facilityCode') {
              Total += Number(data[j][tmp]) || 0;
              item.Total = Total.toString();
            } else
              item.Total = "Total"
          }
          pdata.push(item);
        }
        this.inventoryStatus = pdata;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }
  trackByFn(index, item) {
    return index; // or item.id
  }
  goToLocationCodeDetail() { }
  getLeadTimeHistory(ProductCountryId): void {
    this.indLoading = true;
    this._ApjAtsFacadeService.getLeadTimeHistory(ProductCountryId)
      .subscribe(leadTimeHistorys => {
        this.leadTimeHistory = leadTimeHistorys;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }
  getItemStatusHistory(ProductCountryId): void {

    this.indLoading = true;
    this._ApjAtsFacadeService.getItemStatusHistory(ProductCountryId)
      .subscribe(statusHistorys => {
        if (statusHistorys.length > 0) {
          this.noStatusHistoryFound = false;
          this.statusHistory = statusHistorys;
          this.FromStatusHistory = statusHistorys[statusHistorys.length - 1].createdOn;
          this.ToStatusHistory = statusHistorys[0].createdOn;

          for (var i = statusHistorys.length - 1; i >= 0; i--) {
            if (i == 0) {
              if (statusHistorys[i].toState == "SDS")
                statusHistorys[i].toState = "Buffer";
              if (statusHistorys[i].fromStatus == "SDS")
                statusHistorys[i].fromStatus = "Buffer";
            }
            else {
              this.dateDiff = Math.round((new Date(this.statusHistory[i - 1].createdOn).getTime() - new Date(this.statusHistory[i].createdOn).getTime()) / 60000);
              this.total += this.dateDiff;

              if (statusHistorys[i].toState === "OOS") {
                this.oos += this.dateDiff;
              }
              else if (statusHistorys[i].toState === "OK") {
                this.ok += this.dateDiff;
              }
              else if (statusHistorys[i].toState === "Low") {
                this.low += this.dateDiff;
              }
              else if (statusHistorys[i].toState === "XLT") {
                this.xlt += this.dateDiff;
              }
              else if (statusHistorys[i].toState == "SDS") {
                statusHistorys[i].toState = "Buffer";
                this.sds += this.dateDiff;
              }
              if (statusHistorys[i].fromStatus == "SDS")
                statusHistorys[i].fromStatus = "Buffer";
            }
          }
          this.oos = Number(Number((this.oos / this.total) * 100).toFixed(3));
          this.ok = Number(Number((this.ok / this.total) * 100).toFixed(3));
          this.low = Number(Number((this.low / this.total) * 100).toFixed(3));
          this.xlt = Number(Number((this.xlt / this.total) * 100).toFixed(3));
          this.sds = Number(Number((this.sds / this.total) * 100).toFixed(3));
          this.doughnutChartColors = [{ backgroundColor: ["red", "limegreen", "lime", "darkorange", "yellow"] }];
          this.doughnutChartLabels = ['OOS', 'OK', 'LOW', 'XLT', 'Buffer'];
          this.doughnutChartData = [this.oos, this.ok, this.low, this.xlt, this.sds];
          this.doughnutChartType = 'doughnut';


        }
        else
          this.noStatusHistoryFound = true;

        this.statusHistory = statusHistorys;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }
  getDataRefreshDetail(ProductCountryId): void {
    this.indLoading = true;
    this._ApjAtsFacadeService.getDataRefreshDetail(ProductCountryId)
      .subscribe(refreshDatas => {
        this.refreshData = refreshDatas;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }
  getIncomingSupply(ProductCountryId): void {
    this.indLoading = true;
    this._ApjAtsFacadeService.getIncomingSupply(ProductCountryId)
      .subscribe(incomingsupplys => {
        this.incomingsupply = incomingsupplys;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }

  toggleThresholdEditMode() {
    (<FormControl>this.ThresholdForm.controls['txtlowThreshold'])
      .setValue(this.AtsItemDetail.lowThreshold, { onlySelf: true });
    (<FormControl>this.ThresholdForm.controls['txtsameDayShippingThreshold'])
      .setValue(this.AtsItemDetail.sameDayShippingThreshold, { onlySelf: true });
    (<FormControl>this.ThresholdForm.controls['txtextendedLeadTimeThresold'])
      .setValue(this.AtsItemDetail.extendedLeadTimeThresold, { onlySelf: true });
    (<FormControl>this.ThresholdForm.controls['txtoutOfStockThresold'])
      .setValue(this.AtsItemDetail.outOfStockThresold, { onlySelf: true });
    //(<FormControl>this.ThresholdForm.controls['txtoutOfStockThresholdOffline'])
    //  .setValue(this.AtsItemDetail.outOfStockThresholdOffline, { onlySelf: true });

  }
  thresholdEditDialog(ThresholdForm): void {
    if (this.ThresholdForm.valid) {
      if (this.AtsItemDetail.lowThreshold === ThresholdForm.controls['txtlowThreshold'].value && this.AtsItemDetail.sameDayShippingThreshold === ThresholdForm.controls['txtsameDayShippingThreshold'].value
        && this.AtsItemDetail.extendedLeadTimeThresold === ThresholdForm.controls['txtextendedLeadTimeThresold'].value
        && this.AtsItemDetail.outOfStockThresold === ThresholdForm.controls['txtoutOfStockThresold'].value) {
        //&& this.AtsItemDetail.outOfStockThresholdOffline === ThresholdForm.controls['txtoutOfStockThresholdOffline'].value
        this.notifier.notify('warning', 'No Threshold has been Modified');
        return;
      }
      if (ThresholdForm.controls['txtlowThreshold'].value <= ThresholdForm.controls['txtsameDayShippingThreshold'].value) {
        this.notifier.notify('warning', 'Low threshold must be greater than Buffer threshold');
        return;
      }
      else if (ThresholdForm.controls['txtsameDayShippingThreshold'].value <= ThresholdForm.controls['txtextendedLeadTimeThresold'].value) {
        this.notifier.notify('warning', 'Buffer threshold must be greater than In Oversell threshold');
        return;
      }
      else if (ThresholdForm.controls['txtextendedLeadTimeThresold'].value <= ThresholdForm.controls['txtoutOfStockThresold'].value) {
        this.notifier.notify('warning', 'In Oversell threshold must be greater than In Oversold (Online) threshold');
        return;
      }
      //else if (ThresholdForm.controls['txtextendedLeadTimeThresold'].value <= ThresholdForm.controls['txtoutOfStockThresholdOffline'].value) {
      //  this.notifier.notify('warning', 'In Oversell threshold must be greater than In Oversold (Offline) threshold');
      //  return;
      //}

      else {
        const message = 'Threshold will be updated, Do you want to proceed ?';

        const dialogData = new ConfirmDialogModel("Threshold Edit", message);

        const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
          maxWidth: "100%",
          data: dialogData,
          disableClose: true,
          width: "100%",
        });

        dialogRef.afterClosed().subscribe(dialogResult => {
          if (dialogResult) {
            this.updateThresholdAction(ThresholdForm);
          }
          this.result = dialogResult;
        });
      }

    }


  }
  updateThresholdAction(ThresholdForm) {
    this.AtsItemDetail.lowThreshold = ThresholdForm.controls['txtlowThreshold'].value;
    this.AtsItemDetail.sameDayShippingThreshold = ThresholdForm.controls['txtsameDayShippingThreshold'].value;
    this.AtsItemDetail.extendedLeadTimeThresold = ThresholdForm.controls['txtextendedLeadTimeThresold'].value;
    this.AtsItemDetail.outOfStockThresold = ThresholdForm.controls['txtoutOfStockThresold'].value;
    //this.AtsItemDetail.outOfStockThresholdOffline = ThresholdForm.controls['txtoutOfStockThresholdOffline'].value;
    this.AtsItemDetail.productCountryId = this.itemdetail.ProductCountryId;
    this.AtsItemDetail.updatedBy = 'jitendra_kumar_pradh';
    //this.AtsItemDetail.regionId = this.RegionId;
    this.indLoading = true;
    this._ApjAtsFacadeService.updateThreshold(this.AtsItemDetail)
      .subscribe(atsDetails => {
        this.getAtsItemDetail(this.itemdetail.ProductCountryId);
        this.getInventoryStatus(this.itemdetail.ProductCountryId);
        this.getLeadTimeHistory(this.itemdetail.ProductCountryId);
        this.getItemStatusHistory(this.itemdetail.ProductCountryId);
        this.getDataRefreshDetail(this.itemdetail.ProductCountryId);
        this.getIncomingSupply(this.itemdetail.ProductCountryId);
        this.notifier.notify('success', 'Threshold updated successfully');
        this.editThreshold = false;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });

  }
  //#endregion
  gotoFulfillmentCenter() {
    if (this.itemdetail.Catalog === 'NEW FGA:GLOBAL') {
      this.notifier.notify('warning', 'Please add Country and catalog before adding fullfillment center');
      return;
    }
    else {
      this.IsFulfillmentCenter = true;
      setTimeout(() => {
        this.PanelFulfillmentCenter.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'start' });

      });

    }
  }
  gotoParentItemDetails() {
    setTimeout(() => {
      this.PanelItemDetails.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'start' });

    });
    this.IsFulfillmentCenter = false;

  }


}
//#region "Internal Class"
class AtsItemDetail {
  lowThreshold: number;
  sdsShippingId: number;
  outOfStockThresold: number;
  displayLowInventry: boolean;
  isEligibleForSmartLogo: boolean;
  itemInventryStatus: string;
  isFirstTrackEligible: boolean;
  extendedLeadTimeThresold: number;
  availabletoSellQuantiry: number;
  sameDayShippingThreshold: number;
  allowAutoXLT: boolean;
  autoXltIncrement: number;
  id: number;
  sku: string = null;
  part: string = null;
  brand: string = null;
  type: string = null;
  offerType: string = null;
  description: string = null;
  catalogId: number = 0;
  catalog: string = null;
  catalogGroupId: number = 0;
  catalogGroup: string = null;
  ats: number = 0;
  onHand: number = 0;
  commit: number = 0;
  checkout: number = 0;
  cart: number = 0;
  futureCommit: string = null;
  statusId: number = 0;
  status: string = null;
  leadTime: number;
  ltSource: string;
  defaultLT: number;
  stdLeadTime: number = 0;
  countDown: string = null;
  continueToSell: boolean;
  sds: boolean;
  active: boolean;
  productCountryId: number = 0;
  productCountryIds: string = null;
  extendedLeadTime: number;
  isSDSEnabledCountry: boolean;
  threshold: string = null;
  //isBTSSku: boolean = null;
  //isBTOSku: boolean = null;
  //isBTPSku: boolean = null;
  updatedBy: string = null;
  createdBy: string = null;
  updatedOn: string = null;
  createdOn: string = null;
  outOfStockThresholdOffline: number;
  regionId: number;
}
class LeadTimeHistory {
  id: number;
  changedOn: string;
  fromLeadTime: number;
  toLeadTime: number;
  updatedBy: string;
}
export class autoXltIncrement {
  constructor(id: number, name: string) {
    this.id = id;
    this.name = name;
  }

  id: number;
  name: string;
}
class itemdetail {
  ProductCountryId: number;
  Sku: string;
  Catalog: string;
}
//#endregion
