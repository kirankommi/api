﻿using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    /// <summary>
    /// Summary description for CountryManagementUnitTest
    /// </summary>
    
    public class CountryManagementEditUnitTest:UnitTestInitializer
    {

        [Fact]
        public void UpdateCountriesDataShouldReturnOKResult()
        {
            var result = btsCommandController.UpdateCountry(atsCountrys);
            Assert.NotNull(result);
        }
    }
}
