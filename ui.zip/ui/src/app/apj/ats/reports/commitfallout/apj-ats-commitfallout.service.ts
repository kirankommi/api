import { Injectable } from '@angular/core';
import {DataservicesProvider} from '@Dataservice/dataservices/dataservices';
import { Global } from '@App/shared/global';
import { Observable } from 'rxjs/Observable';
import { CommitFalloutRequest } from './apj-ats-commitfallout.model';

@Injectable({
    providedIn: 'root'  
})
  export class ApjAtsCommitfalloutService {

    constructor(private _DataservicesProvider:DataservicesProvider ) {
    }

    getCommitFallout(commitFalloutRequest) {
      return this._DataservicesProvider.PostData(Global.ApjEmeaAtsApiUrl + 'getCommitFallout', commitFalloutRequest);
    }

    getExportCommitFallout(commitFalloutRequest) {
      return this._DataservicesProvider.PostData(Global.ApjEmeaAtsApiUrl + 'getExportCommitFallout', commitFalloutRequest);
    }
  }
