import { Injectable } from '@angular/core';
import {DataservicesProvider} from '@Dataservice/dataservices/dataservices';
import { environment } from '@Environments/environment';

@Injectable({
  providedIn: 'root'
  
})
export class ApjatsDashboardService {

  constructor(private _DataservicesProvider:DataservicesProvider ) {
   }
   LoadStockStatus() {
     return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getStockStatus');
  }   
  loadCountries (Id) {
    return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getCountriesAndCatalogGroups/' + Id);
  }
  loadCatalogGroup (Id) {
    return   this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getcataloggroup/' + Id);
   }
   loadLocationCode (Id) {
    return   this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getLocationCode/' + Id);
   }
   Search (objapjAtsDashboard) {
    return   this._DataservicesProvider.PostData(environment.ApjEmeaAtsApiUrl + 'getFGADetails', objapjAtsDashboard);
   }

}
