import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemExceptionReportComponent } from './item-exception-report.component';

describe('ItemExceptionReportComponent', () => {
  let component: ItemExceptionReportComponent;
  let fixture: ComponentFixture<ItemExceptionReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ItemExceptionReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemExceptionReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
