export class AtsCommitDetail {
  reservationId: string;
  name: string;
  irn: string;
  segment: string;
  orderNumber: string;
  quantity: number;
  facilityCode: string;
  tieNumber: string;
  fulfillmentLocation: string;
  shipToContactName: string;
  billingCompanyName: string;
  reservedOn: Date;
  commitedOn: Date;
  mustArriveByDate: Date;
  futuristicDeliveryDate: Date;
  customerName: string;
  releaseDate: Date;
  overrideTPB: boolean;
  gossStatus: string;
  businessUnitCode: string;
  fulfillWarning: boolean;
  cancelWarning: boolean;
  updatedBy: string;
  createdBy: string;
  updatedOn: Date;
  createdOn: Date;
}

export class CommitItemDetail {
  ProductCountryId: number;
  Sku: string;
}
