﻿using Dell.DP.BTS.Entities;
using Dell.DP.BTS.API.Controllers;
using Dell.DP.BTS.DataServices;
using Dell.DP.BTS.BusinessServices;
using Xunit;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.AspNetCore.Mvc;

namespace Dell.DP.BTS.UnitTesting
{
    
    public class DashboardSearch : UnitTestInitializer
    {

        [Fact]

        public void GetDashboardSearchWithOutAnyFilter()
        {
            AtsItemSearchRequest items = new AtsItemSearchRequest()
            {
                PageNumber = 1,
                PageSize = 20
            };
            var result = btsQueryController.GetFGAItemDetails(items);
            Asserts(result);
        }

        [Fact]

        public void GetDashboardSearchWithSKUFilter()
        {
            AtsItemSearchRequest items = new AtsItemSearchRequest()
            {
                Sku = "225-0716",
                PageNumber = 1,
                PageSize = 20
            };
            var result = btsQueryController.GetFGAItemDetails(items);
            Asserts(result);
        }

        [Fact]

        public void GetDashboardSearchWithPartFilter()
        {
            AtsItemSearchRequest items = new AtsItemSearchRequest()
            {
                Part = "VWN7F",
                PageNumber = 1,
                PageSize = 20
            };
            var result = btsQueryController.GetFGAItemDetails(items);
            Asserts(result);
        }

        [Fact]

        public void GetDashboardSearchWithSKUPartFilter()
        {
            AtsItemSearchRequest items = new AtsItemSearchRequest()
            {
                Sku = "225-0716",
                Part = "VWN7F",
                PageNumber = 1,
                PageSize = 20
            };
            var result = btsQueryController.GetFGAItemDetails(items);
            Asserts(result);

        }

        [Fact]

        public void GetDashboardSearchWithAllFilter()
        {
            AtsItemSearchRequest items = new AtsItemSearchRequest()
            {
                Sku = "225-0716",
                Part = "VWN7F",
                Type=-1,
                CountryId="30",
                CatalogGroupIds="",
                Region=3,
                StockStatus=5,
                CatalogId="15",
                IsContinueToSell=0,
                IsActive= "I",
                PageNumber = 1,
                PageSize = 20
            };
            var result = btsQueryController.GetFGAItemDetails(items);
            Asserts(result);

        }
        public void Asserts(Task<IActionResult> result)
        {
            Assert.NotNull(result);
        }

    }
}
