import { Component, OnInit, Input, TemplateRef, HostListener } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormsModule, NgForm, FormControl } from '@angular/forms';
import { ProductManagementService } from './product-management.service';
import { ApjAtsFacadeService } from '@App/shared/apj-ats-facade.service';
import { Global } from '@App/shared/global';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Action } from 'rxjs/internal/scheduler/Action';
import { LocalStorageService } from 'angular-2-local-storage';
import { MatDialog, MatTableDataSource, MatSlideToggleChange } from '@angular/material';
import { NotifierService } from 'angular-notifier';
import { productManagementReff, ProductCountry, ProductDetails, CountriesAndCatalogGroups, ProductCatalog } from './product-management.model';
import { DISABLED } from '@angular/forms/src/model';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
@Component({
  selector: 'app-product-management',
  templateUrl: './product-management.component.html',
  styleUrls: ['./product-management.component.css']
})
export class ProductManagementComponent implements OnInit {
  @Input() productManagementReff: productManagementReff;
  public modalRef: BsModalRef;

  ProductDetails: ProductDetails;
  productCountries: ProductCountry[];
  _ProductCountrys: ProductCountry[];
  productCatalogs: ProductCatalog[];

  ProductDetailsList: ProductDetails[];
  dataSourceProdInfo: MatTableDataSource<ProductDetails>;
  displayedColumnsProdInfo = ['sku', 'fga', 'productType', 'offer', 'name', 'description', 'active'];
  private notifier: NotifierService;
  RegionId: number;

  ProductInfoForm: FormGroup;
  ProductCountriesForm: FormGroup;
  ProductCountryForm: FormGroup;
  IsProdCountryunderCatalogGroup: boolean;
  userIsEmeaReadOnly: boolean = false; IsActiveEdit: boolean; IsActiveShow: boolean; IsprodInfoSeperateMessaging: boolean; IsAddProductCountryClicked: boolean; IsAddSDSEnabled: boolean = false;
  IsAddDisplayLowInventory: boolean = false; IsAddIncludePreCheckout: boolean = false; IsAddIncludePostCheckout: boolean = false; IsAddContinueToSell: boolean = false;
  indLoading: boolean = false; ErrorMsg: any; SuccessMsg: any; IsAddProductClicked: boolean = false; IsItemFound: boolean = false; IsProductInfoEdit: boolean = false;
  noRecordsFoundProductInfo: boolean = false; noRecordsFoundCountry: boolean = false; noRecordsFoundCatalog: boolean = false; IsAddActive: boolean = false;
  ModalName: string; countryModalName: string;
  ProductTypes: any; CountriesAndCatalogGroups: CountriesAndCatalogGroups[]; ProductCountryDefaults: any; AllRegions: any[] = [];
  productCountryId: number;
  IsSDSEnabled: boolean = false; IsDisplayLowInventory: boolean = false; IsIncludePreCheckout: boolean = false; IsIncludePostCheckout: boolean = false; IsContinueToSell: boolean = false;
  IsModalOpen: boolean = false; countryName: string;

  filteredCountrys: Observable<any[]>;
  //#region "Country variables"
  AddCountries: any[] = [];
  Countries: any[] = [];
  AddCatalogs: any[] = [];

  //#endregion
  //#region "catalog variables"
  ProductCatalogId: number;
  catalogModalName: string;
  ProductCatalogForm: FormGroup;
  IsProductCatalogListEdit: boolean;
  IsSalesViewVisibility: boolean;
  //#endregion
  constructor(private _ApjAtsFacadeService: ApjAtsFacadeService, public dialog: MatDialog, notifier: NotifierService, private _localStorageService: LocalStorageService
    , private modalService: BsModalService) {

    this.RegionId = this._localStorageService.get('selRegion');

    this.notifier = notifier;

    this.getCountriesAndCatalogGroups(this.RegionId);

  }
  private createForm() {
    this.ProductInfoForm = new FormGroup({
      txtEditFGA: new FormControl('', [Validators.required, Validators.max(250)]),
      ddlProductType: new FormControl(''),
      ddlEditProductType: new FormControl(''),
      txtEditOffer: new FormControl('', [Validators.required, Validators.max(250)]),
      txtEditBrand: new FormControl('', [Validators.required, Validators.max(250)]),
      txtEditDescription: new FormControl('', [Validators.required, Validators.max(250)]),
      swchShowAllowAutoXLT: new FormControl({ value: 'n/a', disabled: true }),
      swchEditAllowAutoXLT: new FormControl(''),

    });
    this.ProductCountriesForm = new FormGroup({
      chkSeperateMessagingWithCatalog: new FormControl({ value: 'n/a', disabled: true }),
      chkSeperateMessagingWithOutCatalog: new FormControl({ value: 'n/a', disabled: true })
    });
    this.ProductCountryForm = new FormGroup({
      ddlCountriesAndCatalogGroups: new FormControl('', [Validators.required]),
      swchAddSDSEnabled: new FormControl(''),
      txtAddLeadTime: new FormControl('', [Validators.required, Validators.max(999), Validators.min(1), Validators.pattern(Global.NUMBER_REGEX)]),
      txtAddExtendedLeadTime: new FormControl('', [Validators.required, Validators.max(999), Validators.min(1), Validators.pattern(Global.NUMBER_REGEX)]),
      swchAddDisplayLowInventory: new FormControl(''),
      swchAddIncludePreCheckout: new FormControl(''),
      swchAddIncludePostCheckout: new FormControl(''),
      swchAddContinueToSell: new FormControl(''),
      txtAddLow: new FormControl('', [Validators.required, Validators.max(10000), Validators.min(-10000), Validators.pattern(Global.NUMBER6_REGEX)]),
      txtAddSDS: new FormControl('', [Validators.required, Validators.max(10000), Validators.min(-10000), Validators.pattern(Global.NUMBER6_REGEX)]),
      txtAddOversell: new FormControl('', [Validators.required, Validators.max(10000), Validators.min(-10000), Validators.pattern(Global.NUMBER6_REGEX)]),
      txtAddOversold: new FormControl('', [Validators.required, Validators.max(10000), Validators.min(-10000), Validators.pattern(Global.NUMBER6_REGEX)]),

    });
    this.ProductCatalogForm = new FormGroup({
      ddlCountriesAndCatalogGroups: new FormControl('', [Validators.required]),
      ddlCatalogGroups: new FormControl('', [Validators.required]),
      swchSalesViewVisibility: new FormControl(''),
      txtQuote: new FormControl(''),
      txtOrderCode: new FormControl('')

    });
  }
  ngOnInit() {
    this.createForm();
    this.GetProductTypes();
    this.loadCountries(this.RegionId);

    this.GetProductDetails(this.productManagementReff.ProductId, this.RegionId);
    this.GetProductCountryDefaults();

    this.getAllRegions();
  }
  loadCountries(Id): void {
    this.indLoading = true;
    this._ApjAtsFacadeService.loadCountries(Id)
      .subscribe(countries => {
        this.Countries = countries;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }

  GetProductTypes(): void {
    this.indLoading = true;
    this._ApjAtsFacadeService.GetProductTypes()
      .subscribe(productTypes => {
        this.ProductTypes = productTypes;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }
  saveSkuInfo() {
    if (this.ProductInfoForm.valid) {
      this.ProductDetails.fga = this.ProductInfoForm.controls['txtEditFGA'].value;
      this.ProductDetails.productType = Number(this.ProductInfoForm.controls['ddlEditProductType'].value);
      this.ProductDetails.offer = this.ProductInfoForm.controls['txtEditOffer'].value;
      this.ProductDetails.brand = "";
      this.ProductDetails.name = this.ProductInfoForm.controls['txtEditBrand'].value;
      this.ProductDetails.description = this.ProductInfoForm.controls['txtEditDescription'].value;
      this.ProductDetails.active = this.IsActiveEdit;
      this.IsProductInfoEdit = false;
    }
    else {
      this.validateAllFormFields(this.ProductInfoForm);

    }
  }
  getCountriesAndCatalogGroups(regionId) {
    this.indLoading = true;
    this._ApjAtsFacadeService.getCountriesAndCatalogGroups(regionId)
      .subscribe(countriesAndCatalogGroups => {
        this.CountriesAndCatalogGroups = countriesAndCatalogGroups;
        //this.filteredCountrys = this.ProductCountryForm.controls['ddlCountriesAndCatalogGroups'].valueChanges
        //  .pipe(
        //  startWith(''),
        //  map(countryName => countryName? this.filterCountriesAndCatalogGroups(countryName):this.CountriesAndCatalogGroups)
        //);
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });

  }
  filterCountriesAndCatalogGroups(value: string): CountriesAndCatalogGroups[] {
    return value ? this.CountriesAndCatalogGroups.filter(s => s.countryName.toLowerCase().indexOf(value.toLowerCase()) === 0)
      : this.CountriesAndCatalogGroups;
    //const filterValue = value.toLowerCase();

    //return this.CountriesAndCatalogGroups.filter(country => country.countryName.toLowerCase().indexOf(filterValue) === 0);
  }

  displayFn(value): string {
    return value ? value.countryName : value;
  }

  GetProductDetails(productId, regionId) {
    this.indLoading = true;
    this._ApjAtsFacadeService.GetProductDetails(productId, regionId)
      .subscribe(productDetails => {
        this.ProductDetails = productDetails;
        if (this.ProductDetails.productType <= 0) {
          this.noRecordsFoundProductInfo = true;
        }
        else {
          this.IsItemFound = true;
        }
        this.productCountries = productDetails.productCountries;
        this.productCatalogs = productDetails.productCatalogs;
        if (this.productCountries.length <= 0) {
          this.noRecordsFoundCountry = true;
        }
        if (this.productCatalogs.length <= 0) {
          this.noRecordsFoundCatalog = true;
        }

        this.IsActiveEdit = this.ProductDetails.active;
        this.IsActiveShow = this.ProductDetails.active;
        (<FormControl>this.ProductInfoForm.controls['swchShowAllowAutoXLT'])
          .setValue(this.ProductDetails.active, { onlySelf: true });
        (<FormControl>this.ProductInfoForm.controls['ddlProductType'])
          .setValue(this.ProductDetails.productType, { onlySelf: true });
        this.dataSourceProdInfo = new MatTableDataSource(this.ProductDetailsList);

        if (this.productCountries != null && this.productCountries.length > 0) {
          this.AddCountries = [];
          for (let productCountry of this.productCountries) {
            var countryId = parseInt(productCountry.countryIds);
            for (let country of this.Countries) {
              if (countryId == country.id) {
                var catalogCountry = { "Id": country.id, "CountryName": country.countryName };
                this.AddCountries.push(catalogCountry);

                this.AddCatalogs = [];
                for (let region of this.AllRegions) {
                  if (countryId == region.countryID && !this.checkCatalogExists(region.countryID, region.id)) {
                    var catalog = { "Id": region.id, "CatalogName": region.name };
                    this.AddCatalogs.push(catalog);
                  }

                }

              }

            }
          }

        }

        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }

  //getRegionName(item) {
  //  return this.AllRegions.find(s => s.id == item.catalogID).name;
  //}
  getRegionName(item) {
    for (let region of this.AllRegions) {
      if (region.countryID == item.countryID && region.id == item.catalogID) {
        return region.name;
      }
    }
  }

  GetProductCountryDefaults() {
    this.indLoading = true;
    this._ApjAtsFacadeService.GetProductCountryDefaults()
      .subscribe(productCountryDefaults => {
        this.ProductCountryDefaults = productCountryDefaults;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }
  getAllRegions() {
    this.indLoading = true;
    this._ApjAtsFacadeService.getAllRegions()
      .subscribe(allRegions => {
        this.AllRegions = allRegions;
        this.indLoading = false;
      },
        error => { this.ErrorMsg = <any>error; this.indLoading = false; });
  }

  holisticSave() {
    this.IsModalOpen = false;
    this.removeAllCountries();
    if (this.ProductDetails.productCountries.length == 0) {
      this.notifier.notify('warning', 'Atleast one Country has to be associated to the Product. The operation will not continue.');
      return;
    }
    else if (!this.atleastOneCatalogExistForEachCountry()) {
      this.notifier.notify('warning', 'Atleast one Catalog has to be associated for each country. The operation will not continue.')
      return;
    }
    else if (this.ProductDetails.productCountries.length > 0) {
      var countries = '';
      var incorrectLTrangeCountries = '';
      var incorrectThresholdrangeCountries = '';
      this.ProductDetails.productCountries.forEach(function (productCountry) {
        if (Number(productCountry.low) > Number(productCountry.sds) && Number(productCountry.sds) > Number(productCountry.oversell) && Number(productCountry.oversell) > Number(productCountry.oversold)) { }
        else {
          if (countries == '')
            countries = productCountry.countryName;
          else
            countries = countries + ',' + productCountry.countryName;
        }
        if (Number(productCountry.leadTime) < 1 || Number(productCountry.leadTime) > 999 || Number(productCountry.extendedLeadTime) < 1 || Number(productCountry.extendedLeadTime) > 999) {
          if (incorrectLTrangeCountries == '')
            incorrectLTrangeCountries = productCountry.countryName;
          else
            incorrectLTrangeCountries = incorrectLTrangeCountries + ',' + productCountry.countryName;
        }
        if (Number(productCountry.low) < -10000 || Number(productCountry.low) > 100000 || Number(productCountry.sds) < -10000 || Number(productCountry.sds) > 100000 || Number(productCountry.oversell) < -10000 || Number(productCountry.oversell) > 100000 || Number(productCountry.oversold) < -10000 || Number(productCountry.oversold) > 100000) {
          if (incorrectThresholdrangeCountries == '')
            incorrectThresholdrangeCountries = productCountry.countryName;
          else
            incorrectThresholdrangeCountries = incorrectThresholdrangeCountries + ',' + productCountry.countryName;
        }
      });
      if (countries.length > 0)
        this.notifier.notify('warning', 'For Countries ' + countries + ' Values of Low, SDS, XLT and OOS should be in the order: Value of Low > Value of SDS > Value of XLT > Value of OOS');
      else if (incorrectLTrangeCountries.length > 0)
        this.notifier.notify('warning', 'For Countries ' + incorrectLTrangeCountries + ' Values of LeadTime and ExtentedLeadTime should be in the range 1 to 999');
      else if (incorrectThresholdrangeCountries.length > 0)
        this.notifier.notify('warning', 'For Countries ' + incorrectThresholdrangeCountries + ' Values of Low, Buffer, Oversell and Oversold Threshold should be in the range -10000 to 100000');
      else {
        //if (!this.ProductDetails.seperateMessaging) {
        //  if (this.ProductDetails.productCountries.length > 0) {
        //    var prodcountryItem = this.ProductDetails.productCountries.pop();
        //  }
        //}
        this.indLoading = true;
        this._ApjAtsFacadeService.updateProductInformation(this.ProductDetails)
          .subscribe(productDetails => {
            this.notifier.notify('success', 'Product Information updated successfully.');

            this.indLoading = false;
          },
            error => { this.ErrorMsg = <any>error; this.indLoading = false; });
      }

    }
  }
  atleastOneCatalogExistForEachCountry() {
    var numberOfCatalogs = 0;
    var totalCountriesCount = 0;
    for (var i = 0; i < this.productCountries.length; i++) {
      if (this.productCountries[i].countryIds !== undefined) {
        var paramCountries = this.productCountries[i].countryIds.split(',');
        numberOfCatalogs += paramCountries.length;
        for (var j = 0; j < paramCountries.length; j++) {
          var countryId = parseInt(paramCountries[j]);
          for (var k = 0; k < this.productCatalogs.length; k++) {
            if (countryId == this.productCatalogs[k].countryID) {
              totalCountriesCount += 1;
              break;
            }
          }
        }
      }
    }

    if (numberOfCatalogs == totalCountriesCount) {
      return true;
    }
    return false;
  }
  removeAllCountries() {
    let filteredCountries = this.ProductDetails.productCountries.filter(function (pc) {
      if (pc.countryName.toUpperCase() != "ALL COUNTRIES") {
        return pc;
      }
    });

    var filteredCatalogs = this.ProductDetails.productCatalogs.filter(function (pc) {
      if (pc.countryName.toUpperCase() != "ALL COUNTRIES") {
        return pc;
      }
    });

    this.ProductDetails.productCountries = filteredCountries;
    this.ProductDetails.productCatalogs = filteredCatalogs;
  }
  updateIsActive(event: MatSlideToggleChange) {
    this.IsActiveEdit = event.checked;
  }
  setSelected() {
    (<FormControl>this.ProductInfoForm.controls['txtEditFGA'])
      .setValue(this.ProductDetails.fga, { onlySelf: true });
    (<FormControl>this.ProductInfoForm.controls['txtEditOffer'])
      .setValue(this.ProductDetails.offer, { onlySelf: true });
    (<FormControl>this.ProductInfoForm.controls['txtEditBrand'])
      .setValue(this.ProductDetails.name, { onlySelf: true });
    (<FormControl>this.ProductInfoForm.controls['txtEditDescription'])
      .setValue(this.ProductDetails.description, { onlySelf: true });
    (<FormControl>this.ProductInfoForm.controls['swchEditAllowAutoXLT'])
      .setValue(this.ProductDetails.active, { onlySelf: true });
    this.IsActiveEdit = this.ProductDetails.active;
    (<FormControl>this.ProductInfoForm.controls['ddlEditProductType'])
      .setValue(this.ProductDetails.productType, { onlySelf: true });

  }
  saveEdit(ProductCountryForm, template: TemplateRef<any>) {
    if (this.ProductCountryForm.valid) {
      if (Number(this.ProductCountryForm.controls['txtAddLow'].value) > Number(this.ProductCountryForm.controls['txtAddSDS'].value)
        && Number(this.ProductCountryForm.controls['txtAddSDS'].value) > Number(this.ProductCountryForm.controls['txtAddOversell'].value)
        && Number(this.ProductCountryForm.controls['txtAddOversell'].value) > Number(this.ProductCountryForm.controls['txtAddOversold'].value)) {
        this.IsProductInfoEdit = false;
      }
      else {
        this.notifier.notify('warning', 'Values of Low, SDS, XLT and OOS should be in the order: Value of Low > Value of SDS > Value of XLT > Value of OOS');
        return false;
      }
      if (this.productCountryId) {

        //if (!this.ProductDetails.seperateMessaging) {
        let itemIndex = this.ProductDetails.productCountries.findIndex(item => item.countryID == this.productCountryId);
        this.productCountries[itemIndex].countryID = this.productCountryId;
        this.productCountries[itemIndex].countryIds = this.productCountryId.toString();
        this.productCountries[itemIndex].sdsEnabled = this.IsSDSEnabled;
        this.productCountries[itemIndex].leadTime = this.ProductCountryForm.controls['txtAddLeadTime'].value;
        this.productCountries[itemIndex].extendedLeadTime = this.ProductCountryForm.controls['txtAddExtendedLeadTime'].value;
        this.productCountries[itemIndex].displayLowInventory = this.IsDisplayLowInventory;
        this.productCountries[itemIndex].includePreCheckout = this.IsIncludePreCheckout;
        this.productCountries[itemIndex].includePostCheckout = this.IsIncludePostCheckout;
        this.productCountries[itemIndex].continueToSell = this.IsContinueToSell;//Boolean(this.ProductCountryForm.controls['swchAddSDSEnabled'].value);
        this.productCountries[itemIndex].sellActionOffline = null;
        this.productCountries[itemIndex].oversoldOffline = null;
        this.productCountries[itemIndex].catalogGroupId = null;

        this.productCountries[itemIndex].low = this.ProductCountryForm.controls['txtAddLow'].value;
        this.productCountries[itemIndex].sds = this.ProductCountryForm.controls['txtAddSDS'].value;
        this.productCountries[itemIndex].oversell = this.ProductCountryForm.controls['txtAddOversell'].value;
        this.productCountries[itemIndex].oversold = this.ProductCountryForm.controls['txtAddOversold'].value;

        this.ProductDetails.productCountries = this.productCountries;
        this.notifier.notify('success', 'Country details updated successfully');
        this.ProductCountryForm.reset();
        this.modalRef.hide();
        this.productCountryId = null;

        //}
      }
      else if (!this.productCountryId) {
        let catalogCountryBindingID;
        if (this.CountriesAndCatalogGroups && this.ProductCountryForm.controls['ddlCountriesAndCatalogGroups'].value) {
          let status: CountriesAndCatalogGroups = this.CountriesAndCatalogGroups.find(s => s.id == this.ProductCountryForm.controls['ddlCountriesAndCatalogGroups'].value);
          if (status)
            this.countryName = status.countryName;
          catalogCountryBindingID = status.catalogCountryBindingID;
        }
        let obj = new ProductCountry(this.ProductCountryForm.controls['ddlCountriesAndCatalogGroups'].value, this.countryName, this.IsContinueToSell, this.IsIncludePreCheckout, this.IsIncludePostCheckout,
          this.IsDisplayLowInventory, this.ProductCountryForm.controls['txtAddLeadTime'].value, this.ProductCountryForm.controls['txtAddExtendedLeadTime'].value,
          this.ProductCountryForm.controls['txtAddLow'].value, this.ProductCountryForm.controls['txtAddSDS'].value, this.ProductCountryForm.controls['txtAddOversell'].value,
          this.ProductCountryForm.controls['txtAddOversold'].value, this.IsSDSEnabled, null, null, null, this.ProductCountryForm.controls['ddlCountriesAndCatalogGroups'].value, catalogCountryBindingID);

        for (var i = 0; i < this.productCountries.length; i++) {
          if (Number(this.productCountries[i].countryID) === Number(this.ProductCountryForm.controls['ddlCountriesAndCatalogGroups'].value)) {
            this.notifier.notify('warning', 'The selected Country/Catalog Group is already mapped against the Product.');
            return;
          }
        }
        this.productCountries.unshift(obj);
        this.ProductDetails.productCountries = this.productCountries;
        this.noRecordsFoundCountry = false;
        this.notifier.notify('success', 'Country details added successfully');
        this.modalRef.hide();

      }
      if (this.productCountries != null && this.productCountries.length > 0) {
        this.AddCountries = [];
        for (let productCountry of this.productCountries) {
          var countryId = parseInt(productCountry.countryIds);
          for (let country of this.Countries) {
            if (countryId == country.id) {
              var catalogCountry = { "Id": country.id, "CountryName": country.countryName };
              this.AddCountries.push(catalogCountry);
            }

          }
        }
      }
    }
    else {
      this.validateAllFormFields(this.ProductCountryForm);

    }
  }
  deleteProductCountry(item) {
    const index: number = this.productCountries.indexOf(item);
    if (index !== -1) {
      this.productCountries.splice(index, 1);
    }

    var catalogCountry = { "Id": item.countryID, "CountryName": item.countryName };
    const catalogCountryIndex: number = this.AddCountries.indexOf(catalogCountry);
    if (catalogCountryIndex !== -1) {
      this.AddCountries.splice(catalogCountryIndex, 1);
    }

  }
  validateProductCountry(seperateMessaging) {
    var shared = true;
    if (!seperateMessaging) {
      if (this.ProductDetails.productCountries.length > 0) {
        var productCountrys = this.ProductDetails.productCountries[0];
        this.ProductDetails.productCountries.forEach(function (productCountry) {
          if (productCountry.sdsEnabled == productCountrys.sdsEnabled && productCountry.leadTime == productCountrys.leadTime && productCountry.extendedLeadTime == productCountrys.extendedLeadTime && productCountry.displayLowInventory == productCountrys.displayLowInventory && productCountry.includePreCheckout == productCountrys.includePreCheckout && productCountry.includePostCheckout == productCountrys.includePostCheckout && productCountry.continueToSell == productCountrys.continueToSell && productCountry.low == productCountrys.low && productCountry.sds == productCountrys.sds && productCountry.oversell == productCountrys.oversell && productCountry.oversold == productCountrys.oversold) {
          }
          else {
            shared = false;
          }
        });
        if (!shared) {
          this.ProductDetails.seperateMessaging = true;
          this.notifier.notify('warning', 'All the Product Countries should have same values for flags and fields in case of Shared messaging');
          return shared;
        }
      }
    }
  }
  CatalogCountryChanged(e) {
    this.AddCatalogs = [];
    var countryId = parseInt(e);
    for (let region of this.AllRegions) {
      if (countryId == region.countryID && !this.checkCatalogExists(region.countryID, region.id)) {
        var catalog = { "Id": region.id, "CatalogName": region.name };
        this.AddCatalogs.push(catalog);
      }

    }
  }
  checkCatalogExists(countryId, catalogId) {
    for (var i = 0; i < this.productCatalogs.length; i++) {
      if (this.productCatalogs[i].countryID == countryId && this.productCatalogs[i].catalogID == catalogId) {
        return true;
      }
    }
    return false;
  }
  updateIsSDSEnabled(event: MatSlideToggleChange) {
    this.IsSDSEnabled = event.checked;
  }
  updateIsDisplayLowInventory(event: MatSlideToggleChange) {
    this.IsDisplayLowInventory = event.checked;
  }
  updateIsIncludePreCheckout(event: MatSlideToggleChange) {
    this.IsIncludePreCheckout = event.checked;
  }
  updateIsIncludePostCheckout(event: MatSlideToggleChange) {
    this.IsIncludePostCheckout = event.checked;
  }
  updateIsContinueToSell(event: MatSlideToggleChange) {
    this.IsContinueToSell = event.checked;
  }
  addProductCountry() {
    this.IsAddProductCountryClicked = true;
  }
  cancelAddProductCountry() {
    this.IsAddProductCountryClicked = false;
    this.ProductCountryForm.reset();
    this.productCountryId = null;
    this.modalRef.hide();
    this.IsModalOpen = false;

  }
  editCountryDetails(item, template: TemplateRef<any>) {
    this.ProductCountryForm.reset();
    this.productCountryId = item.countryIds;
    (<FormControl>this.ProductCountryForm.controls['ddlCountriesAndCatalogGroups'])
      .disable();
    (<FormControl>this.ProductCountryForm.controls['ddlCountriesAndCatalogGroups'])
      .setValue(item.countryIds);
    (<FormControl>this.ProductCountryForm.controls['ddlCountriesAndCatalogGroups'])
      .clearValidators();
    (<FormControl>this.ProductCountryForm.controls['swchAddSDSEnabled'])
      .setValue(item.SDSEnabled);
    this.IsSDSEnabled = item.sdsEnabled;
    (<FormControl>this.ProductCountryForm.controls['txtAddLeadTime'])
      .setValue(item.leadTime);
    (<FormControl>this.ProductCountryForm.controls['txtAddExtendedLeadTime'])
      .setValue(item.extendedLeadTime);
    (<FormControl>this.ProductCountryForm.controls['swchAddDisplayLowInventory'])
      .setValue(item.displayLowInventory);
    this.IsDisplayLowInventory = item.displayLowInventory;
    (<FormControl>this.ProductCountryForm.controls['swchAddIncludePreCheckout'])
      .setValue(item.includePreCheckout);
    this.IsIncludePreCheckout = item.includePreCheckout;
    (<FormControl>this.ProductCountryForm.controls['swchAddIncludePostCheckout'])
      .setValue(item.includePostCheckout);
    this.IsAddIncludePostCheckout = item.includePostCheckout;
    (<FormControl>this.ProductCountryForm.controls['swchAddContinueToSell'])
      .setValue(item.continueToSell);
    this.IsContinueToSell = item.continueToSell;
    (<FormControl>this.ProductCountryForm.controls['txtAddLow'])
      .setValue(item.low);
    (<FormControl>this.ProductCountryForm.controls['txtAddSDS'])
      .setValue(item.sds);
    (<FormControl>this.ProductCountryForm.controls['txtAddOversell'])
      .setValue(item.oversell);
    (<FormControl>this.ProductCountryForm.controls['txtAddOversold'])
      .setValue(item.oversold);
    this.ProductCountryForm.updateValueAndValidity();
    this.countryModalName = "Country Details";
    this.modalRef = this.modalService.show(template, Object.assign({}, this.config, { class: 'gray modal-lg' }));


  }
  AddCountryModal(template: TemplateRef<any>) {
    this.countryModalName = "Country Details";
    this.ProductCountryForm.reset();
    (<FormControl>this.ProductCountryForm.controls['ddlCountriesAndCatalogGroups'])
      .enable({ onlySelf: true });
    this.IsSDSEnabled = this.ProductCountryDefaults.sdsEnabled;
    (<FormControl>this.ProductCountryForm.controls['txtAddLeadTime'])
      .setValue(this.ProductCountryDefaults.leadTime);
    (<FormControl>this.ProductCountryForm.controls['txtAddExtendedLeadTime'])
      .setValue(this.ProductCountryDefaults.extendedLeadTime);
    (<FormControl>this.ProductCountryForm.controls['swchAddDisplayLowInventory'])
      .setValue(this.ProductCountryDefaults.displayLowInventory);
    this.IsDisplayLowInventory = this.ProductCountryDefaults.displayLowInventory;
    (<FormControl>this.ProductCountryForm.controls['swchAddIncludePreCheckout'])
      .setValue(this.ProductCountryDefaults.includePreCheckout);
    this.IsIncludePreCheckout = this.ProductCountryDefaults.includePreCheckout;
    (<FormControl>this.ProductCountryForm.controls['swchAddIncludePostCheckout'])
      .setValue(this.ProductCountryDefaults.includePostCheckout);
    this.IsAddIncludePostCheckout = this.ProductCountryDefaults.includePostCheckout;
    (<FormControl>this.ProductCountryForm.controls['swchAddContinueToSell'])
      .setValue(this.ProductCountryDefaults.continueToSell);
    this.IsContinueToSell = this.ProductCountryDefaults.continueToSell;
    (<FormControl>this.ProductCountryForm.controls['txtAddLow'])
      .setValue(this.ProductCountryDefaults.low);
    (<FormControl>this.ProductCountryForm.controls['txtAddSDS'])
      .setValue(this.ProductCountryDefaults.sds);
    (<FormControl>this.ProductCountryForm.controls['txtAddOversell'])
      .setValue(this.ProductCountryDefaults.oversell);
    (<FormControl>this.ProductCountryForm.controls['txtAddOversold'])
      .setValue(this.ProductCountryDefaults.oversold);
    this.modalRef = this.modalService.show(template, Object.assign({}, this.config, { class: 'gray modal-lg' }));
  }
  public config = {
    animated: true,
    keyboard: false,
    backdrop: 'static',
    ignoreBackdropClick: true
  };
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  //#region "Catalog "
  updateIsSalesViewVisibility(event: MatSlideToggleChange) {
    this.IsSalesViewVisibility = event.checked;
  }
  deleteProductCatalog(item) {
    const index: number = this.productCatalogs.indexOf(item);
    if (index !== -1) {
      this.productCatalogs.splice(index, 1);
    }

    var catalog = { "Id": item.id, "CatalogName": item.name };
    const catalogIndex: number = this.AddCountries.indexOf(catalog);
    if (catalogIndex !== -1) {
      this.AddCatalogs.splice(catalogIndex, 1);
    }
    if (this.productCountries != null && this.productCountries.length > 0) {
      this.AddCountries = [];
      for (let productCountry of this.productCountries) {
        var countryId = parseInt(productCountry.countryIds);
        for (let country of this.Countries) {
          if (countryId == country.id) {
            var catalogCountry = { "Id": country.id, "CountryName": country.countryName };
            this.AddCountries.push(catalogCountry);
          }

        }
      }
    }

  }
  cancelAddProductCatalog() {
    this.ProductCatalogForm.reset();
    this.modalRef.hide();
    this.ProductCatalogId = null;

  }
  AddCatalogModal(template: TemplateRef<any>) {
    this.countryModalName = "Catalog Details";
    this.ProductCatalogForm.reset();
    (<FormControl>this.ProductCatalogForm.controls['ddlCountriesAndCatalogGroups'])
      .enable({ onlySelf: true });
    (<FormControl>this.ProductCatalogForm.controls['ddlCatalogGroups'])
      .enable({ onlySelf: true });
    if (this.productCountries != null && this.productCountries.length > 0) {
      this.AddCountries = [];
      for (let productCountry of this.productCountries) {
        var countryId = parseInt(productCountry.countryIds);
        for (let country of this.Countries) {
          if (countryId == country.id) {
            var catalogCountry = { "Id": country.id, "CountryName": country.countryName };
            this.AddCountries.push(catalogCountry);
          }

        }
      }
    }

    this.modalRef = this.modalService.show(template, Object.assign({}, this.config, { class: 'gray modal-lg' }));
  }
  editCatalogDetails(item, template: TemplateRef<any>) {
    this.ProductCatalogForm.reset();
    this.productCountryId = item.countryIds;
    this.ProductCatalogId = item.catalogID;
    (<FormControl>this.ProductCatalogForm.controls['ddlCountriesAndCatalogGroups'])
      .setValue(String(item.countryID), { onlySelf: true });
    (<FormControl>this.ProductCatalogForm.controls['ddlCountriesAndCatalogGroups'])
      .disable({ onlySelf: true });
    (<FormControl>this.ProductCatalogForm.controls['ddlCountriesAndCatalogGroups'])
      .untouched;
    (<FormControl>this.ProductCatalogForm.controls['ddlCatalogGroups'])
      .setValue(item.catalogID, { onlySelf: true });
    (<FormControl>this.ProductCatalogForm.controls['ddlCatalogGroups'])
      .disable({ onlySelf: true });
    (<FormControl>this.ProductCatalogForm.controls['ddlCatalogGroups'])
      .untouched;
    (<FormControl>this.ProductCatalogForm.controls['ddlCatalogGroups'])
      .markAsUntouched;


    (<FormControl>this.ProductCatalogForm.controls['swchSalesViewVisibility'])
      .setValue(item.salesViewVisibility);
    this.IsSalesViewVisibility = item.salesViewVisibility;
    (<FormControl>this.ProductCatalogForm.controls['txtQuote'])
      .setValue(item.eQuote);
    (<FormControl>this.ProductCatalogForm.controls['txtOrderCode'])
      .setValue(item.orderQuote);
    this.ProductCatalogForm.updateValueAndValidity();
    this.ProductCatalogForm.markAsUntouched;
    this.catalogModalName = "Catalog Details";
    this.modalRef = this.modalService.show(template, Object.assign({}, this.config, { class: 'gray modal-lg' }));


  }
  AddProductCatalog() {
    if (this.ProductCatalogForm.valid) {
      if (this.ProductCatalogId) {
        let itemIndex = this.ProductDetails.productCatalogs.findIndex(item => item.catalogID == this.ProductCatalogId);
        this.productCatalogs[itemIndex].salesViewVisibility = this.IsSalesViewVisibility;
        this.productCatalogs[itemIndex].eQuote = this.ProductCatalogForm.controls['txtQuote'].value;
        this.productCatalogs[itemIndex].orderQuote = this.ProductCatalogForm.controls['txtOrderCode'].value;
        this.ProductDetails.productCatalogs = this.productCatalogs;
        this.notifier.notify('success', 'Catalog details updated successfully');
        this.ProductCatalogForm.reset();
        this.modalRef.hide();
        this.ProductCatalogId = null;

      }
      else {
        let countryName: string;
        if (this.CountriesAndCatalogGroups && this.ProductCatalogForm.controls['ddlCountriesAndCatalogGroups'].value) {
          let status: CountriesAndCatalogGroups = this.CountriesAndCatalogGroups.find(s => s.id == this.ProductCatalogForm.controls['ddlCountriesAndCatalogGroups'].value);
          if (status)
            this.countryName = status.countryName;
        }
        let objCatalog = new ProductCatalog(this.ProductCatalogForm.controls['ddlCountriesAndCatalogGroups'].value, this.countryName,
          this.ProductCatalogForm.controls['ddlCatalogGroups'].value, this.IsSalesViewVisibility, this.ProductCatalogForm.controls['txtQuote'].value,
          this.ProductCatalogForm.controls['txtOrderCode'].value);
        //for (var i = 0; i < this.productCatalogs.length; i++) {
        //  if (Number(this.productCatalogs[i].countryID) === Number(this.ProductCatalogForm.controls['ddlCountriesAndCatalogGroups'].value)) {
        //    this.notifier.notify('warning', 'The selected Country/Catalog Group is already mapped against the Product.');
        //    return;
        //  }
        //}
        var filteredCatalogs = this.productCatalogs.filter(function (pc) {
          if (pc.countryName.toUpperCase() != "ALL COUNTRIES") {
            return pc;
          }
        });

        this.productCatalogs = filteredCatalogs;

        this.productCatalogs.unshift(objCatalog);
        this.ProductDetails.productCatalogs = this.productCatalogs;

        this.noRecordsFoundCatalog = false;
        this.notifier.notify('success', 'Country details added successfully');
        this.modalRef.hide();

      }
    }
    else {
      this.validateAllFormFields(this.ProductCatalogForm);

    }
  }
  //#endregion
}
