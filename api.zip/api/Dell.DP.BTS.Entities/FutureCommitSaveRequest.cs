﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class FutureCommitSaveRequest
    {
        public Guid? ReservationId { get; set; }
        public int? Status { get; set; }
        public DateTime? ReleaseDate { get; set; }
        public string ReleaseDateStr { get; set; }
        public bool? OverrideScdh { get; set; }
    }
}
