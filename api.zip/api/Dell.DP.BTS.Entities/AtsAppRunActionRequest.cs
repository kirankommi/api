﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    [ExcludeFromCodeCoverage]
    public class AtsAppRunActionRequest
    {
        public string JobName { get; set; }
        public string UserName { get; set; }
        public string Operation { get; set; }
    }
}
