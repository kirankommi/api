﻿using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    
    public class InventorySiteStatusUnitTest : UnitTestInitializer
    {

        [Fact]
        public void GetInventorySiteStatusShouldReturnOKResult()
        {
            var productCountryId = 5988;
            var result = btsQueryController.GetInventoryStatus(productCountryId);
            Assert.NotNull(result);
        }
    }
}
