﻿using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    /// <summary>
    /// Summary description for ProductConfigurationUnitTest
    /// </summary>
    
    public class ProductConfigurationUnitTest:UnitTestInitializer
    {


        [Fact]
        public void GetProductConfigurationDataShouldReturnOKResult()
        {
            var result = btsQueryController.GetProductConfiguration();
            Assert.NotNull(result);
        }
    }
}
