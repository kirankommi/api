import { Injectable } from '@angular/core';
import {DataservicesProvider} from '@Dataservice/dataservices/dataservices';
import { ApjAtsCountry } from './apj-ats-country.model';
import { environment } from '@Environments/environment';

@Injectable({
    providedIn: 'root'  
})
  export class ApjAtsCountryService {

    constructor(private _DataservicesProvider:DataservicesProvider ) {
    }

    getCountries (selRegion) {
      return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getCountries/' + selRegion);
    }

    getLocationCode(selRegion){
      return this._DataservicesProvider.getData(environment.ApjEmeaAtsApiUrl + 'getLocationCode/'+selRegion)
    }

    updateCountry (ApjAtsCountry:ApjAtsCountry) {
      return this._DataservicesProvider.PostData(environment.ApjEmeaAtsApiUrl + 'command/updateCountry', ApjAtsCountry);
    }
  }
