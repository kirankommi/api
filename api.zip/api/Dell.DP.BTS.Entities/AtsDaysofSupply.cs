﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsDaysofSupply
    {
        public string TimeFrame { get; set; }
        public int Sales { get; set; }
        public double DSI { get; set; }
    }
}
