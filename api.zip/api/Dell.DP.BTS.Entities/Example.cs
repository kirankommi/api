﻿using System;

namespace Dell.DP.BTS.Entities
{
    public class Example
    {
        public Context Context { get; set; }
        public bool IsActive { get; set; }
    }
}
