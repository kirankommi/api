﻿using Dell.DP.BTS.Entities;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace Dell.DP.BTS.API.Filters
{
    /// <summary>
    /// This class provides Context object input request rules
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class ExampleFilter : AbstractValidator<Example>
    {
        public ExampleFilter()
        {
            RuleFor(crf => crf.Context).NotEmpty().WithMessage("Context is mandatory and should not be null or empty.");
            RuleFor(crf => crf.Context).SetValidator(new ContextFilter());
            RuleFor(crf => crf.IsActive).NotEmpty().WithMessage("IsActive is mandatory and should not be null or empty.");
        }
    }
}
