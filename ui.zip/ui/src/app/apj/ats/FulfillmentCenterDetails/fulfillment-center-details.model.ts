export class FulfillmentCenterData {
  siteCode: string;
  id: string;
  siteName: string;
  countryId: string;
  oldCountryId: string;
  sequence: string;
  isActive: string;
  productCountryId: string;
  updatedOn: string;
  createdOn: string;
}
