﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class OrderDetailsSearchResponse
    {
        public int? ProductTypeId { get; set; }
        public string ProductType { get; set; }
        public int? CountryId { get; set; }
        public string Country { get; set; }
        public int? SiteId { get; set; }
        public string SiteCode { get; set; }
        public string SiteName { get; set; }
        public string SKU { get; set; }
        public string FGA { get; set; }
        public long? OrderNumber { get; set;}
        public int? OrderQuantity { get; set; }
        public int? StatusAge { get; set; }
    }
}
