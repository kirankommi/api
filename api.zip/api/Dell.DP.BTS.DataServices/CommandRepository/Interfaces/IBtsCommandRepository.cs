﻿using Dell.DP.BTS.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.DataServices.CommandRepository.Interfaces
{
    public interface IBtsCommandRepository
    {
        DbCommandResult DbCommandResult { get;}
        int UpdateCatalog(AtsCatalog atsCatalog);
        void DeleteCatalog(AtsCatalog Item);
        int UpdateCountry(AtsCountry atsCountry);
        int UpdateApplicationConfiguration(AtsApplicationConfiguration Item);
        int UpdateProductConfiguration(AtsProductConfiguration productConfig);
        void UpdateProductInformation(AtsProductInfoAddUpdateRequest prodRequest);
        int UpdateContinueToSell(AtsItemDetail atsItemDetail);
        int UpdateDisplayLowInventory(AtsItemDetail atsItemDetail);
        int UpdateIsActive(AtsItemDetail atsItemDetail);
        int UpdateLeadTime(AtsItemDetail AtsDetail);
        int UpdateFulfillmentLocation(List<AtsSite> sites);
        int UpdateFulfillmentLocations(AtsSite sites);
        int MarkAsFulfill(List<AtsCommitDetail> Items);
        int CancelReservation(List<AtsCommitDetail> Items);
        int UpdateThreshold(AtsItemDetail AtsDetail);
    }
}
