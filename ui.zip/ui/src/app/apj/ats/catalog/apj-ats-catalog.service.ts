import { Injectable } from '@angular/core';
import {DataservicesProvider} from '@Dataservice/dataservices/dataservices';
import { environment } from '@Environments/environment';

@Injectable({
    providedIn: 'root'  
})
export class ApjAtsCatalogService {

  constructor(private _DataservicesProvider:DataservicesProvider ) {
  }

  getCatalogs (data) {
    return this._DataservicesProvider.PostData(environment.ApjEmeaAtsApiUrl + 'getCatalogs/', data);
  }

  UpdateCatalog(atsCatalog) {
    return this._DataservicesProvider.PostData(environment.ApjEmeaAtsApiUrl + 'command/UpdateCatalog', atsCatalog);
  }

  DeleteCatalog(atsCatalog) {
    return this._DataservicesProvider.PostData(environment.ApjEmeaAtsApiUrl + 'command/DeleteCatalog', atsCatalog);
  }
}
