export class AgedReportRequest {
  RegionId: number;
  CountryIds: string;
  SiteIds: string;
  ProductTypeIds: string;
  Parts: string;
  StatusAge: number;
  PageNumber: number;
  PageSize: number;
}
export interface ReportData {

  ProductType: string;
  Country: string;
  SiteCode: string;
  SiteName: string;
  SKU: string;
  FGA: string;
  OrderQuantity: string;
  OrderNumber: string;
  StatusAge: string;
}
export interface ExportReportData {

  productType: string;
  country: string;
  siteCode: string;
  siteName: string;
  sku: string;
  fga: string;
  orderQuantity: string;
  orderNumber: string;
  statusAge: string;
}

