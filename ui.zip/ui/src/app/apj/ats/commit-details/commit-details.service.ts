import { Injectable } from '@angular/core';
import { DataservicesProvider } from '@Dataservice/dataservices/dataservices';
import { Global } from '@App/shared/global';
import { Observable } from 'rxjs/Observable';
import { AtsCommitDetail } from './commit-details.model';

@Injectable({
  providedIn: 'root'
})
export class AtsCommitService {

  constructor(private _DataservicesProvider: DataservicesProvider) {
  }

  getCommitDetails(productCountryId): Observable<AtsCommitDetail[]> {
    return this._DataservicesProvider.getData(Global.ApjEmeaAtsApiUrl + 'getatscommitdetails/' + productCountryId);
  }

  exportCommitDetails(productCountryId): Observable<AtsCommitDetail[]> {
    return this._DataservicesProvider.getData(Global.ApjEmeaAtsApiUrl + 'exportatscommitdetails/' + productCountryId);
  }

  cancelCommitOrder(postData): Observable<AtsCommitDetail[]> {
    return this._DataservicesProvider.PostDataWithHeader(Global.ApjEmeaAtsApiUrl + 'command/cancelCommitOrder/', postData);
  }

  markAsFulfill(postData): Observable<AtsCommitDetail[]> {
    return this._DataservicesProvider.PostDataWithHeader(Global.ApjEmeaAtsApiUrl + 'command/updateMarkAsFulfill/', postData);
  }

  //getLocationCode(selRegion) {
  //  return this._DataservicesProvider.getData(Global.ApjEmeaAtsApiUrl + 'getLocationCode/' + selRegion)
  //}

  //updateCountry(ApjAtsCountry: ApjAtsCountry) {
  //  return this._DataservicesProvider.PostData(Global.ApjEmeaAtsApiUrl + 'command/updateCountry', ApjAtsCountry);
  //}
}
