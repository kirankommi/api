﻿using Dell.DP.BTS.Entities;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace Dell.DP.BTS.API.Filters
{
    /// <summary>
    /// This class provides Context object input request rules
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class ContextFilter : AbstractValidator<Context>
    {
        /// <summary>
        /// It has Context object attributes rules
        /// </summary>
        public ContextFilter()
        {
            RuleFor(crf => crf.RegionName).NotEmpty().WithMessage("RegionName is mandatory and should not be null or empty or zero.");
            RuleFor(crf => crf.RegionId).NotEmpty().WithMessage("RegionId is mandatory and should not be null or empty.");
        }
    }
}
