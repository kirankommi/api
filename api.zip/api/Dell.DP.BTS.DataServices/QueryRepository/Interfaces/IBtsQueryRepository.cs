﻿using Dell.DP.BTS.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.DataServices.QueryRepository.Interfaces
{
    public interface IBtsQueryRepository
    {
        Task<IEnumerable<AtsDataRefresh>> GetAtsItemRefreshDetail(int ProductCountryId);
        Task<IEnumerable<AtsStatusHistory>> GetAtsStatusHistory(int ProductCountryId);
        Task<IEnumerable<AtsLeadTimeHistory>> GetLeadTimeHistory(int ProductCountryId);
        Task<IEnumerable<AtsItemDetail>> GetAtsItemDetail(int ProductCountryId);
        Task<IEnumerable<AtsDaysofSupply>> GetDaysofSupply(int ProductCountryId);
        Task<List<AtsItem>> GetFGAItemExportDetails(AtsItemSearchRequest Item);
        Task<AtsFgaItemLists> GetFGAItemDetails(AtsItemSearchRequest Item);
        Task<IEnumerable<InventryStatus>> GetStockStatus();
        Task<IEnumerable<AtsCountry>> GetCountriesAndCatalogGroups(int regionId);
        Task<Dictionary<string, int>> GetCountryUsageDetail(int id);
        Task<IEnumerable<AtsItem>> GetCatalogGroup(int regionId);
        Task<IEnumerable<AtsSite>> GetFulfillmentLocation(int regionId);
        Task<AtsProductCountry> GetProductCountryDefaults();
        IEnumerable<AtsProdType> GetProductTypes();
        Task<IEnumerable<AtsBrand>> GetBrands(Int32 productlineId);
        Task<IEnumerable<AtsProductInfo>> GetProductLines(Int32 catalogId);
        Task<IEnumerable<AtsSite>> GetProductFulfillmentLocation(int ProductCountryId, int Region);
        Task<IEnumerable<RegionItem>> GetAllRegions();
        Task<IEnumerable<AtsCountry>> GetCountries(int regionId);
        Task<AtsProductInfo> GetProductInformation(int productID, int regionId);
        Task<IEnumerable<int>> GetDefaultCatalog(int CountryId);
        Task<IEnumerable<DefaultCatalogRequest>> GetDefaultCatalogs(List<int> CountryIds);
        Task<IEnumerable<AtsCatalog>> GetCatalog(AtsCatalog Item);
        Task<IEnumerable<AtsCatalog>> GetCatalogs(AtsCatalog Item);
        Task<IEnumerable<AtsApplication>> GetApplications();
        Task<AtsAppConfigList> GetApplicationConfigurations(AtsAppConfigRequest appConfigReq);
        Task<AtsAppConfigList> GetApplicationRuleConfigurations(AtsAppConfigRequest appConfigReq);
        Task<IEnumerable<AtsCommitDetail>> GetCommitDetail(int ProductCountryId);
        Task<IEnumerable<AtsJobTransactionStatus>> GetTransactionDetails(int regionId);
        Task<IEnumerable<AtsJobDetails>> GetJobDetails(int regionId);
        Task<IEnumerable<AtsItemSiteInventory>> GetInventoryStatus(int ProductCountryId);
        Task<AtsProductConfiguration> GetProductConfiguration();
        Task<InTransitLists> GetInTransit(AtsInTransitSearchRequest Item);
        Task<OrderDetailsSearchResultList> GetOrderDetails(OrderDetailsSearchRequest request);
        Task<IEnumerable<OrderDetailsSearchResponse>> GetOrderExportDetails(OrderDetailsSearchRequest request);
        Task<IEnumerable<InTransit>> GetInTransitExport(AtsInTransitSearchRequest Item);
        Task<CommitCalloutDetailResponse> GetCommitCalloutDetails(CommitFalloutRequest request);
        Task<IEnumerable<CommitCalloutDetail>> GetCommitCalloutExportDetails(CommitFalloutRequest request);
    }
}
