import { Component, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import {FormBuilder, FormGroup, Validators, FormsModule, NgForm} from '@angular/forms';
import { ApjAtsFacadeService } from '@App/shared/apj-ats-facade.service';
import { Applications, Filter, Configurations, AtsApplicationConfigurationList, PostData } from './apj-ats-configmgmt.model';
import { Global } from '@App/shared/global';
import {MatSnackBar} from '@angular/material/snack-bar';
import { Action } from 'rxjs/internal/scheduler/Action';
import { LocalStorageService } from 'angular-2-local-storage';
import { NotifierService } from 'angular-notifier';
import { NgModel } from '@angular/forms';

@Component({
  selector: 'app-apj-ats-configmgmt',
  templateUrl: './apj-ats-configmgmt.component.html',
  styleUrls: ['./apj-ats-configmgmt.component.css'],
})

export class ApjAtsConfigMgmtComponent {
  apjAtsConfigMgmtForm: FormGroup;
  applications: Applications[];
  filter: Filter = new Filter();
  configurations: Configurations;
  atsApplicationConfigurationList: AtsApplicationConfigurationList[];
  configurationData: Configurations;
  configurationList: AtsApplicationConfigurationList[];
  postData: PostData = new PostData()
  indLoading: boolean = false;
  addNewRow: boolean = false;
  displayedColumns = ['Application', 'ConfigurationName', 'ConfigurationValue', 'Status', 'Action'];
  dataSource: MatTableDataSource<AtsApplicationConfigurationList>;
  appArray: any[];
  configArray: any[];
  appselected: string = '';
  configSelected: string = '';
  configValuesSelected: string = '';
  hasRecords: boolean = false;
  selectedApps: any[] = [];
  selectedConfigNames: any[] = [];
  selectedConfigValues: any[] = [];
  configValueArray: any[];
  //@ViewChild(MatPaginator) paginator: MatPaginator;
  private paginator: MatPaginator;
  @ViewChild(MatPaginator) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    this.dataSource.paginator = this.paginator;
  }
  private readonly notifier: NotifierService;

  constructor(private fb: FormBuilder,
    private _ApjAtsFacadeService:ApjAtsFacadeService,
    private _snackBar: MatSnackBar,
    private _localStorageService: LocalStorageService,
    notifierService: NotifierService
  ) {
      // To initialize FormGroup , Validators.required 
    this.apjAtsConfigMgmtForm = fb.group({
      'ddlAppName': [null],
      'ddlConfigName': [null],
      'ddlConfigValue': [null],
      'ddlStatus': [null],
      'txtConfigValue': [null],
      'chkStatus': [null],
      'chkStatusNonEdit': [null],
      'txtConfigName': [null],
      'ddlTblAppName': [null]
    });
    this.notifier = notifierService;
  }

  ngOnInit(){
    this.init();
  }

  init() {
    this.indLoading = true;
      
    this._ApjAtsFacadeService.getApplications()
    .subscribe(data => {
      if (data.length > 0) {
        this.applications = data;
      }
      else {
        this.applications = [];
      }
      this.indLoading = false;
    },
    error => {
      this.notifier.notify('error', 'Error while fetching application list');
      this.indLoading = false;
    });
  }

  getConfigurations() {
    this.indLoading = true;
    this.appArray = this.apjAtsConfigMgmtForm.get('ddlAppName').value;
    this.appselected = "";
    this.appArray.forEach(apparr => {
      this.appselected = this.appselected.concat(apparr.toString() + ",");
    });

    this.filter.ApplicationIds = this.appselected;
    this.filter.ConfigIDs = null;
    this.filter.ConfigValues = null;
    this.filter.PageNumber = -1;
    this.filter.PageSize = 500;

    this.configurations = null;
    this.atsApplicationConfigurationList = [];
    this.apjAtsConfigMgmtForm.get('ddlConfigValue').setValue([]);
    this.apjAtsConfigMgmtForm.get('ddlConfigName').setValue([]);

    this._ApjAtsFacadeService.getApplicationConfigurations(this.filter)
    .subscribe(data => {
      this.configurations = data;
      this.atsApplicationConfigurationList = this.configurations.atsApplicationConfigurationList;
      this.indLoading = false;
    },
    error => {
      this.notifier.notify('error', 'Error while fetching configuration list');
      this.indLoading = false;
    });
  }

  search() {
    if (this.appselected == undefined
      || this.appselected == ''
      || this.appselected == null) {
      this.notifier.notify('error', 'Please select application');
      return;
    }
    this.indLoading = true;
    this.addNewRow = false;

    this.configArray = this.apjAtsConfigMgmtForm.get('ddlConfigName').value;
    this.configSelected = "";
    if (this.configArray && this.configArray.length > 0) {
      this.configArray.forEach(apparr => {
        this.configSelected = this.configSelected.concat(apparr.toString() + ",");
      });
    }
    else
      this.configSelected = null;

    this.configValueArray = this.apjAtsConfigMgmtForm.get('ddlConfigValue').value;
    this.configValuesSelected = "";
    if (this.configValueArray && this.configValueArray.length > 0) {
      this.configValueArray.forEach(apparr => {
        this.configValuesSelected = this.configValuesSelected.concat(apparr.toString() + ",");
      });
    }
    else
      this.configValuesSelected = null;

    this.filter.ApplicationIds = this.appselected;
    this.filter.ConfigIDs = this.configSelected;
    this.filter.ConfigValues = this.configValuesSelected;
    this.filter.Status = this.apjAtsConfigMgmtForm.get('ddlStatus').value;
    this.filter.PageNumber = -1;
    this.filter.PageSize = 500;

    this.filter.Status = (this.filter.Status == "-1") ? null : this.filter.Status;

    this._ApjAtsFacadeService.getApplicationConfigurations(this.filter)
      .subscribe(data => {
        this.configurationData = data;
        this.configurationList = this.configurationData.atsApplicationConfigurationList;
        this.dataSource = new MatTableDataSource(this.configurationList);
        this.dataSource.paginator = this.paginator;
        this.hasRecords = (this.dataSource != null && this.dataSource.data != null && this.dataSource.data.length > 0);
        this.indLoading = false;
      },
      error => {
        this.notifier.notify('error', 'Error while fetching Application configuration list');
        this.indLoading = false;
      });
    }

  update(item) {
    if (item.operation == 'update') {
      if (this.apjAtsConfigMgmtForm.get('txtConfigValue').value == undefined
        || this.apjAtsConfigMgmtForm.get('txtConfigValue').value == ''
        || this.apjAtsConfigMgmtForm.get('txtConfigValue').value == null) {
        item.Edit = true;
        this.notifier.notify('error', 'Please enter configuration value');
        return;
      }
      this.indLoading = true;
      this.postData.ApplicationID = item.applicationID;
      this.postData.ConfigID = item.configID;
      this.postData.ConfigName = item.configName;
      this.postData.ConfigValue = this.apjAtsConfigMgmtForm.get('txtConfigValue').value//item.configValue;
      this.postData.IsActive = this.apjAtsConfigMgmtForm.get('chkStatus').value//item.isActive;
      this.postData.UserName = "ASIA-PACIFIC\\Kiran_kumar_Kommi";
      this.postData.Operation = 'update';

      this._ApjAtsFacadeService.updateapplicationconfiguration(this.postData)
        .subscribe(data => {
          this.search();
          this.notifier.notify('success', 'Information updated successfully');
        },
        error => {
          this.notifier.notify('error', 'Error while updating Application configuration');
          this.indLoading = false;
        });
    }
    else if (item.operation == 'add') {
      if (this.apjAtsConfigMgmtForm.get('ddlTblAppName').value == undefined
        ||  this.apjAtsConfigMgmtForm.get('ddlTblAppName').value == ''
        || this.apjAtsConfigMgmtForm.get('ddlTblAppName').value == null) {
        item.Edit = true;
        this.notifier.notify('error','Please select application');
        return;
      }
      if (this.apjAtsConfigMgmtForm.get('txtConfigName').value == undefined
        || this.apjAtsConfigMgmtForm.get('txtConfigName').value == ''
        || this.apjAtsConfigMgmtForm.get('txtConfigName').value == null) {
        item.Edit = true;
        this.notifier.notify('error','Please enter configuration name');
        return;
      }
      if (this.apjAtsConfigMgmtForm.get('txtConfigValue').value == undefined
        || this.apjAtsConfigMgmtForm.get('txtConfigValue').value == ''
        || this.apjAtsConfigMgmtForm.get('txtConfigValue').value == null) {
        item.Edit = true;
        this.notifier.notify('error','Please enter configuration value');
        return;
      }

      this.indLoading = true;
      this.postData.ApplicationID = this.apjAtsConfigMgmtForm.get('ddlTblAppName').value//item.applicationID;
      this.postData.ConfigID = item.configID;
      this.postData.ConfigName = this.apjAtsConfigMgmtForm.get('txtConfigName').value//item.configName;
      this.postData.ConfigValue = this.apjAtsConfigMgmtForm.get('txtConfigValue').value//item.configValue;
      this.postData.IsActive = this.apjAtsConfigMgmtForm.get('chkStatus').value//item.isActive;
      this.postData.UserName = "ASIA-PACIFIC\\Kiran_kumar_Kommi";
      this.postData.Operation = 'add';

      this._ApjAtsFacadeService.updateapplicationconfiguration(this.postData)
        .subscribe(data => {
          this.search();
          this.notifier.notify('success', 'Information added successfully');
        },
          error => {
            this.notifier.notify('error', 'Error while adding Application configuration');
            this.indLoading = false;
          });
    }
  }

  createNewUser(): AtsApplicationConfigurationList {
    return {
      applicationID: 0,
      applicationName: '',
      brandId: 0,
      brandName: '',
      catalogId: 0,
      catalogName: '',
      configID: 0,
      configName: '',
      configValue: '',
      familyId: 0,
      familyName: '',
      isActive: false,
      operation: 'add',
      preDefinitionCode: '',
      productLine: '',
      productLineId: 0,
      trimmedConfigName: '',
      userName: '',
      xMLConfigValue: '',
      Edit: true,
      add: true
    };
    }

  addRow() {
    if (!this.addNewRow) {
      this.addNewRow = true;
      this.dataSource.data.unshift(this.createNewUser());
      this.dataSource.filter = "";
      this.dataSource.paginator = this.paginator;
    }
    else {
      this.notifier.notify('error', 'Please add the new row or cancel it');
    }
  }

  cancel(item) {
    if (item.operation == 'add') {
      this.addNewRow = false;
      this.search();
    }
  }

  edit(item) {
    if (!this.addNewRow) {
      this.configurationList.forEach(contact => {
        contact.Edit = false;
      });
      item.Edit = true;
      item.operation = 'update';
    }
  }

  selectAllaApps() {
    this.selectedApps = [];
    this.applications.forEach(app => {
      this.selectedApps.push(app.id);
    });
    this.apjAtsConfigMgmtForm.get('ddlAppName').setValue(this.selectedApps);
    this.getConfigurations();
  }

  deselectAllApps() {
    this.apjAtsConfigMgmtForm.get('ddlAppName').setValue([]);
    this.getConfigurations();
  }

  selectAllConfigNames() {
    this.selectedConfigNames = [];
    this.atsApplicationConfigurationList.forEach(configlist => {
      this.selectedConfigNames.push(configlist.configID);
    });
    this.apjAtsConfigMgmtForm.get('ddlConfigName').setValue(this.selectedConfigNames);
  }

  deselectAllConfigNames() {
    this.configSelected = "";
    this.apjAtsConfigMgmtForm.get('ddlConfigName').setValue([]);
  }

  selectAllConfigValues() {
    this.selectedConfigValues = [];
    this.atsApplicationConfigurationList.forEach(configlst => {
      this.selectedConfigValues.push(configlst.configID);
    });
    this.apjAtsConfigMgmtForm.get('ddlConfigValue').setValue(this.selectedConfigValues);
  }

  deselectAllConfigValues() {
    this.configValuesSelected = "";
    this.apjAtsConfigMgmtForm.get('ddlConfigValue').setValue([]);
  }
}




