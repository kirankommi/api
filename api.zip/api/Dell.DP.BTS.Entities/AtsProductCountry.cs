﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsProductCountry
    {
        public int SalesChannel { get; set; }
        public int CountryID { get; set; }
        public string CountryName { get; set; }
        public bool ContinueToSell { get; set; }
        public string SellActionOffline { get; set; }
        public bool IncludePreCheckout { get; set; }
        public bool IncludePostCheckout { get; set; }
        public bool DisplayLowInventory { get; set; }
        public int LeadTime { get; set; }
        public int ExtendedLeadTime { get; set; }
        public int Low { get; set; }
        public int SDS { get; set; }
        public int Oversell { get; set; }
        public int Oversold { get; set; }
        public int? OversoldOffline { get; set; }
        public bool SDSEnabled { get; set; }

        public int? CatalogGroupId { get; set; }
        public string CountryIds { get; set; }
        public string CatalogCountryBindingID { get; set; }

    }
}
