﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dell.DP.BTS.Entities
{
    public class AtsApplicationConfiguration
    {
        public int ConfigID { get; set; }
        public  string ConfigName { get; set; }
        public string TrimmedConfigName { get; set; }
        public string ConfigValue { get; set; }
        public string XMLConfigValue { get; set; }
        public int ApplicationID { get; set; }
        public string ApplicationName { get; set; }
        public bool? IsActive { get; set; }
        public string UserName { get; set; }
        public int CatalogId { get; set; }
        public string CatalogName { get; set; }
        public int ProductLineId { get; set; }
        public string ProductLine { get; set; }
        public int BrandId { get; set; }
        public string BrandName { get; set; }
        public int FamilyId { get; set; }
        public string FamilyName { get; set; }
        public string PreDefinitionCode { get; set; }
        public string Operation { get; set; }

    }
}
