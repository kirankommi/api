var appConfig = {
    title: "ATSUX",
    lang: "en",
    dateFormat: "mm/dd/yy",
    apiBase: 'http://localhost:57606/api/',
   // apiBase: 'http://localhost:65141/api/',
    theme: 'skin-purple',
    layout: "fixed"
};
