﻿using Xunit;

namespace Dell.DP.BTS.UnitTesting
{
    /// <summary>
    /// Summary description for ProductConfigurationUnitTest
    /// </summary>
    
    public class JobConfigurationUnitTest:UnitTestInitializer
    {


        [Fact]
        public void GetJobConfigurationDataShouldReturnOKResult()
        {
            int regionId = 3;
            var result = btsQueryController.GetJobDetails(regionId);
            Assert.NotNull(result);
        }

        [Fact]
        public void GetTransactionDetailsDataShouldReturnOKResult()
        {
            int regionId = 3;
            var result = btsQueryController.GetTransactionDetails(regionId);
            Assert.NotNull(result);
        }
    }
}
