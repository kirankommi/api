﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Dell.DP.BTS.BusinessServices.CommandBusiness.Implementation;
using Dell.DP.BTS.BusinessServices.CommandBusiness.Interfaces;
using Dell.DP.BTS.BusinessServices.QueryBusiness.Implementation;
using Dell.DP.BTS.BusinessServices.QueryBusiness.Interfaces;
using Dell.DP.BTS.DataServices.CommandRepository.Implementation;
using Dell.DP.BTS.DataServices.CommandRepository.Interfaces;
using Dell.DP.BTS.DataServices.DbFactory;
using Dell.DP.BTS.DataServices.QueryRepository.Implementation;
using Dell.DP.BTS.DataServices.QueryRepository.Interfaces;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Serilog;
using Serilog.Exceptions;
using Swashbuckle.AspNetCore.Swagger;

namespace Dell.DP.BTS.APJ.API
{
    [ExcludeFromCodeCoverage]
    public class Startup
    {
        public IHostingEnvironment HostingEnvironment { get; }
        public IConfiguration Configuration { get; }
        public Startup(IConfiguration configuration, IHostingEnvironment hostingEnvironment)
        {
            this.HostingEnvironment = hostingEnvironment;
            var builder = new ConfigurationBuilder()
                .SetBasePath(hostingEnvironment.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{hostingEnvironment.EnvironmentName}.json", reloadOnChange: true, optional: true)
                .AddEnvironmentVariables();
            Configuration = builder.Build();


            Log.Logger = new LoggerConfiguration()
           .ReadFrom.Configuration(configuration)
           .Enrich.FromLogContext()
           .Enrich.WithExceptionDetails()
           .Enrich.WithMachineName()
           .CreateLogger();
            Console.WriteLine(hostingEnvironment.EnvironmentName);
            Console.WriteLine(Configuration.GetConnectionString("Query_Connection").ToString());
            //Log.Information(Configuration.GetConnectionString("Query_Connection").ToString());
        }


        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddPolicy("CORSPolicy", corsPolicyBuilder => corsPolicyBuilder.AllowAnyOrigin()
                    /* Apply CORS policy for any type of origin */
                    .AllowAnyMethod()
                    /* Apply CORS policy for any type of http methods  */
                    .AllowAnyHeader()
                    /* Apply CORS policy for any headers */
                    .AllowCredentials());
                /* Apply CORS policy for all users  */
            });
            services.AddMvc()
            .AddFluentValidation(fvc => fvc.RegisterValidatorsFromAssemblyContaining<Startup>())
            .SetCompatibilityVersion(CompatibilityVersion.Version_2_1)
            .AddJsonOptions(options =>
            {
                options.SerializerSettings.Converters.Add(new Newtonsoft.Json.Converters.StringEnumConverter());
                options.SerializerSettings.NullValueHandling = Newtonsoft.Json.NullValueHandling.Ignore;
            });

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1",
                    new Info
                    {
                        Title = "BTS Inventory Internal API for APJ region",
                        Version = "v1",
                        Description = "BTS Inventory Internal API for APJ region facilitate Dell BTS products inventory related informaiton",
                        Contact = new Contact { Name = "Email to Delivery Promise L3 Support for any queries.", Email = "DeliveryPromise_Support@Dell.com" }
                    });
                c.DescribeAllParametersInCamelCase();
            });

            services.AddScoped<IBtsQueryBusiness, BtsQueryBusiness>();
            services.AddScoped<IBtsCommandBusiness, BtsCommandBusiness>();
            services.AddScoped<IBtsQueryRepository, BtsQueryRepository>();
            services.AddScoped<IBtsCommandRepository, BtsCommandRepository>();
            services.AddTransient<IDbFactory>(s => new QueryDbFactory(Configuration.GetConnectionString("Query_Connection")));
            services.AddTransient<IDbFactory>(s => new CommandDbFactory(Configuration.GetConnectionString("Command_Connection")));
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            app.UseHttpsRedirection();

            app.UseSwagger(c =>
            {
                /*Change the path of the end point , should also update UI middle ware for this change   */
                c.RouteTemplate = "swagger/{documentName}/swagger.json";
            });
            app.UseSwaggerUI(c =>
            {
                /*Include virtual directory if site is configured so */
                c.RoutePrefix = "swagger";
                c.SwaggerEndpoint("v1/swagger.json", "BTS Inventory Internal API");
            });
            // app.UseRequestResponseLogging();
            app.UseCors("CORSPolicy");
            app.UseMvc();
        }
    }
}
