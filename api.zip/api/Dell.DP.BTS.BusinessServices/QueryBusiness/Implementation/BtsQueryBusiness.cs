﻿using Dell.DP.BTS.BusinessServices.QueryBusiness.Interfaces;
using Dell.DP.BTS.DataServices.QueryRepository.Interfaces;
using Dell.DP.BTS.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Dell.DP.BTS.BusinessServices.QueryBusiness.Implementation
{
    public class BtsQueryBusiness : IBtsQueryBusiness
    {

        #region Private Members
        /// <summary>
        /// This property can be used bts inventory query business object as dynamic
        /// </summary>
        private readonly IBtsQueryRepository _btsQueryRepository;


        #endregion

        #region Constructor

        /// <summary>
        /// Paramterised constructor with inventory query business object as parameter 
        /// </summary>
        /// <param name="inventoryQueryBusiness"></param>
        public BtsQueryBusiness(IBtsQueryRepository btsQueryRepository) => _btsQueryRepository = btsQueryRepository;

        #endregion

        #region Public Get routes
        /// <summary>
        /// This end point can be used to test the API health
        /// </summary>
        /// <returns>boolean value</returns>

        public bool IsAlive()
        {
            return true;
        }

        public async Task<IEnumerable<AtsDataRefresh>> GetAtsItemRefreshDetail(int ProductCountryId)
        {
            return await _btsQueryRepository.GetAtsItemRefreshDetail(ProductCountryId);
        }
        public async Task<IEnumerable<AtsStatusHistory>> GetAtsStatusHistory(int ProductCountryId)
        {
            return await _btsQueryRepository.GetAtsStatusHistory(ProductCountryId);
        }
        public async Task<IEnumerable<AtsLeadTimeHistory>> GetLeadTimeHistory(int ProductCountryId)
        {
            return await _btsQueryRepository.GetLeadTimeHistory(ProductCountryId);
        }
        public async Task<IEnumerable<AtsItemDetail>> GetAtsItemDetail(int ProductCountryId)
        {
            return await _btsQueryRepository.GetAtsItemDetail(ProductCountryId);
        }
        public async Task<IEnumerable<AtsDaysofSupply>> GetDaysofSupply(int ProductCountryId)
        {
            return await _btsQueryRepository.GetDaysofSupply(ProductCountryId);
        }
        public async Task<List<AtsItem>> GetFGAItemExportDetails(AtsItemSearchRequest Item)
        {
            return await _btsQueryRepository.GetFGAItemExportDetails(Item);
        }
        public async Task<AtsFgaItemLists> GetFGAItemDetails(AtsItemSearchRequest Item)
        {
            return await _btsQueryRepository.GetFGAItemDetails(Item);
        }
        public async Task<IEnumerable<InventryStatus>> GetStockStatus()
        {
            return await _btsQueryRepository.GetStockStatus();
        }
        public async Task<IEnumerable<AtsCountry>> GetCountriesAndCatalogGroups(int regionId)
        {
            return await _btsQueryRepository.GetCountriesAndCatalogGroups(regionId);
        }
        public async Task<Dictionary<string, int>> GetCountryUsageDetail(int id)
        {

            return await _btsQueryRepository.GetCountryUsageDetail(id);
        }

        public async Task<IEnumerable<AtsItem>> GetCatalogGroup(int regionId)
        {
            return await _btsQueryRepository.GetCatalogGroup(regionId);
        }
        public async Task<IEnumerable<AtsSite>> GetFulfillmentLocation(int regionId)
        {
            return await _btsQueryRepository.GetFulfillmentLocation(regionId);
        }
        public async Task<AtsProductCountry> GetProductCountryDefaults()
        {
            return await _btsQueryRepository.GetProductCountryDefaults();
        }
        public IEnumerable<AtsProdType> GetProductTypes()
        {
            return _btsQueryRepository.GetProductTypes();
        }
        public async Task<IEnumerable<AtsBrand>> GetBrands(Int32 productlineId)
        {
            return await _btsQueryRepository.GetBrands(productlineId);
        }
        public async Task<IEnumerable<AtsProductInfo>> GetProductLines(Int32 catalogId)
        {
            return await _btsQueryRepository.GetProductLines(catalogId);
        }
        public async Task<IEnumerable<AtsSite>> GetProductFulfillmentLocation(int ProductCountryId, int Region)
        {
            return await _btsQueryRepository.GetProductFulfillmentLocation(ProductCountryId, Region);
        }
        public async Task<IEnumerable<RegionItem>> GetAllRegions()
        {
            return await _btsQueryRepository.GetAllRegions();
        }
        public async Task<IEnumerable<AtsCountry>> GetCountries(int regionId)
        {
            return await _btsQueryRepository.GetCountries(regionId);
        }
        public async Task<AtsProductInfo> GetProductInformation(int productID, int regionId)
        {
            return await _btsQueryRepository.GetProductInformation(productID, regionId);
        }
        public async Task<IEnumerable<int>> GetDefaultCatalog(int CountryId)
        {
            return await _btsQueryRepository.GetDefaultCatalog(CountryId);
        }
        public async Task<IEnumerable<DefaultCatalogRequest>> GetDefaultCatalogs(List<int> CountryIds)
        {
            return await _btsQueryRepository.GetDefaultCatalogs(CountryIds);
        }
        public async Task<IEnumerable<AtsCatalog>> GetCatalog(AtsCatalog Item)
        {
            return await _btsQueryRepository.GetCatalog(Item);
        }
        public async Task<IEnumerable<AtsCatalog>> GetCatalogs(AtsCatalog Item)
        {
            return await _btsQueryRepository.GetCatalogs(Item);
        }
        public async Task<IEnumerable<AtsApplication>> GetApplications()
        {
            return await _btsQueryRepository.GetApplications();
        }
        public async Task<AtsAppConfigList> GetApplicationConfigurations(AtsAppConfigRequest appConfigReq)
        {
            return await _btsQueryRepository.GetApplicationConfigurations(appConfigReq);
        }
        public async Task<AtsAppConfigList> GetApplicationRuleConfigurations(AtsAppConfigRequest appConfigReq)
        {
            return await _btsQueryRepository.GetApplicationRuleConfigurations(appConfigReq);
        }
        public async Task<IEnumerable<AtsCommitDetail>> GetCommitDetail(int ProductCountryId)
        {
            return await _btsQueryRepository.GetCommitDetail(ProductCountryId);
        }
        public async Task<IEnumerable<AtsJobTransactionStatus>> GetTransactionDetails(int regionId)
        {
            return await _btsQueryRepository.GetTransactionDetails(regionId);
        }
        public async Task<IEnumerable<AtsJobDetails>> GetJobDetails(int regionId)
        {
            return await _btsQueryRepository.GetJobDetails(regionId);
        }
        public async Task<IEnumerable<AtsItemSiteInventory>> GetInventoryStatus(int ProductCountryId)
        {
            return await _btsQueryRepository.GetInventoryStatus(ProductCountryId);
        }
        public async Task<AtsProductConfiguration> GetProductConfiguration()
        {
            return await _btsQueryRepository.GetProductConfiguration();
        }
        public async Task<InTransitLists> GetInTransit(AtsInTransitSearchRequest Item)
        {
            return await _btsQueryRepository.GetInTransit(Item);
        }
        public async Task<OrderDetailsSearchResultList> GetOrderDetails(OrderDetailsSearchRequest request)
        {
            return await _btsQueryRepository.GetOrderDetails(request);
        }
        public async Task<IEnumerable<OrderDetailsSearchResponse>> GetOrderExportDetails(OrderDetailsSearchRequest request)
        {
            return await _btsQueryRepository.GetOrderExportDetails(request);
        }
        public async Task<IEnumerable<InTransit>> GetInTransitExport(AtsInTransitSearchRequest Item)
        {
            return await _btsQueryRepository.GetInTransitExport(Item);
        }
        public async Task<CommitCalloutDetailResponse> GetCommitCalloutDetails(CommitFalloutRequest request)
        {
            return await _btsQueryRepository.GetCommitCalloutDetails(request);
        }
        public async Task<IEnumerable<CommitCalloutDetail>> GetCommitCalloutExportDetails(CommitFalloutRequest request)
        {
            return await _btsQueryRepository.GetCommitCalloutExportDetails(request);
        }

        #endregion
    }
}
